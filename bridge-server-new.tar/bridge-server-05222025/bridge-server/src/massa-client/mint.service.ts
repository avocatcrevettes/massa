import { Injectable } from '@nestjs/common';
import { BridgingState, LockMintEntity } from '../database/entities';
import { BridgeError, Codes, isBridgeError } from '../utils/errors';
import { Interval } from '@nestjs/schedule';
import { ForwardingRequest, TokenPair } from './request';
import { Args, EOperationStatus, toMAS } from '@massalabs/massa-web3';
import { toReadable } from '../utils/decimals';
import { MintServiceInit } from './mint.service.init';
import { PERIOD_TIME } from './constants';
import { multisigThresholdReached, packSignatures } from './multisig-utils';

const MAX_OP_PER_PERIOD = 5;

export const SIGNATURE_BYTE_LEN = 65;

@Injectable()
export class MintService extends MintServiceInit {
    public async mintWrappedAsset(entity: LockMintEntity): Promise<string> {
        const { inputTxId, inputLogIdx, outputAmount, outputAddr, massaToken, ercToken, originNetwork, signatures } =
            entity;

        try {
            const tokenPair = new TokenPair(massaToken, ercToken, originNetwork);

            const packedSignatures = packSignatures(signatures);
            const mintRequest = new ForwardingRequest(
                outputAmount,
                outputAddr,
                inputLogIdx,
                tokenPair,
                packedSignatures,
            );

            mintRequest.opId = inputTxId;

            const parameter = new Args().addSerializable(mintRequest).serialize();
            const coins = this.massaOperations.getBridgeCoinsAmount();
            const maxGas = await this.massaOperations.getDynamicGasCost(
                this.massaClient.bridgeContract,
                'forwardMint',
                parameter,
            );

            this.logger.debug(
                `Minting ${toReadable(outputAmount, 18)} ${tokenPair.massaToken} to ${outputAddr}. maxGas: ${maxGas}`,
            );
            const opId = await this.massaClient.client.smartContracts().callSmartContract({
                fee: this.massaOperations.defaultFee,
                maxGas,
                coins,
                targetAddress: this.massaClient.bridgeContract,
                targetFunction: 'forwardMint',
                parameter,
            });

            const symbol = await this.massaClient.getTokenSymbol(tokenPair.massaToken);
            const decimals = await this.massaClient.getTokenDecimals(tokenPair.massaToken);
            this.logger.log(
                `Mint Op submitted: ${toReadable(outputAmount, decimals)} ${symbol}. OpId: ${opId}. Coins  ${toMAS(
                    coins,
                ).toString()}`,
            );
            return opId;
        } catch (err) {
            this.logger.error(`Failed to submit mint for txid ${inputTxId}`, err.toString());
            throw new BridgeError(Codes.MASSA_MINT_REQUEST, `Operation Id: ${inputTxId}: ${err.toString()}`);
        }
    }

    public finalizeLockMint = async (lockMint: LockMintEntity): Promise<void> => {
        const { inputTxId, inputLogIdx, outputOpId } = lockMint;

        try {
            this.logger.log(`Finalizing LockMint. txId ${inputTxId}. opId: ${outputOpId}`);

            await this.massaOperations.waitFinalOperation(outputOpId);
            this.logger.log(`Mint ${outputOpId} reached finality`);

            await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.processing, {
                state: BridgingState.done,
                outputIsFinal: true,
            });
        } catch (err) {
            this.logger.error(`Unable to finalize LockMint, tx ${inputTxId} logIndex ${inputLogIdx}`, err.toString());
            const bridgeError = isBridgeError(err) ? err : new BridgeError(Codes.FINALIZE_LOCKMINT, err.toString());

            try {
                await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.processing, {
                    state: BridgingState.error,
                    error: bridgeError,
                });
            } catch (err) {
                this.logger.error(`Unable to update LockMint state of, tx ${inputTxId}`, err.toString());
            }
        }
    };

    // every 16 secs (1 period)
    @Interval(1000 * PERIOD_TIME)
    public async retryMint(): Promise<void> {
        const failed = await this.db.getFailedLockMints();

        if (!failed.length) {
            return;
        }

        this.logger.log(`Retrying to submit ${failed.length} failed mint(s)`);

        let mintCnt = 0;
        for (const lockMint of failed) {
            try {
                const { inputTxId, inputLogIdx, outputOpId, error, amount } = lockMint;

                if (amount === '0') {
                    // Set locks with amount = 0 to done
                    // This should not happen in new evm contract
                    await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.error, {
                        state: BridgingState.done,
                    });
                    continue;
                }

                if (this.isInLockList(inputTxId, inputLogIdx)) {
                    // mint is final
                    await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.error, {
                        state: BridgingState.done,
                        outputIsFinal: true,
                    });
                    continue;
                }

                if (outputOpId) {
                    const status = await this.massaOperations.getOperationStatus(outputOpId);
                    switch (status) {
                        case EOperationStatus.INCLUDED_PENDING:
                        case EOperationStatus.AWAITING_INCLUSION:
                        case EOperationStatus.SPECULATIVE_ERROR:
                        case EOperationStatus.SPECULATIVE_SUCCESS:
                            continue;
                        case EOperationStatus.FINAL_SUCCESS:
                            await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.error, {
                                state: BridgingState.done,
                                outputIsFinal: true,
                            });
                            continue;
                    }
                }
                if (!multisigThresholdReached(lockMint, this.massaClient.multisigThreshold)) {
                    // this should not happen. Retry mechanism should only deals with signed mints
                    this.logger.error(`Not enough signatures collected for ${inputTxId}. Skipping retry`);
                    continue;
                }

                const isExpired = error.code === Codes.MASSA_OPERATION_EXPIRED;
                const isGasError = error.code === Codes.MASSA_INSUFFICIENT_GAS;
                const submitError = error.code === Codes.MASSA_MINT_REQUEST;
                const interrupted = error.code === Codes.INTERRUPTED_PROCESSING;

                if (interrupted || submitError || isExpired || isGasError) {
                    if (++mintCnt > MAX_OP_PER_PERIOD) {
                        return;
                    }

                    await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.error, {
                        state: BridgingState.processing,
                    });

                    let opId;
                    let processingLockMint;
                    try {
                        opId = await this.mintWrappedAsset(lockMint);

                        // set output opId
                        processingLockMint = await this.db.updateLockMintState(
                            inputTxId,
                            inputLogIdx,
                            BridgingState.processing,
                            {
                                state: BridgingState.processing,
                                outputOpId: opId,
                            },
                        );
                    } catch (err) {
                        // set back to error state
                        await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.processing, {
                            state: BridgingState.error,
                            error: err,
                        });
                        continue;
                    }

                    // eslint-disable-next-line @typescript-eslint/no-floating-promises
                    this.finalizeLockMint(processingLockMint);
                }
            } catch (err) {
                this.logger.error(`Unable to process lockmint retry.`, err.toString());
                continue;
            }
        }
    }

    public isMinted = (lockMint: LockMintEntity): boolean => {
        return this.isInLockList(lockMint.inputTxId, lockMint.inputLogIdx) || lockMint.outputIsFinal;
    };
}
