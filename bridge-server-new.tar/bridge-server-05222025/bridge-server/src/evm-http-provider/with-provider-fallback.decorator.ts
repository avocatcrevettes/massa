import { ethers } from 'ethers';
import { EvmHttpProviderService } from './evm-http-provider.service';

const RPC_ERROR_TIMEOUT_DELAY_SECOND = 600;

/**
 * Decorator to add Fallback logic to a EVM method. 
 * 
 * @remarks
 * It retries the method call up to a specified limit when it fails.
 * This decorator is intended to be used within the `EvmHttpProviderService` class, as it depends on the context
 * provided by this service, including methods like `switchToNextProvider` and logging capabilities.
 * The first argument of the called method must be the chainId .

 * @returns Modified method descriptor with fallback logic.
 */
export default function WithProviderFallback() {
    return function <T>(target: T, propertyKey: string, descriptor: PropertyDescriptor) {
        const originalMethod = descriptor.value;

        descriptor.value = async function (...args: any[]) {
            // eslint-disable-next-line @typescript-eslint/no-this-alias
            const evmProviderService: EvmHttpProviderService = this;

            if (!evmProviderService.switchToNextProvider) {
                throw new Error('You should use this decorator within the EvmHttpProviderService class');
            }

            const chainId: number = args[0];
            if (!evmProviderService.enabledNetworks.includes(chainId)) {
                throw new Error(
                    `Invalid chainId: ${chainId}. the first argument of the  ${propertyKey} method should be the chainId`,
                );
            }

            async function attempt() {
                try {
                    return originalMethod.apply(evmProviderService, args);
                } catch (error) {
                    evmProviderService.logger.warn(`Evm provider code: ${error?.code}: ${error?.message}`);

                    if (
                        Date.now() - evmProviderService.lastRPCErrorTimestamp[chainId] <
                        RPC_ERROR_TIMEOUT_DELAY_SECOND * 1000
                    ) {
                        await evmProviderService.alertsService.triggerAlert(
                            'rpc-call-error',
                            `Rpc call failed with code: ${error?.code}: ${error?.message}. Current rpc url: ${
                                (evmProviderService.signers[chainId].provider as ethers.providers.StaticJsonRpcProvider)
                                    .connection.url
                            }. RelayerId: ${evmProviderService.relayerId} Switching to next provider.`,
                            'warning',
                            true,
                        );
                    }
                    evmProviderService.lastRPCErrorTimestamp[chainId] = Date.now();
                    // We decided to switch to the next provider for every error, as it is difficult to know if the error comes from the provider or not.
                    evmProviderService.switchToNextProvider(chainId);

                    throw error;
                }
            }
            return attempt();
        };
        return descriptor;
    };
}
