import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { isDev, loadConfig } from './config';
import { utilities as nestWinstonModuleUtilities, WinstonModule } from 'nest-winston';
import * as winston from 'winston';
import WinstonCloudwatch from 'winston-cloudwatch';
import { CloudWatchLogs } from '@aws-sdk/client-cloudwatch-logs';
import { AwsCredentialIdentity } from '@aws-sdk/types';

async function bootstrap() {
    const envDir = `${__dirname}/../.env`;
    loadConfig(envDir);

    const loggerTransports: winston.transport[] = [
        new winston.transports.Console({ level: 'info' }),
        new winston.transports.File({
            filename: `logs/bridge-${process.env.APP_ENV || 'dev'}.log`,
            maxsize: 10000000,
            maxFiles: 10,
            tailable: true,
            level: 'debug',
        }),
    ];

    if (process.env.ENABLE_CLOUDWATCH_LOGS === 'true') {
        for (const conf of ['AWS_LOG_GROUP', 'AWS_LOG_STREAM', 'AWS_REGION']) {
            if (!process.env[conf]) {
                throw new Error(`Missing ${conf} in .env file`);
            }
        }

        let client;
        if (process.env.AWS_NEEDS_AUTH === 'true') {
            if (!process.env.ACCESS_KEY_ID) {
                throw new Error('ACCESS_KEY_ID not set but AWS_NEEDS_AUTH is set to true');
            }
            if (!process.env.SECRET_ACCESS_KEY) {
                throw new Error('SECRET_ACCESS_KEY not set but AWS_NEEDS_AUTH is set to true');
            }
            const credentials: AwsCredentialIdentity = {
                accessKeyId: process.env.ACCESS_KEY_ID,
                secretAccessKey: process.env.SECRET_ACCESS_KEY,
            };
            client = new CloudWatchLogs({ region: process.env.AWS_REGION, credentials });
        } else {
            client = new CloudWatchLogs({ region: process.env.AWS_REGION });
        }

        loggerTransports.push(
            new WinstonCloudwatch({
                logGroupName: process.env.AWS_LOG_GROUP,
                logStreamName: process.env.AWS_LOG_STREAM,
                cloudWatchLogs: client,
                level: 'debug',
            }),
        );
    }
    const app = await NestFactory.create(AppModule, {
        logger: WinstonModule.createLogger({
            format: winston.format.combine(
                winston.format.timestamp(),
                winston.format.ms(),
                nestWinstonModuleUtilities.format.nestLike('Bridge', {
                    colors: isDev(),
                    prettyPrint: true,
                }),
            ),
            transports: loggerTransports,
        }),
    });

    app.enableShutdownHooks();

    await app.init();
}

// eslint-disable-next-line @typescript-eslint/no-floating-promises
bootstrap();
