import { Module } from '@nestjs/common';
import { AWSModule } from '../aws/aws.module';
import { MetricsService } from './metrics.service';
import { MassaClientModule } from '../massa-client/massa-client.module';
import { EvmHttpProviderModule } from '../evm-http-provider/evm-http-provider.module';
import { DatabaseModule } from '../database/database.module';
import { HttpModule } from '@nestjs/axios';
import { EvmListenerModule } from '../evm-listener/evm-listener.module';

@Module({
    imports: [AWSModule, MassaClientModule, EvmHttpProviderModule, DatabaseModule, HttpModule, EvmListenerModule],
    controllers: [],
    providers: [MetricsService],
    exports: [MetricsService],
})
export class MetricsModule {}
