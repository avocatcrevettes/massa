import { Injectable, Logger } from '@nestjs/common';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';
import { MassaClientService } from '../massa-client/massa-client.service';
import { AWSService } from '../aws/aws.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import { toReadable } from '../utils/decimals';
import { DatabaseService } from '../database/database.service';
import { formatMAS, formatNumber } from './utils';
import { firstValueFrom } from 'rxjs';
import { HttpService } from '@nestjs/axios';
import { EvmBlockParserService } from '../evm-listener/evm-block-parser.service';
import { ethers } from 'ethers';
import { Networks, networkName } from '../evm-http-provider/networks';

const binanceApi = 'https://api.binance.com/api/v3/ticker/price?symbol=';
const RPC_ERROR_TIMEOUT_DELAY_SECOND = 900;

@Injectable()
export class MetricsService {
    private readonly logger = new Logger('Metrics');

    public lastBlockHeight: Record<number, number> = {};
    public lastRPCErrorTimestamp: Record<number, number> = {};

    constructor(
        protected readonly evmProvider: EvmHttpProviderService,
        protected readonly massaClient: MassaClientService,
        protected readonly awsService: AWSService,
        protected readonly db: DatabaseService,
        protected readonly evmBlockParser: EvmBlockParserService,
        private readonly httpService: HttpService,
    ) {}

    async onApplicationBootstrap(): Promise<void> {
        for (const chainId of this.evmProvider.enabledNetworks) {
            this.lastRPCErrorTimestamp[chainId] = 0;
        }
    }
    @Cron(CronExpression.EVERY_MINUTE)
    public async publishActivity(): Promise<void> {
        for (const tokenInfo of this.massaClient.tokensInfos) {
            // Count lockMints for token and compute total amount
            const lockMints = await this.db.getLockMints({ ercToken: tokenInfo.evmToken });
            await this.awsService.publishMetric(`${tokenInfo.symbol}-lock-count`, lockMints.length);

            const lockMintVolume = lockMints.reduce((acc, entity) => acc + BigInt(entity.amount), 0n);
            const totalLocked = formatNumber(toReadable(lockMintVolume, tokenInfo.decs));
            await this.awsService.publishMetric(`${tokenInfo.symbol}-lock-token-amount`, totalLocked);

            // Count burnRedeems for token and compute total amount
            const burnRedeems = await this.db.getBurnRedeems({ ercToken: tokenInfo.evmToken });
            await this.awsService.publishMetric(`${tokenInfo.symbol}-burn-count`, burnRedeems.length);

            const burnRedeemVolume = burnRedeems.reduce((acc, entity) => acc + BigInt(entity.amount), 0n);
            const totalBurned = formatNumber(toReadable(burnRedeemVolume, tokenInfo.decs));
            await this.awsService.publishMetric(`${tokenInfo.symbol}-burn-token-amount`, totalBurned);
        }

        if (this.massaClient.MasVaultContract) {
            // Count wMas burn and compute total amount
            const burnReleases = await this.db.getReleases();
            await this.awsService.publishMetric('wmas-burn-count', burnReleases.length);
            const burnVolume = burnReleases.reduce((acc, entity) => acc + BigInt(entity.amount), 0n);
            const totalBurned = formatMAS(burnVolume);
            await this.awsService.publishMetric(`wmas-burn-token-amount`, totalBurned);
        }
    }

    @Cron(CronExpression.EVERY_MINUTE)
    public async publishMASBalance(): Promise<void> {
        await this.awsService.publishMetric('bridge-mas-balance', formatMAS(this.massaClient.bridgeMASBalance));
        if (this.massaClient.MasVaultContract) {
            await this.awsService.publishMetric('vault-mas-balance', formatMAS(this.massaClient.MasVaultBalance));
        }
    }

    @Cron(CronExpression.EVERY_MINUTE)
    public async publishReservePeg(): Promise<void> {
        if (!!this.massaClient.MasVaultContract && this.evmProvider.WMasListeningEnabled) {
            for (const chainId of this.evmProvider.enabledNetworks) {
                if (chainId === Networks.BSC || chainId === Networks.BSC_Testnet) {
                    const WMasSupply = await this.evmProvider.getWMasSupply(chainId);
                    await this.awsService.publishMetric(
                        'reserve-wmas-peg',
                        formatMAS(this.massaClient.MasVaultBalance - WMasSupply),
                    );
                }
            }
        }
    }

    @Cron(CronExpression.EVERY_MINUTE)
    public async publishPegMetrics(): Promise<void> {
        const pendingClaims = await this.db.getPendingClaims();

        for (const chainId of this.evmProvider.enabledNetworks) {
            for (const tokenInfo of this.massaClient.tokensInfos) {
                if (tokenInfo.chainId !== chainId) {
                    continue;
                }
                const totalMinted = await this.massaClient.getTotalSupply(tokenInfo.massaToken);
                let totalLocked = ethers.BigNumber.from(0);
                try {
                    totalLocked = await this.evmProvider.getVaultBalance(
                        chainId,
                        tokenInfo.evmToken,
                        this.evmBlockParser.fromBlock[chainId] - 1,
                    );
                } catch (e) {
                    this.logger.warn(`Error getting vault balance for ${tokenInfo.symbol}...`);
                }
                const totalClaimable = pendingClaims.reduce((acc, claim) => {
                    if (claim.ercToken === tokenInfo.evmToken) {
                        return acc + BigInt(claim.amount);
                    }
                    return acc;
                }, 0n);
                const diff = totalLocked.toBigInt() - totalMinted - totalClaimable;
                await this.awsService.publishMetric(
                    `${tokenInfo.symbol}-supply-diff`,
                    formatNumber(toReadable(diff, tokenInfo.decs)),
                );
            }
        }
    }

    @Cron(CronExpression.EVERY_HOUR)
    public async publishTVL(): Promise<void> {
        try {
            let tvl = 0;
            for (const chainId of this.evmProvider.enabledNetworks) {
                for (const tokenInfo of this.massaClient.tokensInfos) {
                    if (tokenInfo.chainId !== chainId) {
                        continue;
                    }
                    const totalLocked = await this.evmProvider.getVaultBalance(chainId, tokenInfo.evmToken);
                    const usdPrice = await this.getAssetPrice(tokenInfo.symbol);
                    const formattedTotal = formatNumber(toReadable(totalLocked, tokenInfo.decs));
                    tvl += formattedTotal * usdPrice;
                }
            }
            await this.awsService.publishMetric(`tvl`, tvl);
        } catch (e) {
            this.logger.error('Error publising TVL: ' + e.toString());
        }
    }

    @Cron(CronExpression.EVERY_5_MINUTES)
    public async publishMassaOwnerMASBalance(): Promise<void> {
        const balance = await this.massaClient.client
            .wallet()
            .getAccountBalance(this.massaClient.client.wallet().getBaseAccount().address());
        await this.awsService.publishMetric('relayer-mas-balance', formatMAS(balance.candidate));
    }

    @Cron(CronExpression.EVERY_5_MINUTES)
    public async publishLockMintFailed(): Promise<void> {
        const failed = await this.db.getFailedLockMints();
        await this.awsService.publishMetric('failed-lockMint', failed.length);
        this.logger.warn(`Failed lockmints in db: ${failed.length}`);

        for (const lockMint of failed) {
            this.logger.warn(JSON.stringify(lockMint, null, 2));
        }
    }

    @Cron(CronExpression.EVERY_5_MINUTES)
    public async publishBurnRedeemFailed(): Promise<void> {
        const failed = await this.db.getFailedBurnRedeems();
        await this.awsService.publishMetric('failed-burnRedeem', failed.length);
        this.logger.warn(`Failed burnRedeem in db: ${failed.length}`);

        for (const burnRedeem of failed) {
            this.logger.warn(JSON.stringify(burnRedeem, null, 2));
        }
    }

    @Cron(CronExpression.EVERY_5_MINUTES)
    public async publishFailedRelease(): Promise<void> {
        const failed = await this.db.getFailedRelease();
        await this.awsService.publishMetric('failed-release', failed.length);
        this.logger.warn(`Failed release in db: ${failed.length}`);

        for (const entity of failed) {
            this.logger.warn(JSON.stringify(entity, null, 2));
        }
    }

    @Cron(CronExpression.EVERY_30_SECONDS)
    public async publishBlockHeight(): Promise<void> {
        if (this.evmBlockParser.isBootstrapping()) {
            return;
        }
        for (const chainId of this.evmProvider.enabledNetworks) {
            let metricName = 'block-height';
            const network = networkName(chainId);
            metricName += `-${network}`;
            metricName += `-relayer-${this.massaClient.relayerId}`;
            const currentBlockHeight = this.evmProvider.currentBlockNum[chainId];
            await this.awsService.publishMetric(metricName, currentBlockHeight);

            if (this.lastBlockHeight[chainId] === currentBlockHeight) {
                this.logger.log(`Block height is not increasing for relayer ${this.massaClient.relayerId}}`);
                this.evmProvider.switchToNextProvider(chainId);

                if (Date.now() - this.lastRPCErrorTimestamp[chainId] < RPC_ERROR_TIMEOUT_DELAY_SECOND * 1000) {
                    await this.evmProvider.alertsService.triggerAlert(
                        'rpc-stale-error',
                        `RPC block height is not updated since 30 seconds, for the second time in a ${
                            RPC_ERROR_TIMEOUT_DELAY_SECOND / 60
                        } minutes period. Current rpc url: ${
                            (this.evmProvider.signers[chainId].provider as ethers.providers.StaticJsonRpcProvider)
                                .connection.url
                        }. Relayer: ${this.massaClient.relayerId}. Switching to next provider.`,
                        'warning',
                        true,
                    );
                }
                this.lastRPCErrorTimestamp[chainId] = Date.now();
            }
            this.lastBlockHeight[chainId] = currentBlockHeight;
        }
    }

    async getAssetPrice(symbol: string): Promise<number> {
        let sym;
        // little hack to get the right symbol
        if (symbol.toUpperCase().includes('ETH')) {
            sym = 'ETH';
        } else if (symbol.toUpperCase().includes('BTC')) {
            sym = 'BTC';
        } else if (symbol.toUpperCase().includes('DAI')) {
            // sym = 'DAI';
            return 1;
        } else if (symbol.toUpperCase().includes('USD')) {
            // sym = 'USD';
            return 1;
        } else {
            throw new Error(`Unknown symbol ${symbol} for price fetching.`);
        }

        const { data } = await firstValueFrom(
            this.httpService.get<{ symbol: string; price: string }>(binanceApi + `${sym}USDT`),
        );
        return Number(data.price);
    }
}
