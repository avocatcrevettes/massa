import { ethers } from 'ethers';
import { toReadable } from '../utils/decimals';

// limit to 4 decimals digits
export function formatNumber(numberString: string, maxDecimals = 4): number {
    const parts = numberString.split('.');

    if (parts.length === 1) {
        return Number(parts[0]);
    }

    const integerPart = parts[0];
    let decimalPart = parts[1].slice(0, maxDecimals);

    // Remove trailing zeros from the decimal part
    while (decimalPart.endsWith('0')) {
        decimalPart = decimalPart.slice(0, -1);
    }

    if (decimalPart.length === 0) {
        return Number(integerPart);
    }
    return Number(`${integerPart}.${decimalPart}`);
}

export function formatETH(amount: ethers.BigNumber | bigint | string): number {
    return formatNumber(toReadable(amount, 18));
}

export function formatMAS(amount: ethers.BigNumber | bigint | string): number {
    return formatNumber(toReadable(amount, 9));
}
