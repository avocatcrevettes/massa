import bridgeVaultAbi from './BridgeVault.abi.json';
import WMasAbi from './WMAS.abi.json';

// Strings should match contract ABI events
enum bridgeEvents {
    Locked = 'Locked',
    OwnershipTransferred = 'OwnershipTransferred',
    Redeemed = 'Redeemed',
    TokenAdded = 'TokenAdded',
    TokenRemoved = 'TokenRemoved',
    Paused = 'Paused',
    Unpaused = 'Unpaused',
    SignerAdded = 'SignerAdded',
    SignerRemoved = 'SignerRemoved',
}

enum wmasEvents {
    Approval = 'Approval',
    Burn = 'Burn',
    RoleAdminChanged = 'RoleAdminChanged',
    RoleGranted = 'RoleGranted',
    RoleRevoked = 'RoleRevoked',
    Transfer = 'Transfer',
}
export { bridgeVaultAbi, WMasAbi, bridgeEvents, wmasEvents };
