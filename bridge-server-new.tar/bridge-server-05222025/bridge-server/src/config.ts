import { config } from 'dotenv-safe';

export const DEFAULT_ENV = 'dev';

// Load config and check for missing values
export const loadConfig = (envDir: string): void => {
    const env = process.env.NODE_ENV === 'test' ? 'test' : process.env.APP_ENV || DEFAULT_ENV;
    config({
        path: `${envDir}/${env}.env`,
        example: `${envDir}/${env}.env.example`,
        allowEmptyValues: true,
    });
};

export const isDev = (): boolean => !process.env.APP_ENV || process.env.APP_ENV === DEFAULT_ENV;
