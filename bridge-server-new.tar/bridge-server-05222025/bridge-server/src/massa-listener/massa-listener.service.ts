import { Injectable, Logger } from '@nestjs/common';
import { MassaClientService } from '../massa-client/massa-client.service';
import { SchedulerRegistry } from '@nestjs/schedule';
import { DatabaseService } from '../database/database.service';
import { BridgingState, isSignedByRelayer } from '../database/entities';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';
import { BurnService } from '../massa-client/burn.service';
import { ForwardingRequest } from '../massa-client/request';
import { multisigThresholdReached, signRedeemRequest } from '../massa-client/multisig-utils';

@Injectable()
export class MassaListenerService {
    constructor(
        private schedulerRegistry: SchedulerRegistry,
        protected readonly massaClient: MassaClientService,
        protected readonly burn: BurnService,
        protected readonly db: DatabaseService,
        protected readonly evmProvider: EvmHttpProviderService,
    ) {}

    private readonly logger = new Logger('Massa-listener');

    public async onApplicationBootstrap(): Promise<void> {
        if (this.evmProvider.multisigThreshold != this.massaClient.multisigThreshold) {
            throw new Error('Multisig threshold mismatch');
        }

        // check if supported networks are the same
        if (
            this.evmProvider.enabledNetworks.sort().toString() !=
            this.massaClient.tokensInfos
                .map((info) => info.chainId)
                // filter duplicates
                .filter((value, index, self) => self.indexOf(value) === index)
                .sort()
                .toString()
        ) {
            throw new Error('Supported networks mismatch');
        }

        // check that relayerIds are the same
        if (this.evmProvider.relayerId != this.massaClient.relayerId) {
            throw new Error('RelayerId mismatch');
        }

        const intervalMs = parseInt(process.env.MASSA_POLL_INTERVAL_SEC) * 1000;
        const interval = setInterval(this.poll, intervalMs);
        this.schedulerRegistry.addInterval('pollMassa', interval);
    }

    public poll = async (): Promise<void> => {
        try {
            const list = await this.massaClient.getBurnList();
            // Check if list is empty
            if (!list.length) {
                return;
            }

            this.logger.log(`Fetched ${list.length} burn receipts from Massa SC.`);
            for (const burn of list) {
                try {
                    await this.processBurnRedeem(burn);
                } catch (err) {
                    this.logger.debug(`Error while processing burn ${burn.opId}: ${err.toString()}`);
                    continue;
                }
            }
        } catch (err) {
            this.logger.error(`Error while polling Massa: ${err}`);
        }
    };

    public processBurnRedeem = async (burn: ForwardingRequest): Promise<void> => {
        const relayerId = this.massaClient.relayerId;

        if (!this.evmProvider.enabledNetworks.includes(burn.tokenPair.chainId)) {
            this.logger.error(`Invalid chain id ${burn.tokenPair.chainId}`);
            return;
        }

        let entity = await this.db.addNewBurnRedeem({
            inputOpId: burn.opId,
            inputAddr: burn.caller,
            outputAddr: burn.receiver,
            amount: burn.amount,
            ercToken: burn.tokenPair.evmToken,
            massaToken: burn.tokenPair.massaToken,
            destinationNetwork: burn.tokenPair.chainId,
        });

        if (isSignedByRelayer(entity, relayerId)) {
            return;
        }

        // only sign data coming from the blockchain to mitigate database corruption risk
        const signature = await this.signRedeemRequest(burn);

        entity = await this.db.addRedeemSignature(entity, relayerId, signature);

        // if not all signatures are collected, stop here
        // if already processed, stop here
        if (
            entity.state != BridgingState.new ||
            !multisigThresholdReached(entity, this.massaClient.multisigThreshold)
        ) {
            return;
        }

        await this.db.updateBurnRedeem(burn.opId, BridgingState.new, {
            state: BridgingState.processing,
        });
    };

    public async signRedeemRequest(burn: ForwardingRequest): Promise<string> {
        this.logger.log(`Signing redeem request ${burn.opId}`);
        const chainId = burn.tokenPair.chainId;
        return signRedeemRequest(
            this.evmProvider.signers[chainId],
            burn.amount,
            burn.opId,
            burn.tokenPair.evmToken,
            burn.receiver,
            chainId,
        );
    }
}
