import { Injectable, Logger } from '@nestjs/common';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';
import { scheduler } from 'node:timers/promises';
import { ethers, utils } from 'ethers';
import { bridgeEvents, bridgeVaultAbi, wmasEvents } from '../contracts';
import { EvmEventHandlerService } from './event-handler.service';
import { AlertsService } from '../alerts/alerts.service';
import { isHexadecimal } from 'class-validator';
import { Networks, networkName } from '../evm-http-provider/networks';

// avoid trigger alerts for old events when we restart the service
const ALERT_CONFIRMATIONS_TRESHOLD = 20;

@Injectable()
export class EvmBlockParserService {
    constructor(
        private readonly provider: EvmHttpProviderService,
        private readonly eventHandler: EvmEventHandlerService,
        private readonly alertsService: AlertsService,
    ) {}

    private readonly logger = new Logger('evm-http-listener');

    public maxBatchSize: Record<number, number> = {};
    public blockRangeSize: Record<number, number> = {};
    public fromBlock: Record<number, number> = {};
    public intervalSec: Record<number, number> = {};
    public bootstrapStatus: Record<number, boolean> = {};

    async onApplicationBootstrap(): Promise<void> {
        let networkIdx = 0;
        for (const chainId of this.provider.enabledNetworks) {
            const initBlock = parseInt(process.env[`EVM_INIT_BLOCK_${networkIdx}`]);
            if (isNaN(initBlock) || initBlock < 1) {
                throw new Error('Invalid init block for network ' + chainId);
            }
            this.fromBlock[chainId] = initBlock;

            const batchSize = parseInt(process.env[`MAX_BATCH_SIZE_${networkIdx}`]);
            if (isNaN(batchSize) || batchSize < 1) {
                throw new Error('Invalid MAX_BATCH_SIZE for network ' + chainId);
            }
            this.maxBatchSize[chainId] = batchSize;

            const blockRange = parseInt(process.env[`BLOCK_RANGE_SIZE_${networkIdx}`]);
            if (isNaN(blockRange) || blockRange < 1) {
                throw new Error('Invalid BLOCK_RANGE_SIZE for network ' + chainId);
            }
            this.blockRangeSize[chainId] = blockRange;

            const intervalSec = parseInt(process.env[`PARSE_INTERVAL_SEC_${networkIdx}`]);
            if (isNaN(intervalSec) || intervalSec < 1) {
                throw new Error('Invalid PARSE_INTERVAL_SEC for network ' + chainId);
            }
            this.intervalSec[chainId] = intervalSec;

            this.bootstrapStatus[chainId] = true;

            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            this.task(chainId);
            ++networkIdx;
        }
    }

    // main loop
    public task = async (chainId: number): Promise<void> => {
        this.logger.log(`*************************************************************************************`);
        this.logger.log(
            `*** Start evm block listener for network ${networkName(chainId)} from block ${
                this.fromBlock[chainId]
            }. ***`,
        );
        this.logger.log(`*************************************************************************************`);

        while (true) {
            const start = Date.now();
            try {
                await this.fetchBlocks(chainId);
                if (!this.isBootstrapping()) {
                    this.alertsService.isBootstrapping = false;
                } else {
                    this.bootstrapStatus[chainId] = false;
                }
            } catch (err) {
                this.logger.error('Http listener sync failed:', err.toString());
                this.provider.switchToNextProvider(chainId);
            }
            const processTime = Date.now() - start;
            if (processTime < this.intervalSec[chainId] * 1000) {
                await scheduler.wait(this.intervalSec[chainId] * 1000 - processTime);
            }
        }
    };

    public isBootstrapping(): boolean {
        return Object.values(this.bootstrapStatus).some((v) => v);
    }

    public async fetchBlocks(chainId: number): Promise<void> {
        const currentBlock = await this.provider.getBlockHeight(chainId);
        const toBlock = currentBlock;
        let currentFromBlock = this.fromBlock[chainId] - this.blockRangeSize[chainId];
        let leftBlocks = toBlock - currentFromBlock;

        if (leftBlocks < 1) {
            return;
        }
        this.logger.log(`${networkName(chainId)}: Start sync from block ${currentFromBlock} to ${toBlock}`);

        let currentToBlock: number;
        while (true) {
            if (leftBlocks > this.maxBatchSize[chainId]) {
                currentToBlock = currentFromBlock + this.maxBatchSize[chainId];
            } else {
                currentToBlock = toBlock;
            }
            const events = await this.getEvents(chainId, currentFromBlock, currentToBlock);
            if ((this.provider.WMasListeningEnabled && chainId === Networks.BSC) || chainId === Networks.BSC_Testnet) {
                events.push(...(await this.getWmasEvents(chainId, currentFromBlock, currentToBlock)));
            }

            await this.processEvents(chainId, events, currentBlock);

            // update global fromBlock
            this.fromBlock[chainId] = currentToBlock + 1;

            if (leftBlocks <= this.maxBatchSize[chainId]) {
                // all blocks have been processed
                break;
            }
            currentFromBlock += this.maxBatchSize[chainId];
            leftBlocks -= this.maxBatchSize[chainId];
        }
    }

    public getBridgeTopics(): string[] {
        const intf = new utils.Interface(bridgeVaultAbi);
        return Object.values(bridgeEvents).map((event) => intf.getEventTopic(event));
    }

    public getWmasTopics(): string[] {
        return [this.provider.WMASContract.interface.getEventTopic(wmasEvents.Burn)];
    }

    public async getEvents(chainId: number, fromBlock: number, toBlock: number): Promise<ethers.providers.Log[]> {
        const filter = {
            address: [this.provider.vaultContracts[chainId].address],
            fromBlock: `0x${fromBlock.toString(16)}`,
            toBlock: `0x${toBlock.toString(16)}`,
            topics: [this.getBridgeTopics()],
        };
        return this.provider.send(chainId, 'eth_getLogs', [filter]);
    }

    public async getWmasEvents(chainId: number, fromBlock: number, toBlock: number): Promise<ethers.providers.Log[]> {
        const filter = {
            address: this.provider.WMASContract.address,
            fromBlock: `0x${fromBlock.toString(16)}`,
            toBlock: `0x${toBlock.toString(16)}`,
            topics: this.getWmasTopics(),
        };
        return this.provider.signers[chainId].provider.getLogs(filter);
    }

    public parseLog(event: ethers.providers.Log): any {
        const emitterContract = utils.getAddress(event.address);

        let intf: utils.Interface;

        if (emitterContract === this.provider.WMASContract?.address) {
            intf = this.provider.WMASContract.interface;
        } else {
            intf = new utils.Interface(bridgeVaultAbi);
        }
        return intf.parseLog(event);
    }

    public async processEvents(chainId: number, events: ethers.providers.Log[], currentBlock: number): Promise<void> {
        for (const event of events) {
            const blockNumber = isHexadecimal(event.blockNumber)
                ? parseInt(event.blockNumber as any, 16)
                : event.blockNumber;

            const confirmations = currentBlock - blockNumber;

            const eventLog = this.parseLog(event);
            const eventName = eventLog.name;

            try {
                switch (eventName) {
                    case bridgeEvents.Locked:
                        await this.eventHandler.handleLockEvent(
                            chainId,
                            eventLog.args.sender,
                            eventLog.args.token,
                            eventLog.args.massaAddress,
                            eventLog.args.amount,
                            eventLog.args.lockedAmount,
                            event,
                            confirmations,
                        );
                        break;
                    case bridgeEvents.OwnershipTransferred:
                        this.logger.log(`${eventName} event! new owner is ${eventLog.args.newOwner}`);
                        if (confirmations < ALERT_CONFIRMATIONS_TRESHOLD) {
                            await this.alertsService.triggerAlert(
                                'OwnershipTransferred',
                                `Ownership transferred to ${eventLog.args.newOwner}. see: https://www.notion.so/massa-innoteam/Human-intervention-procedures-a21f69b9d2e64084a3292f59c1e121b3?pvs=4#452a5522d64848d59c0d5000200d52a2`,
                                'critical',
                                true,
                            );
                        }
                        break;
                    case bridgeEvents.SignerAdded:
                        this.logger.log(`${eventName} event! new signer is ${eventLog.args.signer}`);
                        if (confirmations < ALERT_CONFIRMATIONS_TRESHOLD) {
                            await this.alertsService.triggerAlert(
                                'SignerAdded',
                                `New signer added: ${eventLog.args.signer}. see: https://www.notion.so/massa-innoteam/Human-intervention-procedures-a21f69b9d2e64084a3292f59c1e121b3?pvs=4#7378d104a8ff4201af053146babf669d`,
                                'critical',
                                true,
                            );
                        }
                        break;
                    case bridgeEvents.SignerRemoved:
                        this.logger.log(`${eventName} event! signer removed: ${eventLog.args.signer}`);
                        if (confirmations < ALERT_CONFIRMATIONS_TRESHOLD) {
                            await this.alertsService.triggerAlert(
                                'SignerRemoved',
                                `Signer removed: ${eventLog.args.signer}. see: https://www.notion.so/massa-innoteam/Human-intervention-procedures-a21f69b9d2e64084a3292f59c1e121b3?pvs=4#5b2ee080d2b54ba89898acac4071e65e`,
                                'critical',
                                true,
                            );
                            this.logger.log(`Add supported token event! new token: ${eventLog.args.token}.`);
                            break;
                        }
                    case bridgeEvents.Paused:
                        this.logger.log(`${eventName} event!`);
                        if (confirmations < ALERT_CONFIRMATIONS_TRESHOLD) {
                            await this.alertsService.triggerAlert(
                                'BridgePaused',
                                `Bridge paused. see: https://www.notion.so/massa-innoteam/Human-intervention-procedures-a21f69b9d2e64084a3292f59c1e121b3?pvs=4#3ff97ee5280e44e09b598b1a2a2cbf32`,
                                'critical',
                                true,
                            );
                        }
                    case bridgeEvents.Unpaused:
                        this.logger.log(`${eventName} event!`);
                        if (confirmations < ALERT_CONFIRMATIONS_TRESHOLD) {
                            await this.alertsService.triggerAlert(
                                'BridgeUnpaused',
                                `Bridge unpaused. see: https://www.notion.so/massa-innoteam/Human-intervention-procedures-a21f69b9d2e64084a3292f59c1e121b3?pvs=4#f8e8f0367c8e4fa194340826fc14f397`,
                                'critical',
                                true,
                            );
                        }
                    case bridgeEvents.TokenAdded:
                        this.logger.log(`Add supported token event! new token: ${eventLog.args.token}.`);
                        break;
                    case bridgeEvents.TokenRemoved:
                        this.logger.log(`Remove supported token event! removed token: ${eventLog.args.token}.`);
                        break;
                    case bridgeEvents.Redeemed:
                        await this.eventHandler.handleRedeemEvent(
                            chainId,
                            eventLog.args.burnOpId,
                            eventLog.args.amount,
                            event,
                            confirmations,
                        );
                        break;
                    case wmasEvents.Burn:
                        await this.eventHandler.handleBurnEvent(
                            chainId,
                            eventLog.args.account,
                            eventLog.args.massaAddress,
                            eventLog.args.amount,
                            event,
                            confirmations,
                        );
                        break;
                    default:
                        throw new Error(`Unknown bridge event ${eventName}`);
                }
            } catch (err) {
                this.logger.debug(
                    `Unable to process event log ${event.logIndex} of block ${blockNumber}: ${err.toString()}`,
                );
                continue;
            }
        }
    }
}
