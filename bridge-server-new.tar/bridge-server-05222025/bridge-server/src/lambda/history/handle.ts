import { DataSource } from 'typeorm';
import { getConfig } from '../../database/config';
import { Entities, HistoryRequest, HistoryResponse } from './interface';
import { validateEntities, validateInputLogIdx, validateRequestParams, validateState } from './validation';
import { fetchBurnRedeem } from './burn';
import { fetchLockMint } from './lock';
import { fetchReleaseMAS } from './release';
import { mergeOperations, readEntities } from './utils';

export let dataSource: DataSource;

export const handle = async (request: HistoryRequest): Promise<HistoryResponse> => {
    if (!validateRequestParams(request)) {
        return { statusCode: 400, body: 'invalid request params' };
    }
    // Read the parameters
    let entities = readEntities(request.entities);
    if (entities) {
        if (entities && !validateEntities(entities)) {
            return { statusCode: 400, body: 'invalid entities query parameter' };
        }
    } else {
        entities = Object.values(Entities);
    }
    const states = request.state;
    if (states) {
        if (states && !validateState(states)) {
            return { statusCode: 400, body: 'invalid state query parameter' };
        }
    }

    if (!validateInputLogIdx(request.inputLogIdx)) {
        return { statusCode: 400, body: 'inputLogIdx must be a number' };
    }

    // Initialize the data source
    if (!dataSource) {
        dataSource = new DataSource(await getConfig());
    }
    if (!dataSource.isInitialized) {
        await dataSource.initialize();
    }

    // Fetch the data
    let locked = [];
    let burned = [];
    let releasedMAS = [];

    if (entities && entities.includes(Entities.Lock)) {
        locked = await fetchLockMint(request);
    }

    if (entities && entities.includes(Entities.Burn)) {
        burned = await fetchBurnRedeem(request);
    }

    if (entities && entities.includes(Entities.ReleaseMAS)) {
        releasedMAS = await fetchReleaseMAS(request);
    }

    // Prepare the output
    return {
        statusCode: 200,
        body: mergeOperations(burned, locked, releasedMAS),
    };
};
