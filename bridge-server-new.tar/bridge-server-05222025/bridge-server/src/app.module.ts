import { Module } from '@nestjs/common';
import { ScheduleModule } from '@nestjs/schedule';
import { DatabaseModule } from './database/database.module';
import { EvmListenerModule } from './evm-listener/evm-listener.module';
import { MassaListenerModule } from './massa-listener/massa-listener.module';
import { MetricsModule } from './metrics/metrics.module';

@Module({
    imports: [ScheduleModule.forRoot(), EvmListenerModule, DatabaseModule, MassaListenerModule, MetricsModule],
    controllers: [],
    providers: [],
})
export class AppModule {}
