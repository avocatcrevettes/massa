#!/bin/bash

# Check if the user provided an ID and a mode
if [ ! $# -eq 2 ]; then
    echo "Usage: $0 <service_id> <mode>"
    echo "Available modes are 'prod' or 'bsc'"
    echo "Example: $0 1 prod"
    exit 1
fi

if [ -z "$NVM_DIR" ]; then
    echo "Error: NVM is not set up!"
    exit 1
fi

mode=$2

if [ $mode != "prod" ] && [ $mode != "bsc" ]; then
    echo "Error: Mode must be either 'prod' or 'bsc'"
    exit 1
fi

service_id=$1

# Define the template for the systemd service
service_template="[Unit]
Description=Massa Bridge relayer - $service_id
After=network.target

[Service]
WorkingDirectory=$PWD
Environment=APP_ENV=$mode NODE_VERSION=18.16.0
Type=simple
User=$USER
ExecStart=$NVM_DIR/nvm-exec npm start
Restart=on-failure

[Install]
WantedBy=multi-user.target
"

# Define the path to the systemd services directory
services_dir="/lib/systemd/system/"

# Generate a unique service file name based on the provided ID
service_file="bridge-relayer-${service_id}-${mode}.service"

# Check if the service file already exists
if [ -e "${services_dir}${service_file}" ]; then
    echo "Error: Service file already exists!"
    exit 1
fi

# Create the service file with the template and user-provided ID
echo "$service_template" | sudo tee "${services_dir}${service_file}" >/dev/null

sudo systemctl enable $service_file

# Reload systemd to pick up the new service
sudo systemctl daemon-reload

echo "New relayer service '${service_file}' has been created."
echo "You can now start the service using: sudo systemctl start ${service_file}"
