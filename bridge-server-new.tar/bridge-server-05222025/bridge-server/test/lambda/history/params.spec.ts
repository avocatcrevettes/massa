import { HistoryRequest, HistoryResponse } from 'src/lambda/history/interface';
import { handle } from '../../../src/lambda/history/handle';

import seed, { evmAddress } from './seed';

describe('lambda/history params', () => {
    beforeAll(async () => {
        await seed();
    });

    test('reject invalid params', async () => {
        let result: HistoryResponse;
        result = await handle({
            invalid: 'params',
        } as HistoryRequest);
        expect(result.statusCode).toBe(400);
        result = await handle({
            invalid: 'params',
            other: 'other',
            evmAddress,
        } as HistoryRequest);
        expect(result.statusCode).toBe(400);
        expect(result.body).toBe('invalid request params');
    });
});
