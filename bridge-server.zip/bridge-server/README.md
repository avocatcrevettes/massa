# Bridge Server

## Testing

To run tests, install libcrypto.so.1.1 from here:

    wget http://security.ubuntu.com/ubuntu/pool/main/o/openssl/libssl1.1_1.1.1f-1ubuntu2.19_amd64.deb
    sudo dpkg -i libssl1.1_1.1.1f-1ubuntu2.19_amd64.deb

## Setup

`cp .env/dev.env.example .env/dev.env`

## SAM Deployments

SAM templates are available to deploy the stack containing:
- DocumentDB
- API
- Lambda

It does not deploy the EC2 instance with the bridge backend for now.

### Prerequisites:

- Have an AWS IAM account
- Have AWS CLI installed: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
- Configure your credentials: `aws configure`
- Have AWS SAM CLI installed: https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html

### Steps:

1. Build the lambda:

```shell
npm install
npm run build-lambda
```

2. If you updated the templates, validate them:

```shell
sam validate --template=template.yaml
sam validate --template=template_documentdb.yaml
sam validate --template=template_lambda_api.yaml
```

Note: `template_documentdb.yaml` and `template_lambda_api.yaml` are split in case it is needed to deploy them independantly.
You should use `template.yaml` if you can.

3. Test the SAM template locally:

```shell
sam local invoke BridgeGetHistoryTest --template=template.yaml
sam local generate-event --template=template.yaml
sam local start-api BridgeGetHistoryTest --template=template.yaml
sam local start-lambda BridgeGetHistoryTest --template=template.yaml
```

4. If you're satisfied by your tests, deploy the stack:

```shell
sam deploy --guided --template=template.yaml --stack-name bridge-get-history-test-stack --parameter-overrides ClusterUser=BridgeTestClusterUser ClusterPassword=BridgeTestClusterPwd ClusterName=BridgeTestCluster
```

It will ask you: (* = change if needed)
- The stack name [bridge-get-history-test-stack]: *
- AWS Region [eu-west-3]: *
- The parameter values (ClusterUser, ClusterPassword, ClusterName): *
- Confirm changes before deploy [Y/n]: y
- Allow SAM CLI IAM role creation [Y/n]: y
- Disable rollback [y/N]: n
- Save arguments to configuration file [Y/n]: n
- Deploy this changeset? [y/N]: y

5. Test the lambda, the api, and everything

6. Destroy a stack if needed:
```shell
aws cloudformation delete-stack --stack-name bridge-get-history-test-stack
```