module.exports = {
    testEnvironment: 'node',
    bail: true,
    verbose: true,
    transform: {
        '^.+\\.tsx?$': 'ts-jest',
    },
    testMatch: ['**/*.spec.ts'],
    moduleFileExtensions: ['js', 'json', 'ts'],
    setupFilesAfterEnv: ['<rootDir>/test/setup.ts'],
    collectCoverageFrom: ['./src/**/*.ts'],
    coverageDirectory: '../coverage',
};
