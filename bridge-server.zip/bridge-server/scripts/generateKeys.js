#!/usr/bin/env node
/* eslint @typescript-eslint/no-var-requires: 0 */

const { ethers } = require('ethers');
const { SigningKey } = require('ethers/lib/utils');
const wallet = ethers.Wallet.createRandom();
const keys = new SigningKey(wallet.privateKey);
console.log('\x1b[36m%s\x1b[0m', 'New wallet generated. Keep it safe!');
console.log('\x1b[33m%s\x1b[0m', 'address: ', wallet.address);
console.log('\x1b[33m%s\x1b[0m', 'mnemonic: ', wallet.mnemonic.phrase);
console.log('\x1b[33m%s\x1b[0m', 'publicKey: ', keys.publicKey);
console.log('\x1b[33m%s\x1b[0m', 'privateKey: ', keys.privateKey);
