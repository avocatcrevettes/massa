import { ethers } from 'ethers';
import { config as envConfig } from 'dotenv';
import massaWeb3 from '@massalabs/massa-web3';

// load environment variables
// edit the path to the .env file if needed
envConfig({ path: '.env/prod.env' });

const config = {
    version: 0,
    // mainnet
    evmChainId: 1,
    // sepolia
    // evmChainId: 11155111,
    withdrawingContract: 'AS1mSSpfmgcngprb1LXiBXLQHGBasdbouRT9STSHtGCc5pfkrB6Y',
    // Damir
    recipient: 'AU16RffH3AAiNbkt84rMxTRqxQbcGZChtzJkModA3UXPiD6yJ5xr',
};

if (!process.env.MASSA_JSON_RPC) {
    throw new Error('MASSA_JSON_RPC is not set');
}
if (!process.env.MASSA_BRIDGE_ADMIN_PK) {
    throw new Error('MASSA_BRIDGE_ADMIN_PK is not set');
}

const account = await massaWeb3.WalletClient.getAccountFromSecretKey(process.env.MASSA_BRIDGE_ADMIN_PK);
const massaClient = await massaWeb3.ClientFactory.createDefaultClient(
    process.env.MASSA_JSON_RPC,
    massaWeb3.CHAIN_ID.MainNet,
    true,
    account,
);

const res = await massaClient.smartContracts().readSmartContract({
    maxGas: 3294167295n,
    targetAddress: config.withdrawingContract,
    targetFunction: 'lockedAmount',
    parameter: [],
});
const lockedAmount = massaWeb3.bytesToU64(res.returnValue);

const wallet = new ethers.Wallet(process.env.EVM_RELAYER_PK);
console.log('\x1b[36m%s\x1b[0m', `Using signer wallet ${wallet.address}`);
console.log('\x1b[36m%s\x1b[0m', `Withdrawing from contract ${config.withdrawingContract}`);
console.log('\x1b[36m%s\x1b[0m', `Amount: ${massaWeb3.toMAS(lockedAmount)} MAS`);
console.log('\x1b[36m%s\x1b[0m', `Recipient ${config.recipient}\n`);

// signature without version
const message = [
    // ...massaWeb3.u8toByte(config.version),
    ...massaWeb3.strToBytes('manualRelease'),
    ...massaWeb3.u32ToBytes(0),
    ...massaWeb3.strToBytes(config.recipient),
    ...massaWeb3.u64ToBytes(lockedAmount),
    ...massaWeb3.u64ToBytes(BigInt(config.evmChainId)),
];

const signature = await wallet.signMessage(message);
console.log('\x1b[33m%s\x1b[0m', `Signature: ${signature}`);
