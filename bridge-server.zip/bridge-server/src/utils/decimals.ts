/* eslint-disable tsdoc/syntax */
import { ethers } from 'ethers';

/**
 * Convert a n decimals string to a readable unit string
 * @example for 3 decs "1050" gives "1.05"
 * @param decs number
 * @param amount string
 * @returns Readable unit string
 */
export const toReadable = (amount: ethers.BigNumber | bigint | string, decs: number): string =>
    ethers.utils.formatUnits(amount.toString(), decs);

/**
 * Convert evm amount with n decimals to massa amount with n decimals. (rounding floors)
 *
 * @param amount evm amount
 * @param evmDecs evm decimals
 * @param massaDecs massa decimals
 * @returns massa amount
 */
export const toMassAmount = (evmAmount: ethers.BigNumber, evmDecs: number, massaDecs: number): bigint => {
    const amount = evmAmount.toString().substring(0, evmAmount.toString().length + massaDecs - evmDecs);
    return amount.length ? BigInt(amount) : 0n;
};
