import { isDev } from '../config';
import path from 'path';
import { DataSourceOptions } from 'typeorm';
import { LockMintEntity, BurnRedeemEntity, ReleaseMASEntity } from './entities';
import { MongoConnectionOptions } from 'typeorm/driver/mongodb/MongoConnectionOptions';

export let mongoMemory;

export const getConfig = async (): Promise<DataSourceOptions> => {
    const dataSource = getDataSource();

    const isTest = process.env.NODE_ENV === 'test';
    if (isTest) {
        if (!mongoMemory) {
            const { MongoMemoryServer } = await import('mongodb-memory-server');

            mongoMemory = await MongoMemoryServer.create({
                binary: { version: '5.0.0' },
            });
        }
        (dataSource as any).url = mongoMemory.getUri();
    }
    return dataSource;
};

export const getDataSource = (): MongoConnectionOptions => {
    const isLambda = !!process.env._HANDLER;
    const useLocalDb = !isLambda && (isDev() || process.env.DB_HOST === 'localhost');

    let certFile: string;
    if (isLambda) {
        certFile = 'ca.pem';
    } else {
        certFile = path.resolve(__dirname, '..', '..', 'ca.pem');
    }

    const host = process.env.DB_HOST;
    const username = process.env.DB_USER;
    const password = process.env.DB_PASSWORD;

    return {
        type: 'mongodb',
        host,
        port: 27017,
        readPreference: 'secondaryPreferred',
        retryWrites: false,
        username,
        password,
        replicaSet: useLocalDb ? undefined : 'rs0',
        ssl: !useLocalDb,
        sslCA: useLocalDb ? undefined : certFile,
        entities: [LockMintEntity, BurnRedeemEntity, ReleaseMASEntity],
        synchronize: process.env.DB_SYNC === 'true',
        url: undefined,
    };
};
