import { MigrationInterface, QueryRunner } from 'typeorm';
import { BridgingState, BurnRedeemEntity } from '../../entities';
import { ethers } from 'ethers';
import { signRedeemRequest } from '../../../massa-client/multisig-utils';
import { ObjectId } from 'mongodb';
import { loadConfig } from '../../../config';

loadConfig(`${__dirname}/../../../../.env`);

export class PostV2Migration1721632761958 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        if (!process.env.EVM_RELAYER_PK) {
            throw new Error('EVM_RELAYER_PK is not set');
        }
        const wallet = new ethers.Wallet(process.env.EVM_RELAYER_PK);
        console.log('Relayer address:', await wallet.getAddress());
        const relayerId = 0; // AvocatCrevette
        console.log('Relayer Id:', relayerId);

        const redeemRepository = queryRunner.manager.getMongoRepository(BurnRedeemEntity);

        // get pending claims before migration
        const migrationTimestamp = 1721131200;

        const entities = await redeemRepository.find({
            where: {
                _id: {
                    $lte: ObjectId.createFromTime(migrationTimestamp),
                },
                outputTxId: null,
                state: BridgingState.processing,
            },
        });

        console.log(`Found ${entities.length} pending redeem entries`);
        for (const entity of entities) {
            console.log(`Processing entry ${entity.inputOpId} ${entity.inputOpId}`);

            const newSignature = await signRedeemRequest(
                wallet,
                entity.amount,
                entity.inputOpId,
                entity.ercToken,
                entity.outputAddr,
                entity.destinationNetwork,
            );

            const damirOldRelayerId = 1;
            const damirSig = entity.signatures.find((s) => s.relayerId === damirOldRelayerId).signature;
            const sreOldRelayerId = 2;
            const sreSig = entity.signatures.find((s) => s.relayerId === sreOldRelayerId).signature;

            const signatures = [
                {
                    relayerId: 2,
                    signature: damirSig,
                },
                {
                    relayerId: 3,
                    signature: sreSig,
                },
                {
                    relayerId,
                    signature: newSignature,
                },
            ];
            await redeemRepository.findOneAndUpdate(
                { inputOpId: entity.inputOpId },
                {
                    $set: { signatures },
                },
            );
        }
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars,@typescript-eslint/no-empty-function
    public async down(queryRunner: QueryRunner): Promise<void> {}
}
