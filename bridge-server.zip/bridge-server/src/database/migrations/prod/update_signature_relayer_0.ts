import { MigrationInterface, QueryRunner } from 'typeorm';
import { ethers } from 'ethers';
import { BridgingState, BurnRedeemEntity } from '../../entities';
import { signRedeemRequest } from '../../../massa-client/multisig-utils';
import { loadConfig } from '../../../config';

loadConfig(`${__dirname}/../../../../.env`);

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
const relayerId = 0;

// eslint-disable-next-line camelcase
export class UpdateSignatureRelayer_0_1715874132310 implements MigrationInterface {
    public async up(queryRunner: QueryRunner): Promise<void> {
        if (!process.env.EVM_RELAYER_PK) {
            throw new Error('EVM_RELAYER_PK is not set');
        }
        const wallet = new ethers.Wallet(process.env.EVM_RELAYER_PK);
        console.log('Relayer address:', await wallet.getAddress());
        console.log('Relayer id:', relayerId);

        const redeemRepository = queryRunner.manager.getMongoRepository(BurnRedeemEntity);

        // get pending claims
        const entities = await redeemRepository.find({
            where: {
                outputTxId: null,
                state: BridgingState.processing,
            },
        });

        console.log(`Found ${entities.length} pending redeem entries`);
        for (const entity of entities) {
            console.log(`Processing entry ${entity.inputOpId}`);

            const newSignature = await signRedeemRequest(
                wallet,
                entity.amount,
                entity.inputOpId,
                entity.ercToken,
                entity.outputAddr,
                entity.destinationNetwork,
            );

            const signatures = entity.signatures
                .filter((s) => !!s?.signature)
                .map((s) => {
                    if (s.relayerId === relayerId) {
                        s.signature = newSignature;
                    }
                    return s;
                });
            await redeemRepository.findOneAndUpdate(
                { inputOpId: entity.inputOpId },
                {
                    $set: { signatures },
                },
            );
        }
    }

    // eslint-disable-next-line @typescript-eslint/no-unused-vars,@typescript-eslint/no-empty-function
    public async down(queryRunner: QueryRunner): Promise<void> {}
}
