import { Module } from '@nestjs/common';
import { TypeOrmModule, TypeOrmModuleOptions } from '@nestjs/typeorm';
import { LockMintEntity, BurnRedeemEntity, ReleaseMASEntity } from './entities';
import { DatabaseService } from './database.service';
import { getConfig } from './config';

@Module({
    imports: [
        TypeOrmModule.forRootAsync({ useFactory: async (): Promise<TypeOrmModuleOptions> => getConfig() }),
        TypeOrmModule.forFeature([LockMintEntity, BurnRedeemEntity, ReleaseMASEntity]),
    ],
    providers: [DatabaseService],
    exports: [DatabaseService],
})
export class DatabaseModule {}
