import { BurnRedeemEntity } from './burnRedeem.entity';
import { LockMintEntity } from './lockmint.entity';
import { ReleaseMASEntity } from './releaseMAS.entity';

export const isSignedByRelayer = (
    entity: LockMintEntity | BurnRedeemEntity | ReleaseMASEntity,
    relayerId: number,
): boolean => {
    return !!entity.signatures && entity.signatures.some((s) => s?.relayerId === relayerId);
};

export enum BridgingState {
    new = 'new',
    processing = 'processing',
    done = 'done',
    error = 'error',
    finalizing = 'finalizing',
}

export type Signature = { relayerId: number; signature: string };
