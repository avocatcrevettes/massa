import { BridgeError } from '../../utils/errors';
import { Entity, Column, BaseEntity, ObjectIdColumn, ObjectId } from 'typeorm';
import { BridgingState, Signature } from './utils';

export const burnRedeemEntityName = 'burn_redeem_entity';

@Entity({ name: burnRedeemEntityName })
export class BurnRedeemEntity extends BaseEntity {
    @ObjectIdColumn() id: ObjectId;

    @Column() inputAddr: string;
    @Column() inputOpId: string;

    @Column() outputAddr: string;
    @Column() outputTxId: string;
    @Column() outputConfirmations: number;

    @Column() amount: string;
    @Column() outputAmount: string;

    @Column() ercToken: string;
    @Column() massaToken: string;

    @Column() signatures: Signature[] = [];

    @Column() state: BridgingState = BridgingState.new;

    @Column() destinationNetwork: number;

    @Column() error: BridgeError;
}
