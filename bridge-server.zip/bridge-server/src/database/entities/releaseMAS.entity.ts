import { BridgeError } from '../../utils/errors';
import { Entity, Column, BaseEntity, ObjectIdColumn, ObjectId } from 'typeorm';
import { BridgingState, Signature } from './utils';

export const releaseMASEntityName = 'release_mas_entity';

@Entity({ name: releaseMASEntityName })
export class ReleaseMASEntity extends BaseEntity {
    @ObjectIdColumn()
    id: ObjectId;

    @Column()
    inputAddr: string;
    @Column() inputTxId: string;
    @Column() inputLogIdx: number;
    @Column() inputConfirmations: number;

    @Column() outputAddr: string;
    @Column() outputOpId: string;
    @Column()
    outputIsFinal = false;

    @Column() amount: string;

    @Column() signatures: Signature[] = [];

    @Column()
    state: BridgingState = BridgingState.new;
    @Column() originNetwork: number;

    @Column() error: BridgeError;
}
