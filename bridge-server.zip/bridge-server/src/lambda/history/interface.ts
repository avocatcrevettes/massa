import { BridgingState } from '../../database/entities';
import { BridgeError } from '../../utils/errors';

// Request interfaces

export interface HistoryRequest {
    evmAddress?: string;
    massaAddress?: string;
    entities?: string;
    inputTxId?: string;
    inputLogIdx?: string;
    inputOpId?: string;
    state?: string;
}

export enum Entities {
    Burn = 'burn',
    Lock = 'lock',
    ReleaseMAS = 'releaseMAS',
}

// Response interfaces

export enum HistoryOperationStatus {
    Claimable = 'claimable',
    Pending = 'pending',
    Done = 'done',
    Error = 'error',
    Unknown = 'unknown',
}

export enum SIDE {
    MASSA_TO_EVM = 'massaToEvm',
    EVM_TO_MASSA = 'evmToMassa',
}

export interface OperationHistoryItem {
    entity: Entities;
    emitter: string;
    createdAt: string;
    amount: string;
    outputAmount?: string;
    recipient: string;
    historyStatus: HistoryOperationStatus;
    serverState: BridgingState;
    outputId?: string;
    signatures?: string[];
    inputId: string;
    inputLogIdx?: number;
    evmChainId: number;
    massaToken?: string;
    evmToken?: string;
    confirmations?: number;
    isConfirmed: boolean;
    error?: BridgeError;
}

export interface HistoryResponse {
    statusCode: number;
    body: string | OperationHistoryItem[];
}
