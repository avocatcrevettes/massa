import { Entities, HistoryOperationStatus, HistoryRequest, OperationHistoryItem } from './interface';
import { BridgingState, ReleaseMASEntity } from '../../database/entities';
import { getFilterEvmToMassa } from './utils';
import { BridgeError } from '../../utils/errors';
import { dataSource } from './handle';

export async function fetchReleaseMAS(request: HistoryRequest): Promise<OperationHistoryItem[]> {
    const releaseMASRepository = dataSource.getMongoRepository(ReleaseMASEntity);

    const releaseMAS = await releaseMASRepository.find({
        where: getFilterEvmToMassa(request),
    });

    return releaseMAS.map(
        (releaseMAS): OperationHistoryItem => ({
            entity: Entities.ReleaseMAS,
            emitter: releaseMAS.inputAddr,
            inputId: releaseMAS.inputTxId,
            inputLogIdx: releaseMAS.inputLogIdx,
            amount: releaseMAS.amount,
            recipient: releaseMAS.outputAddr,
            outputId: releaseMAS.outputOpId,
            isConfirmed: releaseMAS.outputIsFinal,
            historyStatus: getReleaseMASHistoryStatus(releaseMAS.error, releaseMAS.state),
            serverState: releaseMAS.state,
            evmChainId: releaseMAS.originNetwork,
            error: releaseMAS.error,
            createdAt: releaseMAS.id.getTimestamp().toISOString(),
        }),
    );
}

function getReleaseMASHistoryStatus(error: BridgeError, state: string): HistoryOperationStatus {
    if (state === BridgingState.finalizing || state === BridgingState.done) {
        return HistoryOperationStatus.Done;
    }
    if (state === BridgingState.processing || state === BridgingState.new) {
        return HistoryOperationStatus.Pending;
    }
    if (error !== null || state === BridgingState.error) {
        return HistoryOperationStatus.Error;
    }
    return HistoryOperationStatus.Unknown;
}
