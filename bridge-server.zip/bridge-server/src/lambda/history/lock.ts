import { Entities, HistoryOperationStatus, HistoryRequest, OperationHistoryItem } from './interface';
import { BridgingState, LockMintEntity } from '../../database/entities';
import { getFilterEvmToMassa } from './utils';
import { BridgeError } from '../../utils/errors';
import { dataSource } from './handle';

export async function fetchLockMint(request: HistoryRequest): Promise<OperationHistoryItem[]> {
    const lockMintRepository = dataSource.getMongoRepository(LockMintEntity);

    const lockMints = await lockMintRepository.find({
        where: getFilterEvmToMassa(request),
    });

    return lockMints.map(
        (lockMint): OperationHistoryItem => ({
            entity: Entities.Lock,
            emitter: lockMint.inputAddr,
            inputId: lockMint.inputTxId,
            inputLogIdx: lockMint.inputLogIdx,
            amount: lockMint.amount,
            outputAmount: lockMint.outputAmount ?? lockMint.outputOpId ? lockMint.amount : null,
            evmToken: lockMint.ercToken,
            massaToken: lockMint.massaToken,
            recipient: lockMint.outputAddr,
            evmChainId: lockMint.originNetwork,
            outputId: lockMint.outputOpId,
            isConfirmed: lockMint.outputIsFinal,
            historyStatus: getLockHistoryStatus(lockMint.error, lockMint.state),
            serverState: lockMint.state,
            error: lockMint.error,
            createdAt: lockMint.id.getTimestamp().toISOString(),
        }),
    );
}

function getLockHistoryStatus(error: BridgeError, state: string): HistoryOperationStatus {
    if (state === BridgingState.finalizing || state === BridgingState.done) {
        return HistoryOperationStatus.Done;
    }
    if (state === BridgingState.processing || state === BridgingState.new) {
        return HistoryOperationStatus.Pending;
    }
    if (error !== null || state === BridgingState.error) {
        return HistoryOperationStatus.Error;
    }
    return HistoryOperationStatus.Unknown;
}
