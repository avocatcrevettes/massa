import { BridgingState } from '../../database/entities';
import { Entities, HistoryRequest } from './interface';

export function validateRequestParams(request: HistoryRequest): boolean {
    const allowedKeys = ['evmAddress', 'massaAddress', 'entities', 'inputTxId', 'inputLogIdx', 'inputOpId', 'state'];
    return Object.keys(request).every((key) => allowedKeys.includes(key));
}

export function validateEntities(entities: string[]): boolean {
    return entities.every((entity) => Object.values(Entities).includes(entity as Entities));
}

export function validateInputLogIdx(inputLogIdx?: string): boolean {
    return inputLogIdx ? !isNaN(Number(inputLogIdx)) : true;
}

export function validateState(state?: string): boolean {
    return Object.values(BridgingState).includes(state as BridgingState);
}
