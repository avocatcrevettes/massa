import { Signature } from '../../database/entities';
import { Networks } from '../../evm-http-provider/networks';
import { HistoryOperationStatus, HistoryRequest, OperationHistoryItem } from './interface';

export const requiredConfirmations = {
    [Networks.Mainnet]: 5,
    [Networks.Sepolia]: 5,
    [Networks.BSC]: 10,
    [Networks.BSC_Testnet]: 10,
};

export function readEntities(entities?: string): string[] | undefined {
    if (!entities) return undefined;
    return entities.split(',');
}

export const getFilterMassaToEvm = (request: HistoryRequest) => {
    const massaAddress = request.massaAddress;
    const evmAddress = request.evmAddress;
    const states = request.state;

    let filter = [];
    if (evmAddress) {
        filter.push({ outputAddr: evmAddress });
    }
    if (massaAddress) {
        filter.push({ inputAddr: massaAddress });
    }
    if (states) {
        filter.push({ state: states });
    }
    filter = filter.concat(getInputTxAndOpFilter(request));

    if (!filter.length) return {};

    return filter.reduce((acc, curr) => {
        return { ...acc, ...curr };
    });
};

export const getFilterEvmToMassa = (request: HistoryRequest) => {
    const evmAddress = request.evmAddress;
    const massaAddress = request.massaAddress;
    const states = request.state;

    let filter = [];
    if (evmAddress) {
        filter.push({ inputAddr: evmAddress });
    }
    if (massaAddress) {
        filter.push({ outputAddr: massaAddress });
    }
    if (states) {
        filter.push({ state: states });
    }
    filter = filter.concat(getInputTxAndOpFilter(request));

    if (!filter.length) return {};

    return filter.reduce((acc, curr) => {
        return { ...acc, ...curr };
    });
};

const getInputTxAndOpFilter = (request: HistoryRequest) => {
    const inputTxId = request.inputTxId;
    const inputLogIdx = request.inputLogIdx;
    const inputOpId = request.inputOpId;

    const filter = [];
    if (inputTxId) {
        const query: { inputTxId: string; inputLogIdx?: number } = { inputTxId };
        if (inputLogIdx) {
            query.inputLogIdx = Number(inputLogIdx);
        }
        filter.push(query);
    }
    if (inputOpId) {
        filter.push({ inputOpId });
    }

    return filter;
};

export function mergeOperations(
    burn: OperationHistoryItem[],
    lock: OperationHistoryItem[],
    releaseMAS: OperationHistoryItem[],
): OperationHistoryItem[] {
    return [...burn, ...lock, ...releaseMAS]
        .sort((a, b) => {
            return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        })
        .sort((a, b) =>
            a.historyStatus === HistoryOperationStatus.Pending && b.historyStatus !== HistoryOperationStatus.Pending
                ? -1
                : a.historyStatus !== HistoryOperationStatus.Pending &&
                  b.historyStatus === HistoryOperationStatus.Pending
                ? 1
                : 0,
        );
}

export function prepareSignatures(signatures: Signature[]): string[] {
    return signatures.sort((a, b) => a.relayerId - b.relayerId).map((s) => s.signature);
}
