import { Module } from '@nestjs/common';
import { MassaClientModule } from '../massa-client/massa-client.module';
import { MassaListenerService } from './massa-listener.service';
import { EvmHttpProviderModule } from '../evm-http-provider/evm-http-provider.module';
import { DatabaseModule } from '../database/database.module';

@Module({
    imports: [MassaClientModule, DatabaseModule, EvmHttpProviderModule],
    controllers: [],
    providers: [MassaListenerService],
})
export class MassaListenerModule {}
