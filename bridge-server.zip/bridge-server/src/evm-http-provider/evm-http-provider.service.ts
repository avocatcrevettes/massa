import { Injectable, Logger } from '@nestjs/common';
import { BigNumber, ethers } from 'ethers';
import { TransactionResponse } from '@ethersproject/abstract-provider';
import { WMasAbi, bridgeVaultAbi } from '../contracts';
import { NonceManager } from '@ethersproject/experimental';
import { toReadable } from '../utils/decimals';
import WithProviderFallback from './with-provider-fallback.decorator';
import { BurnRedeemEntity } from '../database/entities';
import { AlertsService } from '../alerts/alerts.service';
import { Networks } from './networks';

@Injectable()
export class EvmHttpProviderService {
    // active provider with signer wallet
    public signers: Record<number, NonceManager> = {};
    // all available rpc providers
    private providers: Record<number, ethers.providers.StaticJsonRpcProvider[]> = {};

    // index of the currently active provider
    private activeProviderIdx: Record<number, number> = {};

    public currentBlockNum: Record<number, number> = {};

    public enabledNetworks: number[] = [];

    public vaultContracts: Record<number, ethers.Contract> = {};
    public WMASContract?: ethers.Contract;

    public WMasListeningEnabled: boolean;

    public relayerId: number;
    public multisigThreshold: number;

    public lastRPCErrorTimestamp: Record<number, number> = {};

    public tokensSymbol: Record<string, string> = {};
    public tokensDecimals: Record<string, number> = {};

    public readonly logger = new Logger('evm-client');

    constructor(public readonly alertsService: AlertsService) {}

    public async onModuleInit(): Promise<void> {
        this.WMasListeningEnabled = !!process.env.WMAS_CONTRACT;
        this.logger.log(`WMAS contract listening enabled: ${this.WMasListeningEnabled}`);

        await this.initializeProviders();

        for (const chainId of this.enabledNetworks) {
            const relayerAddr = await this.signers[chainId].getAddress();
            // check that the current relayer is registered on the EVM contract

            const relayerId = await this.getRelayerIdFromAddress(chainId, relayerAddr);
            if (relayerId === -1) {
                throw new Error(
                    'Relayer address does not match any of the relayers addresses on EVM contract for chainId ' +
                        chainId,
                );
            }
            // check that relayerId is the same on all chains
            if (this.relayerId && this.relayerId !== relayerId) {
                throw new Error('Relayer id missmatch between contracts');
            }
            this.relayerId = relayerId;

            // check that multisigTrehsold is the same on all chains
            const multisigThreshold = await this.getMultisigThreshold(chainId);
            if (this.multisigThreshold && this.multisigThreshold !== multisigThreshold) {
                throw new Error('multisig threshold missmatch between contracts');
            }
            this.multisigThreshold = multisigThreshold;

            if (this.WMasListeningEnabled && (chainId === Networks.BSC_Testnet || chainId === Networks.BSC)) {
                const totalSupply = await this.getWMasSupply(chainId);
                this.logger.log(`WMAS total supply: ${toReadable(totalSupply, 9)}`);
            }

            this.lastRPCErrorTimestamp[chainId] = 0;
        }
    }

    private async initializeProviders(): Promise<void> {
        let networkIdx = 0;
        while (process.env[`EVM_RPCS_${networkIdx}`]) {
            const rpcUrls: string[] = JSON.parse(process.env[`EVM_RPCS_${networkIdx}`]);
            const providers = await Promise.all(
                rpcUrls.map(async (rpcUrl) => {
                    const provider = new ethers.providers.StaticJsonRpcProvider(rpcUrl);
                    await provider.detectNetwork();
                    return provider;
                }),
            );

            const chainId = providers[0].network.chainId;
            if (!providers.every((provider) => provider.network.chainId === chainId)) {
                throw new Error(`All providers of network ${networkIdx} must be on the same network`);
            }

            this.providers[chainId] = providers;
            this.activeProviderIdx[chainId] = 0;
            this.enabledNetworks.push(chainId);
            this.initProvider(chainId, networkIdx);

            networkIdx++;
        }
        if (!networkIdx) {
            throw new Error('No JSON RPC URLs provided in environment variables');
        }
    }

    private initProvider(chainId: number, networkIdx?: number): void {
        const provider = this.providers[chainId][this.activeProviderIdx[chainId]];
        this.signers[chainId] = new NonceManager(new ethers.Wallet(process.env.EVM_RELAYER_PK, provider));

        const contractAddr =
            networkIdx !== undefined
                ? process.env[`EVM_VAULT_CONTRACT_${networkIdx}`]
                : this.vaultContracts[chainId].address;
        if (!contractAddr) {
            throw new Error(`No Evm contract address provided for network ${networkIdx}`);
        }
        this.vaultContracts[chainId] = new ethers.Contract(contractAddr, bridgeVaultAbi, this.signers[chainId]);

        if (this.WMasListeningEnabled && (chainId === Networks.BSC || chainId === Networks.BSC_Testnet)) {
            this.WMASContract = new ethers.Contract(process.env.WMAS_CONTRACT, WMasAbi, this.signers[chainId]);
        }
    }

    public switchToNextProvider(chainId: number): void {
        this.activeProviderIdx[chainId] = (this.activeProviderIdx[chainId] + 1) % this.providers[chainId].length;
        this.logger.log(`Switching to provider ${this.activeProviderIdx[chainId]}`);
        this.initProvider(chainId);
    }

    @WithProviderFallback()
    public async gasPrice(chainId: number): Promise<ethers.BigNumber> {
        return this.signers[chainId].getGasPrice();
    }

    @WithProviderFallback()
    public async getBlockHeight(chainId: number): Promise<number> {
        const blockNumber = await this.signers[chainId].provider.getBlockNumber();
        if (isNaN(blockNumber) || blockNumber < 0) {
            throw new Error(`Invalid response from the RPC provider. blockNumber returned : ${blockNumber}`);
        }
        this.currentBlockNum[chainId] = blockNumber;
        return blockNumber;
    }

    @WithProviderFallback()
    public async getVaultBalance(chainId: number, token: string, blockNumber?: number): Promise<ethers.BigNumber> {
        const contract = new ethers.Contract(
            token,
            ['function balanceOf(address) view returns (uint256)'],
            this.signers[chainId],
        );
        const blockTag = blockNumber ?? 'latest';
        return contract.balanceOf(this.vaultContracts[chainId].address, {
            blockTag,
        });
    }

    @WithProviderFallback()
    public async send(chainId: number, method: string, params: any[]): Promise<any> {
        const provider = this.signers[chainId].provider as ethers.providers.StaticJsonRpcProvider;
        return provider.send(method, params);
    }

    @WithProviderFallback()
    public async getTransaction(chainId: number, txHash: string): Promise<ethers.providers.TransactionResponse> {
        return this.signers[chainId].provider.getTransaction(txHash);
    }

    @WithProviderFallback()
    public async getBalance(chainId: number, address: string): Promise<ethers.BigNumber> {
        return this.signers[chainId].getBalance(address);
    }

    @WithProviderFallback()
    public async redeem(chainId: number, burnRedeem: BurnRedeemEntity): Promise<TransactionResponse> {
        const { amount, outputAddr, inputOpId, ercToken, signatures } = burnRedeem;
        const signaturesParam = signatures.map((s) => s.signature);
        const gasEstimation = await this.vaultContracts[chainId].estimateGas.redeem(
            amount,
            outputAddr,
            inputOpId,
            ercToken,
            signaturesParam,
        );
        const gasPrice = await this.gasPrice(chainId);
        this.logger.log(`Redeem gas fee estimation: ${toReadable(gasEstimation.mul(gasPrice), 18)} ETH`);
        const redeemTx = await this.vaultContracts[chainId].redeem(
            amount,
            outputAddr,
            inputOpId,
            ercToken,
            signaturesParam,
        );

        const symbol = await this.getTokenSymbol(chainId, ercToken);
        const decimals = await this.getTokenDecimals(chainId, ercToken);

        this.logger.log(`Redeemed: ${toReadable(BigInt(amount), decimals)} ${symbol}`);
        return redeemTx;
    }

    @WithProviderFallback()
    public async getTokenSymbol(chainId: number, token: string): Promise<string> {
        if (this.tokensSymbol[token]) {
            return this.tokensSymbol[token];
        }
        const contract = new ethers.Contract(token, ['function symbol() view returns (string)'], this.signers[chainId]);
        const symbol = await contract.symbol();
        this.tokensSymbol = { ...this.tokensSymbol, [token]: symbol };

        return symbol;
    }

    @WithProviderFallback()
    public async getTokenDecimals(chainId: number, token: string): Promise<number> {
        if (this.tokensDecimals[token]) {
            return this.tokensDecimals[token];
        }
        const contract = new ethers.Contract(
            token,
            ['function decimals() view returns (uint8)'],
            this.signers[chainId],
        );
        const decs = await contract.decimals();

        this.tokensDecimals = { ...this.tokensDecimals, [token]: decs };
        return decs;
    }

    @WithProviderFallback()
    public async getRelayers(chainId: number): Promise<string[]> {
        return this.vaultContracts[chainId].getSigners();
    }

    private async getRelayerIdFromAddress(chainId: number, relayerAddr: string): Promise<number> {
        const relayersAddresses = await this.getRelayers(chainId);
        return relayersAddresses.findIndex((addr) => addr === relayerAddr);
    }

    @WithProviderFallback()
    public async getWMasSupply(chainId: number): Promise<bigint> {
        const contract = new ethers.Contract(
            this.WMASContract.address,
            ['function totalSupply() view returns (uint256)'],
            this.signers[chainId],
        );
        const totalSupply = await contract.totalSupply();
        return totalSupply.toBigInt();
    }

    @WithProviderFallback()
    private async getMultisigThreshold(chainId: number): Promise<number> {
        const threshold: BigNumber = await this.vaultContracts[chainId].k();
        return threshold.toNumber();
    }
}
