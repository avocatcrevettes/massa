import { Module } from '@nestjs/common';
import { EvmHttpProviderService } from './evm-http-provider.service';
import { AlertsModule } from '../alerts/alerts.module';

@Module({
    imports: [AlertsModule],
    controllers: [],
    providers: [EvmHttpProviderService],
    exports: [EvmHttpProviderService],
})
export class EvmHttpProviderModule {}
