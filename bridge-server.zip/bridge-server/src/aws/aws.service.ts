import { Injectable, Logger } from '@nestjs/common';
import { CloudWatchClient, PutMetricDataCommand } from '@aws-sdk/client-cloudwatch';
import { AwsCredentialIdentity } from '@aws-sdk/types';

const NAMESPACE = 'Bridge';

@Injectable()
export class AWSService {
    private readonly logger = new Logger('AWS');
    public client: CloudWatchClient;

    private isActivated = false;

    constructor() {
        this.isActivated = process.env.ENABLE_METRICS === 'true';
        if (this.isActivated) {
            this.logger.log(`AWS service is activated.`);
            if (!process.env.AWS_REGION) {
                throw new Error('AWS_REGION not set');
            }
            if (!process.env.METRICS_NETWORK) {
                throw new Error('METRICS_NETWORK not set');
            }
            if (process.env.AWS_NEEDS_AUTH === 'true') {
                if (!process.env.ACCESS_KEY_ID) {
                    throw new Error('ACCESS_KEY_ID not set but AWS_NEEDS_AUTH is set to true');
                }
                if (!process.env.SECRET_ACCESS_KEY) {
                    throw new Error('SECRET_ACCESS_KEY not set but AWS_NEEDS_AUTH is set to true');
                }
                const credentials: AwsCredentialIdentity = {
                    accessKeyId: process.env.ACCESS_KEY_ID,
                    secretAccessKey: process.env.SECRET_ACCESS_KEY,
                };
                this.client = new CloudWatchClient({ region: process.env.AWS_REGION, credentials });
            } else {
                this.client = new CloudWatchClient({ region: process.env.AWS_REGION });
            }
        }
    }

    public async publishMetric(metricName: string, val: number): Promise<void> {
        if (this.isActivated) {
            this.logger.debug(`Sending AWS ${metricName} metrics...`);
            const command = new PutMetricDataCommand({
                Namespace: NAMESPACE,
                MetricData: [
                    {
                        MetricName: metricName,
                        Dimensions: [
                            {
                                Name: `Network`,
                                Value: process.env.METRICS_NETWORK,
                            },
                        ],
                        Value: val,
                    },
                ],
            });
            try {
                await this.client.send(command);
            } catch (err) {
                this.logger.error('AWS metrics error:' + JSON.stringify(err));
                console.error(err);
            }
        }
    }
}
