import { strToBytes, u256ToBytes, u32ToBytes, u64ToBytes, u8toByte } from '@massalabs/massa-web3';
import { BurnRedeemEntity, LockMintEntity, ReleaseMASEntity, Signature } from '../database/entities';
import { SIGNATURE_BYTE_LEN } from './mint.service';
import { Wallet, ethers } from 'ethers';
import { NonceManager } from '@ethersproject/experimental';

export const SIGNATURE_VERSION = 0;

export const packSignatures = (signatures: Signature[]): Uint8Array => {
    const packed = new Uint8Array(signatures.length * SIGNATURE_BYTE_LEN);

    signatures
        .sort((a, b) => a.relayerId - b.relayerId)
        .map((s, idx) => {
            packed.set(Buffer.from(s.signature, 'hex'), idx * SIGNATURE_BYTE_LEN);
        });

    return packed;
};

export const multisigThresholdReached = (
    entity: LockMintEntity | ReleaseMASEntity | BurnRedeemEntity,
    threshold: number,
): boolean => {
    return entity.signatures && entity.signatures.length >= threshold;
};

export const signMintRequest = async (
    wallet: Wallet | NonceManager,
    inputTxId: string,
    inputLogIdx: number,
    outputAddr: string,
    amount: string,
    massaToken: string,
): Promise<string> => {
    const message = [
        ...u8toByte(SIGNATURE_VERSION),
        ...strToBytes(inputTxId),
        ...u32ToBytes(inputLogIdx),
        ...strToBytes(outputAddr),
        ...u256ToBytes(BigInt(amount)),
        ...strToBytes(massaToken),
    ];
    const signature = await wallet.signMessage(message);
    // remove 0x prefix
    return signature.substring(2);
};

export const signReleaseRequest = async (
    wallet: Wallet | NonceManager,
    inputTxId: string,
    inputLogIdx: number,
    outputAddr: string,
    amount: string,
    chainId: number,
): Promise<string> => {
    const message = [
        ...u8toByte(SIGNATURE_VERSION),
        ...strToBytes(inputTxId),
        ...u32ToBytes(inputLogIdx),
        ...strToBytes(outputAddr),
        ...u64ToBytes(BigInt(amount)),
        ...u64ToBytes(BigInt(chainId)),
    ];
    const signature = await wallet.signMessage(message);
    // remove 0x prefix
    return signature.substring(2);
};

export const signRedeemRequest = async (
    wallet: Wallet | NonceManager,
    amount: string,
    inputOpId: string,
    evmToken: string,
    outputAddr: string,
    chainId: number,
): Promise<string> => {
    const hashString = ethers.utils.solidityKeccak256(
        ['uint8', 'uint256', 'address', 'string', 'address', 'uint256'],
        [SIGNATURE_VERSION, amount, outputAddr, inputOpId, evmToken, chainId],
    );
    const hashBytes = ethers.utils.arrayify(hashString);
    return wallet.signMessage(hashBytes);
};
