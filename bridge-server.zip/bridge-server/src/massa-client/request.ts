import { Args, IDeserializedResult, ISerializable } from '@massalabs/massa-web3';

export class TokenPair implements ISerializable<TokenPair> {
    constructor(public massaToken = '', public evmToken = '', public chainId = 0) {}

    serialize(): Uint8Array {
        const args = new Args();
        args.addString(this.massaToken);
        args.addString(this.evmToken);
        args.addU64(BigInt(this.chainId));
        return new Uint8Array(args.serialize());
    }

    deserialize(data: Uint8Array, offset: number): IDeserializedResult<TokenPair> {
        const args = new Args(data, offset);
        this.massaToken = args.nextString();
        this.evmToken = args.nextString();
        this.chainId = Number(args.nextU64());
        return { instance: this, offset: args.getOffset() };
    }
}

export class ForwardingRequest implements ISerializable<ForwardingRequest> {
    opId = '';
    caller = '';

    constructor(
        public amount = '',
        public receiver = '',
        public logIdx = 0,
        public tokenPair = new TokenPair('', '', 0),
        public signatures = new Uint8Array(),
    ) {}

    serialize(): Uint8Array {
        const args = new Args();
        args.addU256(BigInt(this.amount));
        args.addString(this.caller);
        args.addString(this.receiver);
        args.addString(this.opId);
        args.addU32(this.logIdx);
        args.addSerializable(this.tokenPair);
        args.addUint8Array(this.signatures);
        return new Uint8Array(args.serialize());
    }

    deserialize(data: Uint8Array, offset: number): IDeserializedResult<ForwardingRequest> {
        const args = new Args(data, offset);
        this.amount = args.nextU256().toString();
        this.caller = args.nextString();
        this.receiver = args.nextString();
        this.opId = args.nextString();
        this.logIdx = args.nextU32();
        this.tokenPair = args.nextSerializable(TokenPair);
        this.signatures = args.nextUint8Array();
        return { instance: this, offset: args.getOffset() };
    }
}

export class ReleaseRequest implements ISerializable<ReleaseRequest> {
    constructor(
        public amount = '',
        public receiver = '',
        public txId = '',
        public logIdx = 0,
        public signatures = new Uint8Array(),
        public chainId = 0,
    ) {}

    public serialize(): Uint8Array {
        const args = new Args();
        args.addU64(BigInt(this.amount));
        args.addString(this.receiver);
        args.addString(this.txId);
        args.addU32(this.logIdx);
        args.addUint8Array(this.signatures);
        args.addU64(BigInt(this.chainId));
        return new Uint8Array(args.serialize());
    }

    deserialize(data: Uint8Array, offset: number): IDeserializedResult<ReleaseRequest> {
        const args = new Args(data, offset);
        this.amount = args.nextU64().toString();
        this.receiver = args.nextString();
        this.txId = args.nextString();
        this.logIdx = args.nextU32();
        this.signatures = args.nextUint8Array();
        this.chainId = Number(args.nextU64());
        return { instance: this, offset: args.getOffset() };
    }
}

export enum RequestStatus {
    Unknown = 0,
    Done = 1,
    Refunded = 2,
}
