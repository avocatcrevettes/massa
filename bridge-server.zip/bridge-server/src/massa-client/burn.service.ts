import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { MassaClientService } from './massa-client.service';
import { BridgingState } from '../database/entities';
import { BridgeError, Codes } from '../utils/errors';
import { Cron, CronExpression } from '@nestjs/schedule';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';
import { MassaOperationsService } from './massa-operations.service';
import { Args, ArrayTypes } from '@massalabs/massa-web3';
import { multisigThresholdReached } from './multisig-utils';

const MAX_OPID_TO_DELETE = 50;

@Injectable()
export class BurnService {
    private readonly logger = new Logger('Burn');

    constructor(
        protected readonly massaClient: MassaClientService,
        protected readonly massaOperations: MassaOperationsService,
        protected readonly db: DatabaseService,
        protected readonly evmProvider: EvmHttpProviderService,
    ) {}

    @Cron(CronExpression.EVERY_MINUTE)
    public async deleteBurnLog(): Promise<void> {
        const burnRedeems = await this.db.getBurnRedeems({ state: BridgingState.processing });

        if (!burnRedeems.length) {
            return;
        }

        const burnLogs = await this.massaClient.getBurnList();

        const opIdstoDelete = [];
        for (const burnRedeem of burnRedeems) {
            try {
                const { inputOpId, outputTxId, outputConfirmations } = burnRedeem;

                if (!multisigThresholdReached(burnRedeem, this.massaClient.multisigThreshold)) {
                    // this should not happen. Delete mechanism should only deals with signed burnRedeem
                    this.logger.error(`Not enough signatures collected for ${inputOpId}. Skipping delete`);
                    continue;
                }

                const reqConfirmations = parseInt(process.env.EVM_MIN_CONFIRMATIONS);

                if (!outputTxId || outputConfirmations < reqConfirmations) {
                    // Redeem not done or not yet confirmed. Skip
                    continue;
                }

                const matchingLog = burnLogs.some((item) => item.opId === inputOpId);

                if (!matchingLog) {
                    this.logger.log(`Log for burn ${inputOpId} already deleted. Set state to done`);
                    await this.db.updateBurnRedeem(inputOpId, BridgingState.processing, {
                        state: BridgingState.done,
                    });
                    continue;
                }

                try {
                    await this.db.updateBurnRedeem(inputOpId, BridgingState.processing, {
                        state: BridgingState.finalizing,
                    });
                } catch (err) {
                    // failed to lock state. Skip
                    continue;
                }

                opIdstoDelete.push(inputOpId);
                if (opIdstoDelete.length >= MAX_OPID_TO_DELETE) {
                    break;
                }
            } catch (err) {
                this.logger.error(`Unable to process burnRedeem ${burnRedeem.inputOpId}.`, err.toString());
                continue;
            }

            if (!opIdstoDelete.length) {
                return;
            }

            this.logger.log(`Deleting ${opIdstoDelete.length} burnlogs`);

            try {
                const deleteOpId = await this.deleteBurnRequests(opIdstoDelete);
                await this.massaOperations.waitFinalOperation(deleteOpId);
                await this.db.updateManyBurnRedeems(opIdstoDelete, { state: BridgingState.done });
            } catch (err) {
                // delete operation failed... retry next time
                this.logger.error(`Unable to delete burnRedeems ${opIdstoDelete.join(', ')}`, err.toString());
                await this.db.updateManyBurnRedeems(opIdstoDelete, { state: BridgingState.processing });
                return;
            }
        }
    }

    public async deleteBurnRequests(opIds: string[]): Promise<string> {
        this.logger.log(`Deleting burn requests: ${opIds.join(', ')}`);
        try {
            const parameter = new Args().addArray(opIds, ArrayTypes.STRING).serialize();

            const maxGas = await this.massaOperations.getDynamicGasCost(
                this.massaClient.bridgeContract,
                'deleteBurnLogs',
                parameter,
            );

            const coins = this.massaOperations.getBridgeCoinsAmount();
            this.logger.debug(`Deleting burnlog for opIds ${opIds.join(', ')} maxGas: ${maxGas}`);

            return this.massaClient.client.smartContracts().callSmartContract({
                fee: this.massaOperations.defaultFee,
                maxGas,
                coins,
                targetAddress: this.massaClient.bridgeContract,
                targetFunction: 'deleteBurnLogs',
                parameter,
            });
        } catch (err) {
            this.logger.error(`Failed to submit burnlog delete for opIds ${opIds.join(', ')}`, err.toString());
            throw new BridgeError(
                Codes.MASSA_DELETE_BURN_REQUEST,
                `Operation Ids: ${opIds.join(', ')}: ${err.toString()}`,
            );
        }
    }
}
