import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { MassaClientService } from './massa-client.service';
import { BridgingState } from '../database/entities';
import { MassaOperationsService } from './massa-operations.service';
import { BridgeError, Codes } from '../utils/errors';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';

@Injectable()
export class ReleaseMASServiceInit {
    protected readonly logger = new Logger('ReleaseMasService');

    constructor(
        protected readonly massaClient: MassaClientService,
        protected readonly massaOperations: MassaOperationsService,
        protected readonly db: DatabaseService,
        protected readonly evmProvider: EvmHttpProviderService,
    ) {}

    public async onModuleInit(): Promise<void> {
        await this.processPending();
    }

    public async processPending(): Promise<void> {
        // at startup check if there are any pending releases
        const processing = await this.db.getReleases({ state: BridgingState.processing });

        if (!processing.length) {
            return;
        }

        this.logger.log(`Found ${processing.length} release in processing state at startup.`);

        for (const entity of processing) {
            const { inputTxId, inputLogIdx } = entity;
            await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.processing, {
                state: BridgingState.error,
                error: new BridgeError(
                    Codes.INTERRUPTED_PROCESSING,
                    'Release operation found in processing state at startup',
                ),
            });
        }
    }

    public isInReleaseList = (inputLockTxId: string, inputLockLogIdx: number): boolean => {
        return Object.keys(this.massaClient.releaseList).some((key) => key === `${inputLockTxId}${inputLockLogIdx}`);
    };
}
