import { Module } from '@nestjs/common';
import { MassaClientService } from './massa-client.service';
import { MintService } from './mint.service';
import { DatabaseModule } from '../database/database.module';
import { BurnService } from './burn.service';
import { EvmHttpProviderModule } from '../evm-http-provider/evm-http-provider.module';
import { MassaOperationsService } from './massa-operations.service';
import { ReleaseMasService } from './releaseMAS.service';

@Module({
    imports: [DatabaseModule, EvmHttpProviderModule],
    controllers: [],
    providers: [MassaClientService, MintService, BurnService, MassaOperationsService, ReleaseMasService],
    exports: [MassaClientService, MintService, BurnService, MassaOperationsService, ReleaseMasService],
})
export class MassaClientModule {}
