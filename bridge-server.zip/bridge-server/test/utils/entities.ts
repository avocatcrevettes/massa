import { randomInt } from 'crypto';
import { randomAddr, randomTokenPair, randomTxId } from './evm';
import { dbService } from '../setup';
import { LockMintEntity } from '../../src/database/entities';

export const insertNewLockMint = (confirmations = 0) => {
    const tokenPair = randomTokenPair();
    return dbService.addNewLockMint({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: randomAddr(),
        outputAddr: randomAddr(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: confirmations,
    });
};

export const updateLockMint = async (lockMintEntity: LockMintEntity, toUpdate: Partial<LockMintEntity>) => {
    return dbService.updateLockMintState(
        lockMintEntity.inputTxId,
        lockMintEntity.inputLogIdx,
        lockMintEntity.state,
        toUpdate,
    );
};
