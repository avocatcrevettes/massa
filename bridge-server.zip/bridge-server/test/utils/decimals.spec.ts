import { ethers } from 'ethers';
import { toMassAmount } from '../../src/utils/decimals';

describe('Amounts conversion', () => {
    describe('Evm to massa', () => {
        describe('18decs => 9 decs', () => {
            const evmDecs = 18;
            const massaDecs = 9;
            it('.', async () => {
                const input = ethers.BigNumber.from('5555555555555555123456789123456789');
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(5555555555555555123456789n);
            });
            it('..', async () => {
                const input = ethers.BigNumber.from('123456789');
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(0n);
            });
            it('...', async () => {
                const input = ethers.BigNumber.from('1123456789');
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(1n);
            });
            it('....', async () => {
                const input = ethers.BigNumber.from('123');
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(0n);
            });
            it('.....', async () => {
                const input = ethers.constants.Zero;
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(0n);
            });
        });

        describe('6decs => 6 decs', () => {
            const evmDecs = 6;
            const massaDecs = 6;
            it('.', async () => {
                const input = '5555555555555555123456789123456789';
                const inputBN = ethers.BigNumber.from(input);
                expect(toMassAmount(inputBN, evmDecs, massaDecs)).toEqual(BigInt(input));
            });
            it('..', async () => {
                const input = '123';
                const inputBN = ethers.BigNumber.from(input);
                expect(toMassAmount(inputBN, evmDecs, massaDecs)).toEqual(BigInt(input));
            });
            it('.....', async () => {
                const input = ethers.BigNumber.from('0');
                expect(toMassAmount(input, evmDecs, massaDecs)).toEqual(0n);
            });
        });
    });
});
