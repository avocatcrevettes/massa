import { randomBytes } from 'crypto';

export const randomOpId = (): string => {
    const randBytes = randomBytes(50);
    const randB64 = Buffer.from(randBytes.toString('hex')).toString('base64');
    return `O1${randB64}`.substring(0, randBytes[0] % 2 ? 50 : 51);
};

export const randomMassaContract = (): string => `AS${randomBytes(29).toString('hex')}`;
export const randomMassaAddress = (): string => `AU${randomBytes(29).toString('hex')}`;
