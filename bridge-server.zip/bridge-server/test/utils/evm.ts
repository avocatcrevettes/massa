import { ethers } from 'ethers';
import { randomBytes, randomInt } from 'crypto';
import { TokenPair } from '../../src/massa-client/request';
import { randomMassaContract } from './massa';
import { supportedNetworks } from '../mocks/evmProviderMock';

export const randomAddr = (): string => ethers.utils.getAddress(`0x${randomBytes(20).toString('hex')}`);
export const randomTxId = (): string => `0x${randomBytes(32).toString('hex')}`;
export const randomTokenPair = (): TokenPair =>
    new TokenPair(randomMassaContract(), randomAddr(), supportedNetworks[randomInt(supportedNetworks.length - 1)]);
