import { errors } from 'ethers';
import { evmHttpProviderServiceMock } from '../mocks/evmProviderMock';
import { evmHttpProviderService } from '../setup';

describe('WithProviderFallback Decorator', () => {
    it('should switch providers for chainId 1', async () => {
        const chainId = evmHttpProviderServiceMock.enabledNetworks[0];

        evmHttpProviderServiceMock.gasPriceMock = jest.fn().mockImplementationOnce(() => {
            const error: any = new Error('Server Error');
            error.code = errors.SERVER_ERROR;
            throw error;
        });

        expect((evmHttpProviderService as any).activeProviderIdx[chainId]).toEqual(0);
        await expect(evmHttpProviderService.gasPrice(chainId)).rejects.toThrow();
        expect((evmHttpProviderService as any).activeProviderIdx[chainId]).toEqual(1);
    });

    it('should switch providers for chainId 2', async () => {
        const chainId = evmHttpProviderServiceMock.enabledNetworks[1];

        evmHttpProviderServiceMock.gasPriceMock = jest.fn().mockImplementationOnce(() => {
            const error: any = new Error('Another server Error');
            error.code = errors.SERVER_ERROR;
            throw error;
        });

        expect((evmHttpProviderService as any).activeProviderIdx[chainId]).toEqual(0);
        await expect(evmHttpProviderService.gasPrice(chainId)).rejects.toThrow();
        expect((evmHttpProviderService as any).activeProviderIdx[chainId]).toEqual(1);
    });
});
