import { Test, TestingModule } from '@nestjs/testing';
import { ConsoleLogger, INestApplication } from '@nestjs/common';
import { AppModule } from '../src/app.module';
import { loadConfig } from '../src/config';
import { mongoMemory } from '../src/database/config';
import { EvmBlockParserService } from '../src/evm-listener/evm-block-parser.service';
import { MassaListenerService } from '../src/massa-listener/massa-listener.service';
import { MassaClientService } from '../src/massa-client/massa-client.service';
import { EvmEventHandlerService } from '../src/evm-listener/event-handler.service';
import { massaClientServiceMock } from './mocks/massaClientServiceMock';
import { EvmHttpProviderService } from '../src/evm-http-provider/evm-http-provider.service';
import { evmHttpProviderServiceMock } from './mocks/evmProviderMock';
import { MetricsService } from '../src/metrics/metrics.service';
import { DatabaseService } from '../src/database/database.service';
import { MintService } from '../src/massa-client/mint.service';
import { BurnService } from '../src/massa-client/burn.service';
import { MassaOperationsService } from '../src/massa-client/massa-operations.service';
import { massaOperationsServiceMock } from './mocks/massaOperationsMock';
import { ReleaseMasService } from '../src/massa-client/releaseMAS.service';

let app: INestApplication;

export let evmEventHandlerService: EvmEventHandlerService;
export let evmHttpProviderService: EvmHttpProviderService;
export let evmBlockParserService: EvmBlockParserService;
export let dbService: DatabaseService;
export let mintService: MintService;
export let burnService: BurnService;
export let releaseService: ReleaseMasService;
export let massaListenerService: MassaListenerService;
export let massaClientService: MassaClientService;
export let massaOperationsService: MassaOperationsService;

beforeAll(async () => {
    const envDir = `${__dirname}`;
    loadConfig(envDir);

    const moduleFixture: TestingModule = await Test.createTestingModule({
        imports: [AppModule],
    })
        .overrideProvider(MetricsService)
        .useValue({})
        .overrideProvider(MassaClientService)
        .useValue(massaClientServiceMock)
        .overrideProvider(MassaOperationsService)
        .useValue(massaOperationsServiceMock)
        .overrideProvider(EvmHttpProviderService)
        .useValue(evmHttpProviderServiceMock)
        .compile();

    app = moduleFixture.createNestApplication();
    app.useLogger(new ConsoleLogger());

    evmBlockParserService = app.get(EvmBlockParserService);
    jest.spyOn(evmBlockParserService, 'task').mockImplementation();

    evmEventHandlerService = app.get(EvmEventHandlerService);

    massaListenerService = app.get(MassaListenerService);
    jest.spyOn(massaListenerService, 'onApplicationBootstrap').mockImplementation();

    evmHttpProviderService = app.get(EvmHttpProviderService);

    massaClientService = app.get(MassaClientService);
    massaOperationsService = app.get(MassaOperationsService);
    mintService = app.get(MintService);
    burnService = app.get(BurnService);
    releaseService = app.get(ReleaseMasService);

    dbService = app.get(DatabaseService);
    jest.spyOn(dbService, 'onModuleInit').mockImplementation();

    await app.init();

    // Every test application will use the same database
    // pay attention to use different txIds/OpIds for each test
    await dbService.createCollectionIndexes();
});

afterAll(async () => mongoMemory.stop(), 10000);
