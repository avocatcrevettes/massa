import { BridgingState } from '../../../src/database/entities';
import { handle } from '../../../src/lambda/history/handle';
import { Entities, OperationHistoryItem } from '../../../src/lambda/history/interface';

import seed, { evmAddress, inputLogIdx1, inputLogIdx2, inputOpId, inputTxId1, inputTxId2, massaAddress } from './seed';

describe('lambda/history', () => {
    beforeAll(async () => {
        await seed();
    });

    test('get all', async () => {
        const result = await handle({});

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(8);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(7);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(9);
    });

    test('only lock entities', async () => {
        const result = await handle({
            entities: [Entities.Lock].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(8);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('only burn entities', async () => {
        const result = await handle({
            entities: [Entities.Burn].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(7);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('only releaseMAS', async () => {
        const result = await handle({
            entities: [Entities.ReleaseMAS].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(9);
    });

    test('request with evmAddress', async () => {
        const result = await handle({
            evmAddress,
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(4);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(4);
    });

    test('request with massaAddress', async () => {
        const result = await handle({
            massaAddress,
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(2);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(3);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(2);
    });

    test('request with evmAddress and massaAddress', async () => {
        const result = await handle({
            evmAddress,
            massaAddress,
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('only lock entities with massaAddress', async () => {
        const result = await handle({
            massaAddress,
            entities: [Entities.Lock].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(2);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('only burn entities with evmAddress', async () => {
        const result = await handle({
            evmAddress,
            entities: [Entities.Burn].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('only releaseMAS entities with massaAddress and evmAddress', async () => {
        const result = await handle({
            evmAddress,
            massaAddress,
            entities: [Entities.ReleaseMAS].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('must fail with invalid entity', async () => {
        const result = await handle({
            entities: ['not an entity'].join(','),
        });

        expect(result.statusCode).toBe(400);
        expect(result.body).toBe('invalid entities query parameter');
    });

    test('filter inputOpId', async () => {
        const result = await handle({
            inputOpId,
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('filter inputTxId alone', async () => {
        const result = await handle({
            inputTxId: inputTxId1,
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(1);
    });

    test('must fail with filter inputLogIdx not integer', async () => {
        const result = await handle({
            inputTxId: inputTxId2,
            inputLogIdx: 'not integer',
        });

        expect(result.statusCode).toBe(400);
        expect(result.body).toBe('inputLogIdx must be a number');
    });

    test('filter inputTxId1 and inputLogIdx1', async () => {
        const result = await handle({
            inputTxId: inputTxId1,
            inputLogIdx: inputLogIdx1.toString(),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(1);
    });

    test('filter inputTxId2 and inputLogIdx2', async () => {
        const result = await handle({
            inputTxId: inputTxId2,
            inputLogIdx: inputLogIdx2.toString(),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(1);
    });

    test('filter inputTxId 1 and inputLogIdx2', async () => {
        const result = await handle({
            inputTxId: inputTxId1,
            inputLogIdx: inputLogIdx2.toString(),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });

    test('must fail if state is invalid', async () => {
        const result = await handle({
            state: 'not a state',
        });

        expect(result.statusCode).toBe(400);
        expect(result.body).toBe('invalid state query parameter');
    });

    test('filter state', async () => {
        const result = await handle({
            state: BridgingState.processing,
            entities: [Entities.Burn].join(','),
        });

        expect(result.statusCode).toBe(200);
        const body = result.body as OperationHistoryItem[];
        expect(body.filter((op) => op.entity === Entities.Lock)).toHaveLength(0);
        expect(body.filter((op) => op.entity === Entities.Burn)).toHaveLength(1);
        expect(body.filter((op) => op.entity === Entities.ReleaseMAS)).toHaveLength(0);
    });
});
