import { BigNumber, ethers, Wallet } from 'ethers';
import WithProviderFallback from '../../src/evm-http-provider/with-provider-fallback.decorator';
import { randomTxId } from '../utils/evm';
import { NonceManager } from '@ethersproject/experimental';
import { bridgeVaultAbi, WMasAbi } from '../../src/contracts';
import { loadConfig } from '../../src/config';
import { Networks } from '../../src/evm-http-provider/networks';

export const redeemTxId = randomTxId();

export const supportedNetworks = [Networks.BSC, Networks.Mainnet];

export class EvmHttpProviderServiceMock {
    public signers: Record<string, NonceManager> = {};
    public vaultContracts: Record<string, ethers.Contract> = {};
    private activeProviderIdx: Record<string, number> = {};
    public lastRPCErrorTimestamp: Record<string, number> = {};

    public WMASContract: ethers.Contract;

    public enabledNetworks = supportedNetworks;

    constructor() {
        const envDir = `${__dirname}/..`;
        loadConfig(envDir);

        for (let idx = 0; idx < supportedNetworks.length; idx++) {
            const chainId = supportedNetworks[idx];
            this.signers[chainId] = new NonceManager(new Wallet(process.env.EVM_RELAYER_PK));
            this.vaultContracts[chainId] = new ethers.Contract(
                process.env[`EVM_VAULT_CONTRACT_${idx}`],
                bridgeVaultAbi,
            );
            this.activeProviderIdx[chainId] = 0;
            this.lastRPCErrorTimestamp[chainId] = 0;
        }

        this.WMASContract = new ethers.Contract(process.env.WMAS_CONTRACT, WMasAbi);
    }

    switchToNextProvider = (chainId: number) => {
        this.activeProviderIdx[chainId]++;
    };

    logger = {
        warn: (msg) => console.log('warn: ' + msg),
    };

    relayerId = 2;

    multisigThreshold = 2;

    gasPriceMock: jest.Mock;

    @WithProviderFallback()
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    gasPrice(chainId: number): Promise<BigNumber> {
        return this.gasPriceMock() as any;
    }

    getVaultBalance = jest.fn().mockReturnValue(BigNumber.from(99999));
    getTokenSymbol = jest.fn().mockReturnValue('TOK');
    getTokenDecimals = jest.fn().mockReturnValue(18);

    alertsService = {
        triggerAlert: jest.fn(),
    };
}

export const evmHttpProviderServiceMock = new EvmHttpProviderServiceMock();
