export const massaOperationsServiceMock = {
    waitFinalOperation: jest.fn(),
    getBridgeCoinsAmount: jest.fn().mockReturnValue(0n),
    getMasVaultCoinsAmount: jest.fn().mockReturnValue(0n),
    getDynamicGasCost: jest.fn().mockReturnValue(123456),
    getOperationStatus: jest.fn(),
};
