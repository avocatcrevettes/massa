import { EOperationStatus } from '@massalabs/massa-web3';
import { BridgingState, LockMintEntity } from '../../src/database/entities';
import { Codes, ErrorsTitles } from '../../src/utils/errors';
import { opId } from '../mocks/massaClientServiceMock';
import { dbService, massaOperationsService, mintService } from '../setup';
import { insertNewLockMint, updateLockMint } from '../utils/entities';
import { randomOpId } from '../utils/massa';
import waitForExpect from 'wait-for-expect';

describe('mint retry', () => {
    let lockMint: LockMintEntity;
    let mintWrappedAssetSpy: jest.SpyInstance;

    beforeEach(async () => {
        lockMint = await insertNewLockMint(3);
        await dbService.addMintSignature(lockMint, 0, 'signature1');
        await dbService.addMintSignature(lockMint, 1, 'signature2');
        await dbService.addMintSignature(lockMint, 2, 'signature3');

        mintWrappedAssetSpy = jest.spyOn(mintService, 'mintWrappedAsset');
        massaOperationsService.getOperationStatus = jest.fn().mockResolvedValueOnce(EOperationStatus.NOT_FOUND);
    });

    it('retry already minted (lockId is in SC list)', async () => {
        const outputOpId = randomOpId();
        await updateLockMint(lockMint, {
            state: BridgingState.error,
            error: {
                code: Codes.MASSA_OPERATION_EXPIRED,
                msg: 'zeMessage',
                title: ErrorsTitles[Codes.MASSA_OPERATION_EXPIRED],
            },
            outputOpId,
        });

        jest.spyOn(mintService, 'isInLockList').mockReturnValueOnce(true);

        await mintService.retryMint();

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId: lockMint.inputTxId,
                inputLogIdx: lockMint.inputLogIdx,
            });
            expect(elt[0].state).toEqual(BridgingState.done);
            expect(elt[0].outputOpId).toEqual(outputOpId);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(mintWrappedAssetSpy).not.toHaveBeenCalled();
        });
    });

    it('retry after mint operation failed for insuficient gas', async () => {
        await updateLockMint(lockMint, {
            state: BridgingState.error,
            error: {
                code: Codes.MASSA_INSUFFICIENT_GAS,
                msg: 'zeMessage',
                title: ErrorsTitles[Codes.MASSA_INSUFFICIENT_GAS],
            },
        });

        await mintService.retryMint();

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId: lockMint.inputTxId,
                inputLogIdx: lockMint.inputLogIdx,
            });
            expect(elt[0].state).toEqual(BridgingState.done);
            expect(elt[0].outputOpId).toEqual(opId);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(mintWrappedAssetSpy).toHaveBeenCalled();
        });
    });

    it('retry after mint operation expired', async () => {
        await updateLockMint(lockMint, {
            state: BridgingState.error,
            error: {
                code: Codes.MASSA_OPERATION_EXPIRED,
                msg: 'zeMessage',
                title: ErrorsTitles[Codes.MASSA_OPERATION_EXPIRED],
            },
            outputOpId: randomOpId(),
        });

        await mintService.retryMint();

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId: lockMint.inputTxId,
                inputLogIdx: lockMint.inputLogIdx,
            });
            expect(elt[0].state).toEqual(BridgingState.done);
            expect(elt[0].outputOpId).toEqual(opId);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(mintWrappedAssetSpy).toHaveBeenCalled();
        });
    });

    it('retry after mint submit failed', async () => {
        await updateLockMint(lockMint, {
            state: BridgingState.error,
            error: {
                code: Codes.MASSA_MINT_REQUEST,
                msg: 'zeMessage',
                title: ErrorsTitles[Codes.MASSA_MINT_REQUEST],
            },
        });

        await mintService.retryMint();

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId: lockMint.inputTxId,
                inputLogIdx: lockMint.inputLogIdx,
            });
            expect(elt[0].state).toEqual(BridgingState.done);
            expect(elt[0].outputOpId).toEqual(opId);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(mintWrappedAssetSpy).toHaveBeenCalled();
        });
    });

    it('retry INTERRUPTED_PROCESSING (found in processing state at startup)', async () => {
        await updateLockMint(lockMint, {
            state: BridgingState.error,
            error: {
                code: Codes.INTERRUPTED_PROCESSING,
                msg: 'zeMessage',
                title: ErrorsTitles[Codes.INTERRUPTED_PROCESSING],
            },
        });

        await mintService.retryMint();

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId: lockMint.inputTxId,
                inputLogIdx: lockMint.inputLogIdx,
            });
            expect(elt[0].state).toEqual(BridgingState.done);
            expect(elt[0].outputOpId).toEqual(opId);
            expect(elt[0].outputIsFinal).toBeTruthy();
        });
    });
});
