import { ethers } from 'ethers';
import { burnService, dbService, evmBlockParserService, evmHttpProviderService } from '../setup';
import { BridgingState } from '../../src/database/entities';
import { bridgeVaultAbi } from '../../src/contracts';
import { randomMassaAddress, randomOpId } from '../utils/massa';
import { ForwardingRequest, TokenPair } from '../../src/massa-client/request';
import { randomAddr, randomTokenPair } from '../utils/evm';
import { randomInt } from 'crypto';
import { massaClientServiceMock, smartContractsMock } from '../mocks/massaClientServiceMock';
import { Networks } from '../../src/evm-http-provider/networks';

describe('Redeem event handler', () => {
    const currentBlock = 4043325;

    const chainId = Networks.Mainnet;

    let redeemEvent: ethers.providers.Log;
    let recipient: string;
    let tokenPair: TokenPair;
    let burnOpId: string;
    let amount: string;
    let redeemedAmount: string;
    const inputAddr = randomMassaAddress();

    beforeEach(async () => {
        recipient = randomAddr();
        tokenPair = randomTokenPair();
        burnOpId = randomOpId();
        amount = randomInt(1000000).toString();
        redeemedAmount = randomInt(1000000).toString();

        // Generate redeem event from random inputs
        const intf = new ethers.utils.Interface(bridgeVaultAbi);
        const topics = intf.encodeEventLog('Redeemed', [recipient, tokenPair.evmToken, burnOpId, redeemedAmount]);
        redeemEvent = {
            address: evmHttpProviderService.vaultContracts[chainId].address,
            blockHash: '0x51592d26f5c53f93c6087cf9deb9e15515aa3de3de15816cc7bc8cf8f9c8c3b3',
            blockNumber: currentBlock.toString(16) as any,
            data: '',
            logIndex: 111,
            removed: false,
            transactionHash: '0xd11c91b78ebf59bf54c4d79fdc4df92116f50a807339f46e42cefc72c481d260',
            transactionIndex: '0x18' as any,
            topics: topics.topics,
            ...topics,
        };

        const entity = await dbService.addNewBurnRedeem({
            inputOpId: burnOpId,
            inputAddr,
            outputAddr: recipient,
            amount,
            ercToken: tokenPair.evmToken,
            massaToken: tokenPair.massaToken,
            destinationNetwork: chainId,
        });

        await dbService.addRedeemSignature(entity, 0, 'signature');
        await dbService.updateBurnRedeem(burnOpId, BridgingState.new, {
            state: BridgingState.processing,
        });
    });

    it('redeem event, 0 confirmations', async () => {
        await evmBlockParserService.processEvents(chainId, [redeemEvent], currentBlock);

        const elt = await dbService.getBurnRedeems({
            inputOpId: burnOpId,
        });

        expect(elt.length).toEqual(1);
        expect(elt[0].inputAddr).toEqual(inputAddr);
        expect(elt[0].inputOpId).toEqual(burnOpId);
        expect(elt[0].outputConfirmations).toEqual(0);
        expect(elt[0].outputAddr).toEqual(recipient);
        expect(elt[0].outputTxId).toEqual(redeemEvent.transactionHash);
        expect(elt[0].amount).toEqual(amount);
        expect(elt[0].outputAmount).toEqual(redeemedAmount);
        expect(elt[0].ercToken).toEqual(tokenPair.evmToken);
        expect(elt[0].massaToken).toEqual(tokenPair.massaToken);
        expect(elt[0].destinationNetwork).toEqual(chainId);
        expect(elt[0].state).toEqual(BridgingState.processing);
    });

    it('redeem event, 10 confirmations', async () => {
        const confirmations = 10;
        // Set threshold to 1 to process the burnlog deletion
        massaClientServiceMock.multisigThreshold = 1;

        await evmBlockParserService.processEvents(chainId, [redeemEvent], currentBlock + confirmations);

        let elt = await dbService.getBurnRedeems({
            inputOpId: burnOpId,
        });

        expect(elt.length).toEqual(1);
        expect(elt[0].inputAddr).toEqual(inputAddr);
        expect(elt[0].inputOpId).toEqual(burnOpId);
        expect(elt[0].outputConfirmations).toEqual(confirmations);
        expect(elt[0].outputAddr).toEqual(recipient);
        expect(elt[0].outputTxId).toEqual(redeemEvent.transactionHash);
        expect(elt[0].amount).toEqual(amount);
        expect(elt[0].outputAmount).toEqual(redeemedAmount);
        expect(elt[0].ercToken).toEqual(tokenPair.evmToken);
        expect(elt[0].massaToken).toEqual(tokenPair.massaToken);
        expect(elt[0].destinationNetwork).toEqual(chainId);
        expect(elt[0].state).toEqual(BridgingState.processing);

        // test that the burn is deleted
        const request = new ForwardingRequest(amount, recipient, 0, tokenPair);
        request.opId = burnOpId;
        request.caller = inputAddr;
        massaClientServiceMock.getBurnList.mockResolvedValueOnce([request]);

        await burnService.deleteBurnLog();

        elt = await dbService.getBurnRedeems({
            inputOpId: burnOpId,
        });

        expect(smartContractsMock.callSmartContract).toHaveBeenCalled();
        expect(elt[0].state).toEqual(BridgingState.done);
    });
});
