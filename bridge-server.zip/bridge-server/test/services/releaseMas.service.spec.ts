import { ethers } from 'ethers';
import { dbService, evmBlockParserService, evmEventHandlerService, evmHttpProviderService } from '../setup';
import { BridgingState, ReleaseMASEntity } from '../../src/database/entities';
import { randomAddr, randomTxId } from '../utils/evm';
import waitForExpect from 'wait-for-expect';
import { WMasAbi } from '../../src/contracts';
import { randomMassaAddress } from '../utils/massa';
import { SIGNATURE_BYTE_LEN } from '../../src/massa-client/mint.service';
import { massaClientServiceMock } from '../mocks/massaClientServiceMock';
import { massaOperationsServiceMock } from '../mocks/massaOperationsMock';
import { BridgeError, Codes } from '../../src/utils/errors';
import { Networks } from '../../src/evm-http-provider/networks';

describe('WMAS burn handler', () => {
    const currentBlock = 4043325;
    let event: ethers.providers.Log;
    const confirmations = 10;
    const chainId = Networks.BSC;
    const amount = 1234n * 10n ** 9n;
    let emitter: string;
    let massaRecipient: string;
    let inputTxId: string;
    let inputLogIdx: number;

    beforeAll(async () => {
        massaClientServiceMock.multisigThreshold = 3;
    });

    beforeEach(async () => {
        emitter = randomAddr();
        massaRecipient = randomMassaAddress();
        inputTxId = randomTxId();
        inputLogIdx = 123;
        // Generate burn event from random inputs
        const intf = new ethers.utils.Interface(WMasAbi);
        const topics = intf.encodeEventLog('Burn', [emitter, massaRecipient, amount.toString()]);

        event = {
            address: evmHttpProviderService.WMASContract.address,
            blockHash: '0xc41bb874a01bcc94df8fc96bd6595b810fd6669dbc99e921abde8c97caa525ad',
            blockNumber: currentBlock.toString(16) as any,
            data: '0x0000000000000000000000000000000000000000000000000000000000000040000000000000000000000000000000000000000000000006aaf7c8516d0c000000000000000000000000000000000000000000000000000000000000000000354155313236346e784336456659614b4c776455317a436f6679434b47766e55317677627139684e53516a4178725335743279596f650000000000000000000000',
            logIndex: inputLogIdx,
            removed: false,
            transactionHash: inputTxId,
            transactionIndex: 456,
            topics: topics.topics,
            ...topics,
        };
    });

    it('WMAS burn event, 0 confirmations', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock);

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);
        expect(elt[0].inputConfirmations).toEqual(0);
        expect(elt[0].state).toEqual(BridgingState.new);
        expect(elt[0].outputOpId).toBeNull();
        expect(elt[0].outputIsFinal).toBeFalsy();
        expect(elt[0].signatures.length).toEqual(0);
    });

    it('WMAS burn event, 10 confirmations. should add signature', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });
        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);
        expect(elt[0].inputConfirmations).toEqual(confirmations);
        expect(elt[0].signatures[0].signature).toEqual(
            await evmEventHandlerService.signReleaseRequest(
                inputTxId,
                inputLogIdx,
                massaRecipient,
                amount.toString(),
                chainId,
            ),
        );
        expect(elt[0].outputOpId).toBeNull();
        expect(elt[0].outputIsFinal).toBeFalsy();

        expect(elt[0].signatures[0].signature.length).toEqual(SIGNATURE_BYTE_LEN * 2);
        expect(elt[0].state).toEqual(BridgingState.new);
    });

    it('Should add 2 signatures', async () => {
        const relayers = [1, 2];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });

        validateEntityProps(elt[0]);

        const signatures = elt[0].signatures;

        expect(signatures.length).toEqual(2);
        expect(signatures.some((s) => s.relayerId === relayers[0])).toBeTruthy();
        expect(signatures.some((s) => s.relayerId === relayers[1])).toBeTruthy();

        const expectedSignature = await evmEventHandlerService.signReleaseRequest(
            inputTxId,
            inputLogIdx,
            massaRecipient,
            amount.toString(),
            chainId,
        );
        expect(signatures.every((s) => s.signature === expectedSignature)).toBeTruthy();
        expect(signatures.every((s) => s.signature.length === SIGNATURE_BYTE_LEN * relayers.length)).toBeTruthy();

        expect(elt[0].outputOpId).toBeNull();
        expect(elt[0].outputIsFinal).toBeFalsy();
    });

    it('Should add 3 signatureswith relayers 0,2,3', async () => {
        const relayers = [0, 2, 3];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            });

            validateEntityProps(elt[0]);

            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 3 signatures with relayers 0,1,3', async () => {
        const relayers = [0, 1, 3];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            });

            validateEntityProps(elt[0]);

            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 3 signatures with relayers 1,2,3', async () => {
        const relayers = [1, 2, 3];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            });

            validateEntityProps(elt[0]);

            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 4 signatures', async () => {
        const relayers = [0, 1, 2, 3];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });

        validateEntityProps(elt[0]);

        expect(elt[0].signatures.length).toEqual(relayers.length);
        expect(elt[0].outputIsFinal).toBeTruthy();
        expect(elt[0].state).toEqual(BridgingState.done);
    });

    it('receive twice same event (same relayer)', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock);
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + 1);

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(1);
        expect(elt[0].signatures.length).toEqual(0);
        expect(elt[0].state).toEqual(BridgingState.new);

        expect(
            await dbService.countReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            }),
        ).toEqual(1);

        expect(elt[0].outputOpId).toBeNull();
        expect(elt[0].outputIsFinal).toBeFalsy();
    });

    it('receive twice same confirmed event (same relayer)', async () => {
        const relayer2 = 2;
        massaClientServiceMock.relayerId = relayer2;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const elt = await dbService.getReleases({
            inputTxId: event.transactionHash,
            inputLogIdx: event.logIndex,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(confirmations);
        expect(elt[0].signatures.length).toEqual(1);
        expect(elt[0].state).toEqual(BridgingState.new);
        expect(elt[0].signatures[0].relayerId).toEqual(relayer2);

        expect(
            await dbService.countReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            }),
        ).toEqual(1);

        expect(elt[0].outputOpId).toBeNull();
        expect(elt[0].outputIsFinal).toBeFalsy();
    });

    it('Process release ', async () => {
        massaOperationsServiceMock.waitFinalOperation;

        const relayers = [0, 1, 2];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('operation timeout', async () => {
        const bridgeErr = new BridgeError(
            Codes.MASSA_OPERATION_EXPIRED,
            `Zisiis and error  😇 😇 😇
        .`,
        );

        massaOperationsServiceMock.waitFinalOperation.mockImplementationOnce(() => {
            throw bridgeErr;
        });

        const relayer1 = 0;
        massaClientServiceMock.relayerId = relayer1;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer2 = 1;
        massaClientServiceMock.relayerId = relayer2;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer3 = 2;
        massaClientServiceMock.relayerId = relayer3;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        await waitForExpect(async () => {
            const elt = await dbService.getReleases({
                inputTxId: event.transactionHash,
                inputLogIdx: event.logIndex,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].outputIsFinal).toBeFalsy();
            expect(elt[0].state).toEqual(BridgingState.error);
            expect(elt[0].error).toEqual(bridgeErr);

            const failed = await dbService.getFailedRelease();
            expect(failed.some((f) => f.inputTxId === event.transactionHash)).toBeTruthy();
        });
    });

    const validateEntityProps = (elt: ReleaseMASEntity) => {
        expect(elt.inputAddr).toEqual(emitter);
        expect(elt.inputTxId).toEqual(event.transactionHash);
        expect(elt.inputLogIdx).toEqual(event.logIndex);
        expect(elt.outputAddr).toEqual(massaRecipient);
        expect(elt.amount).toEqual(amount.toString());
        expect(elt.originNetwork).toEqual(chainId);
    };
});
