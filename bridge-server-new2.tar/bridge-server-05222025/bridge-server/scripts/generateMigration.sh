#!/bin/bash

echo "This script will generate a migration file for updating the relayer signatures in the database."

read -p "Enter a relayer ID (0, 1, or 2): " id

# Check if the entered ID is 0, 1, or 2
if [[ "$id" =~ ^[012]$ ]]; then
    if [[ -f "./src/database/migrations/prod/update_signature_relayer.ts" ]]; then
        sed -i "s/XXX/${id}/g" "./src/database/migrations/prod/update_signature_relayer.ts"
        echo "Migration file src/database/migrations/prod/update_signature_relayer.ts edited for relayer ${id}"
        echo "Once migration is done, you can revert the changes by running 'git checkout -- src/database/migrations/prod/update_signature_relayer.ts'"

    else
        echo "Migration script update_signature_relayer.ts does not exist."
    fi
else
    echo "Invalid relayer ID. Please enter 0, 1, or 2."
fi
