import waitForExpect from 'wait-for-expect';
import { LockMintEntity, BridgingState } from './../../src/database/entities';
import { dbService, mintService } from '../setup';
import { Codes } from '../../src/utils/errors';
import { insertNewLockMint, updateLockMint } from '../utils/entities';

describe('Mint init service', () => {
    describe('processPendingMint', () => {
        let lockMint: LockMintEntity;
        beforeEach(async () => {
            lockMint = await insertNewLockMint();
        });

        it('should return if no processing mint', async () => {
            // Arrange
            jest.spyOn(dbService, 'getLockMints').mockResolvedValueOnce([]);

            // Act
            await mintService.processPendingMint();

            // Assert
            expect(dbService.getLockMints).toHaveBeenCalled();
        });

        it('should update lockMint state to error INTERRUPTED_PROCESSING', async () => {
            await updateLockMint(lockMint, { state: BridgingState.processing });
            jest.spyOn(dbService, 'updateLockMintState');

            // Act
            await mintService.processPendingMint();

            // Assert
            await waitForExpect(async () => {
                const result = await dbService.getLockMints({
                    inputTxId: lockMint.inputTxId,
                });
                expect(result[0].state).toEqual(BridgingState.error);
                expect(result[0].error.code).toEqual(Codes.INTERRUPTED_PROCESSING);
                expect(result[0].error.msg).toEqual('Mint operation found in processing state at startup');
            });
        });
    });
});
