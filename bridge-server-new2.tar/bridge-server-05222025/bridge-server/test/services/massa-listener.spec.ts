import { ForwardingRequest } from '../../src/massa-client/request';
import { massaClientServiceMock } from '../mocks/massaClientServiceMock';
import { dbService, massaListenerService } from '../setup';
import { randomAddr, randomTokenPair } from '../utils/evm';
import { BridgingState, BurnRedeemEntity } from '../../src/database/entities';
import { randomOpId } from '../utils/massa';
import { randomInt } from 'crypto';

describe('MassaListenerService', () => {
    describe('poll', () => {
        let processBurnRedeemMock;

        beforeEach(() => {
            processBurnRedeemMock = jest.spyOn(massaListenerService, 'processBurnRedeem');
            processBurnRedeemMock.mockClear();
            massaClientServiceMock.getBurnList.mockClear();
        });

        it('should not process burn if list is empty', async () => {
            massaClientServiceMock.getBurnList.mockResolvedValueOnce([]);

            await massaListenerService.poll();

            expect(massaClientServiceMock.getBurnList).toHaveBeenCalled();
            expect(processBurnRedeemMock).not.toHaveBeenCalled();
        });

        it('should process burn list', async () => {
            const request = createRandomForwardingRequest();

            massaClientServiceMock.getBurnList.mockResolvedValueOnce([request]);
            massaClientServiceMock.getDataStoreEntry.mockResolvedValueOnce(request.serialize());

            // Set threshold to 1 to process the burn
            massaClientServiceMock.multisigThreshold = 1;

            await massaListenerService.poll();

            expect(massaClientServiceMock.getBurnList).toHaveBeenCalledTimes(1);
            const result = await dbService.getBurnRedeems({
                inputOpId: request.opId,
                inputAddr: request.caller,
            });
            expect(result.length).toEqual(1);
            expect(result[0].amount).toEqual(request.amount);
            expect(result[0].outputAddr).toEqual(request.receiver);
            expect(result[0].ercToken).toEqual(request.tokenPair.evmToken);
            expect(result[0].massaToken).toEqual(request.tokenPair.massaToken);
            expect(result[0].destinationNetwork).toEqual(request.tokenPair.chainId);
            expect(result[0].state).toEqual(BridgingState.processing);
        });

        it('should continue processing other burn if processBurn encounters specific error (err?.code === 11000)', async () => {
            // Arrange
            const mockBurnList = createRandomForwardingRequestList(4);
            jest.spyOn(dbService, 'addNewBurnRedeem').mockRejectedValueOnce({ code: 11000 });
            massaClientServiceMock.getBurnList.mockResolvedValueOnce(mockBurnList);
            mockBurnList.forEach((burn) => {
                massaClientServiceMock.getDataStoreEntry.mockResolvedValueOnce(burn.serialize());
            });

            // Act
            await massaListenerService.poll();

            // Assert
            expect(massaClientServiceMock.getBurnList).toHaveBeenCalledTimes(1);
            expect(processBurnRedeemMock).toHaveBeenCalledTimes(mockBurnList.length);
            const opIds = mockBurnList.map((burn) => burn.opId);
            const result = await dbService.getBurnRedeems({ inputOpId: { $in: opIds } });
            expect(result.length).toEqual(mockBurnList.length - 1);
        });

        it('should continue processing if processBurn encounters a general error', async () => {
            // Arrange
            const mockBurnList = createRandomForwardingRequestList(4);
            const failNumber = 2;
            for (let i = 0; i < failNumber; i++) {
                jest.spyOn(massaListenerService, 'processBurnRedeem').mockRejectedValueOnce(new Error('Test error'));
            }
            massaClientServiceMock.getBurnList.mockResolvedValueOnce(mockBurnList);
            mockBurnList.forEach((burn) => {
                massaClientServiceMock.getDataStoreEntry.mockResolvedValueOnce(burn.serialize());
            });
            // Act
            await massaListenerService.poll();

            // Assert
            expect(massaClientServiceMock.getBurnList).toHaveBeenCalledTimes(1);
            expect(processBurnRedeemMock).toHaveBeenCalledTimes(mockBurnList.length);
            const result = await dbService.getBurnRedeems({
                inputOpId: { $in: mockBurnList.map((burn) => burn.opId) },
            });
            expect(result.length).toEqual(mockBurnList.length - failNumber);
        });

        it('should handle error if getBurnList fails', async () => {
            // Arrange
            const error = new Error('Test error');
            massaClientServiceMock.getBurnList.mockRejectedValueOnce(error);

            // Act
            await massaListenerService.poll();

            // Assert
            expect(massaClientServiceMock.getBurnList).toHaveBeenCalled();
            expect(processBurnRedeemMock).not.toHaveBeenCalled();
        });
    });

    describe('processBurn', () => {
        let burnRequest: ForwardingRequest;
        beforeEach(() => {
            massaClientServiceMock.multisigThreshold = 3;
            burnRequest = createRandomForwardingRequest();
        });

        it('should process a valid burn request signed by 3 relayers', async () => {
            const relayers = [0, 1, 2];

            await Promise.all(
                relayers.map(async (relayer) => {
                    massaClientServiceMock.relayerId = relayer;
                    return massaListenerService.processBurnRedeem(burnRequest);
                }),
            );

            const result = await dbService.getBurnRedeems({ inputOpId: burnRequest.opId });

            expect(result.length).toEqual(1);
            validateEntityProps(result[0]);

            expect(result[0].signatures.length).toEqual(relayers.length);
            expect(result[0].signatures[0].signature).toEqual(
                await massaListenerService.signRedeemRequest(burnRequest),
            );
            expect(result[0].state).toEqual(BridgingState.processing);
            expect(result[0].outputTxId).toBeNull();
            expect(result[0].outputConfirmations).toBeNull();
        });

        it('should process a valid burn request signed by 4 relayers', async () => {
            const relayers = [0, 1, 2, 3];

            await Promise.all(
                relayers.map(async (relayer) => {
                    massaClientServiceMock.relayerId = relayer;
                    return massaListenerService.processBurnRedeem(burnRequest);
                }),
            );

            const result = await dbService.getBurnRedeems({ inputOpId: burnRequest.opId });
            expect(result.length).toEqual(1);
            validateEntityProps(result[0]);

            expect(result[0].signatures.length).toEqual(relayers.length);
            expect(result[0].signatures[0].signature).toEqual(
                await massaListenerService.signRedeemRequest(burnRequest),
            );
            expect(result[0].state).toEqual(BridgingState.processing);

            expect(result[0].outputTxId).toBeNull();
            expect(result[0].outputConfirmations).toBeNull();
        });

        it('should not process because of missing signature', async () => {
            await massaListenerService.processBurnRedeem(burnRequest);

            const result = await dbService.getBurnRedeems({ inputOpId: burnRequest.opId });

            expect(result.length).toEqual(1);
            validateEntityProps(result[0]);

            expect(result[0].state).toEqual(BridgingState.new);
            expect(result[0].signatures.length).toEqual(1);
            expect(result[0].signatures[0].signature).toEqual(
                await massaListenerService.signRedeemRequest(burnRequest),
            );
        });

        const validateEntityProps = (elt: BurnRedeemEntity) => {
            expect(elt.inputOpId).toEqual(burnRequest.opId);
            expect(elt.inputAddr).toEqual(burnRequest.caller);
            expect(elt.outputAddr).toEqual(burnRequest.receiver);
            expect(elt.amount).toEqual(burnRequest.amount);
            expect(elt.ercToken).toEqual(burnRequest.tokenPair.evmToken);
            expect(elt.massaToken).toEqual(burnRequest.tokenPair.massaToken);
            expect(elt.destinationNetwork).toEqual(burnRequest.tokenPair.chainId);
        };
    });
});

const createRandomForwardingRequestList = (size: number): ForwardingRequest[] =>
    new Array(size).fill(undefined).map(() => createRandomForwardingRequest());

const createRandomForwardingRequest = (): ForwardingRequest => {
    const request = new ForwardingRequest(randomInt(10000).toString(), randomAddr(), 111, randomTokenPair());
    request.opId = randomOpId();
    request.caller = randomAddr();
    return request;
};
