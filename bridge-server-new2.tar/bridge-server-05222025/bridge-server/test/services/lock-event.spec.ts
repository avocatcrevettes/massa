import { ethers } from 'ethers';
import { dbService, evmBlockParserService, evmEventHandlerService, evmHttpProviderService } from '../setup';
import { Token1 } from '../mocks/tokens';
import { BridgingState, LockMintEntity } from '../../src/database/entities';
import { massaClientServiceMock, opId } from '../mocks/massaClientServiceMock';
import { BridgeError, Codes } from '../../src/utils/errors';
import { randomAddr, randomTxId } from '../utils/evm';
import { SIGNATURE_BYTE_LEN } from '../../src/massa-client/mint.service';
import { massaOperationsServiceMock } from '../mocks/massaOperationsMock';
import waitForExpect from 'wait-for-expect';
import { bridgeVaultAbi } from '../../src/contracts';
import { randomMassaAddress } from '../utils/massa';
import { Networks } from '../../src/evm-http-provider/networks';
import { randomInt } from 'crypto';

describe('Lock event handler', () => {
    const confirmations = 5;
    const currentBlock = 4043325;

    const chainId = Networks.BSC;

    const amount = BigInt(randomInt(1000000));
    const lockedAmount = BigInt(randomInt(1000000));
    let emitter: string;
    let massaRecipient: string;
    let inputTxId: string;
    let inputLogIdx: number;
    let event: ethers.providers.Log;

    beforeAll(() => {
        massaClientServiceMock.multisigThreshold = 3;
    });

    beforeEach(() => {
        emitter = randomAddr();
        massaRecipient = randomMassaAddress();
        inputTxId = randomTxId();
        inputLogIdx = 42;

        // Generate burn event from random inputs
        const intf = new ethers.utils.Interface(bridgeVaultAbi);
        const topics = intf.encodeEventLog('Locked', [
            emitter,
            Token1.evmToken,
            massaRecipient,
            amount.toString(),
            lockedAmount.toString(),
        ]);

        event = {
            address: evmHttpProviderService.vaultContracts[chainId].address,
            blockHash: '0xc41bb874a01bcc94df8fc96bd6595b810fd6669dbc99e921abde8c97caa525ad',
            blockNumber: currentBlock.toString(16) as any,
            data: '0x1ebac5c60000000000000000000000000000000000000000000000003782dace9d9000000000000000000000000000000000000000000000000000000000000000000060000000000000000000000000f6e9fbff1cf908f6ebc1a274f15f5c0985291424000000000000000000000000000000000000000000000000000000000000003441553164367056577a47347a44785532556f5957485555707557687a5a7151794d4a437938726d596f3446707171763364564846000000000000000000000000',
            logIndex: inputLogIdx,
            removed: false,
            transactionHash: inputTxId,
            transactionIndex: 456,
            topics: topics.topics,
            ...topics,
        };
    });

    it('token locked event, 0 confirmations', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock);

        const elt = await dbService.getLockMints({
            inputTxId,
            inputLogIdx,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(0);
        expect(elt[0].signatures.length).toEqual(0);
        expect(elt[0].state).toEqual(BridgingState.new);
        expect(elt[0].outputIsFinal).toBeFalsy();
        expect(elt[0].outputOpId).toEqual(null);
    });

    it('token locked event, 5 confirmations. should add signature', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const elt = await dbService.getLockMints({
            inputTxId,
            inputLogIdx,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(confirmations);
        expect(elt[0].state).toEqual(BridgingState.new);
        expect(elt[0].outputOpId).toEqual(null);
        expect(elt[0].outputIsFinal).toEqual(false);
        expect(elt[0].signatures[0].signature).toEqual(
            await evmEventHandlerService.signMintRequest(
                inputTxId,
                inputLogIdx,
                elt[0].outputAddr,
                elt[0].outputAmount,
                elt[0].massaToken,
                chainId,
            ),
        );
        expect(elt[0].signatures[0].signature.length).toEqual(SIGNATURE_BYTE_LEN * 2);
    });

    it('Should add 2 signatures', async () => {
        const relayers = [1, 2];

        await Promise.all(
            relayers.map(async (relayer) => {
                massaClientServiceMock.relayerId = relayer;
                return evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
            }),
        );

        const elt = await dbService.getLockMints({
            inputTxId,
            inputLogIdx,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        const signatures = elt[0].signatures;

        expect(signatures.length).toEqual(2);
        for (const relayer of relayers) {
            expect(signatures.find((s) => s.relayerId === relayer)).toBeTruthy();
        }

        const expectedSignature = await evmEventHandlerService.signMintRequest(
            inputTxId,
            inputLogIdx,
            elt[0].outputAddr,
            elt[0].outputAmount,
            elt[0].massaToken,
            chainId,
        );
        expect(signatures.every((s) => s.signature === expectedSignature)).toBeTruthy();
        expect(signatures.every((s) => s.signature.length === SIGNATURE_BYTE_LEN * 2)).toBeTruthy();

        expect(elt[0].state).toEqual(BridgingState.new);
        expect(elt[0].outputIsFinal).toBeFalsy();
        expect(elt[0].outputOpId).toEqual(null);
    });

    it('Should add 3 signatures and process mint operation', async () => {
        const relayers = [0, 1, 2];

        await Promise.all(
            relayers.map(async (relayer) => {
                massaClientServiceMock.relayerId = relayer;
                return evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
            }),
        );

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 3 signatures in specific order', async () => {
        const relayers = [2, 1, 3];

        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 3 signatures and process mint operation', async () => {
        const relayers = [0, 2, 3];
        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('Should add 4 signatures and process mint operation', async () => {
        const relayers = [0, 1, 2, 3];
        for (const relayer of relayers) {
            massaClientServiceMock.relayerId = relayer;
            await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        }

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].signatures.length).toEqual(relayers.length);
            expect(elt[0].outputIsFinal).toBeTruthy();
            expect(elt[0].state).toEqual(BridgingState.done);
        });
    });

    it('receive twice same lock event (same relayer)', async () => {
        await evmBlockParserService.processEvents(chainId, [event], currentBlock);
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + 1);

        const elt = await dbService.getLockMints({
            inputTxId,
            inputLogIdx,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(1);
        expect(elt[0].signatures.length).toEqual(0);
        expect(elt[0].state).toEqual(BridgingState.new);

        expect(
            await dbService.countLockMints({
                inputTxId,
                inputLogIdx,
            }),
        ).toEqual(1);
    });

    it('receive twice same confirmed lock event (same relayer)', async () => {
        const relayer2 = 2;
        massaClientServiceMock.relayerId = relayer2;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const elt = await dbService.getLockMints({
            inputTxId,
            inputLogIdx,
        });

        expect(elt.length).toEqual(1);
        validateEntityProps(elt[0]);

        expect(elt[0].inputConfirmations).toEqual(confirmations);
        expect(elt[0].signatures.length).toEqual(1);
        expect(elt[0].signatures[0].relayerId).toEqual(relayer2);
        expect(elt[0].signatures[0].signature).toEqual(
            await evmEventHandlerService.signMintRequest(
                inputTxId,
                inputLogIdx,
                elt[0].outputAddr,
                elt[0].outputAmount,
                elt[0].massaToken,
                chainId,
            ),
        );
        expect(elt[0].signatures[0].signature.length).toEqual(SIGNATURE_BYTE_LEN * 2);
        expect(elt[0].state).toEqual(BridgingState.new);

        expect(
            await dbService.countLockMints({
                inputTxId,
                inputLogIdx,
            }),
        ).toEqual(1);
    });

    it('Mint operation timeout', async () => {
        const bridgeErr = new BridgeError(
            Codes.MASSA_OPERATION_EXPIRED,
            `Fail to wait operation finality for ${opId}: Timeout reached.`,
        );

        massaOperationsServiceMock.waitFinalOperation.mockImplementationOnce(() => {
            throw bridgeErr;
        });

        const relayer1 = 0;
        massaClientServiceMock.relayerId = relayer1;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer2 = 1;
        massaClientServiceMock.relayerId = relayer2;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer3 = 2;
        massaClientServiceMock.relayerId = relayer3;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].outputIsFinal).toBeFalsy();
            expect(elt[0].state).toEqual(BridgingState.error);
            expect(elt[0].error).toEqual(bridgeErr);

            const failedLockMints = await dbService.getFailedLockMints();
            expect(failedLockMints.some((f) => f.inputTxId === inputTxId)).toBeTruthy();
        });
    });

    it('insufficient coins to mint ', async () => {
        const bridgeErr = new BridgeError(
            Codes.MASSA_INSUFFICIENT_COINS_FOR_OP,
            `Insufficient coins included in ${opId}: Operation failed.`,
        );

        massaOperationsServiceMock.waitFinalOperation.mockImplementationOnce(() => {
            throw bridgeErr;
        });

        const relayer1 = 0;
        massaClientServiceMock.relayerId = relayer1;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer2 = 1;
        massaClientServiceMock.relayerId = relayer2;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        const relayer3 = 2;
        massaClientServiceMock.relayerId = relayer3;
        await evmBlockParserService.processEvents(chainId, [event], currentBlock + confirmations);

        await waitForExpect(async () => {
            const elt = await dbService.getLockMints({
                inputTxId,
                inputLogIdx,
            });

            expect(elt.length).toEqual(1);
            validateEntityProps(elt[0]);

            expect(elt[0].inputConfirmations).toEqual(confirmations);
            expect(elt[0].state).toEqual(BridgingState.error);
            expect(elt[0].error).toEqual(bridgeErr);

            const failedLockMints = await dbService.getFailedLockMints();
            expect(failedLockMints.some((f) => f.inputTxId === inputTxId)).toBeTruthy();
        });
    });

    const validateEntityProps = (elt: LockMintEntity) => {
        expect(elt.inputAddr).toEqual(emitter);
        expect(elt.inputTxId).toEqual(event.transactionHash);
        expect(elt.inputLogIdx).toEqual(event.logIndex);
        expect(elt.ercToken).toEqual(Token1.evmToken);
        expect(elt.outputAddr).toEqual(massaRecipient);
        expect(elt.amount).toEqual(amount.toString());
        expect(elt.outputAmount).toEqual(lockedAmount.toString());
        expect(elt.massaToken).toEqual(Token1.massaToken);
        expect(elt.originNetwork).toEqual(chainId);
    };
});
