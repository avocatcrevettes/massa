import { randomInt } from 'crypto';
import { randomAddr, randomTokenPair, randomTxId } from '../../utils/evm';
import { randomMassaAddress, randomOpId } from '../../utils/massa';

import { DataSource } from 'typeorm';
import { getConfig } from '../../../src/database/config';
import { BridgingState, BurnRedeemEntity, LockMintEntity, ReleaseMASEntity } from '../../../src/database/entities';

export const evmAddress = randomAddr();
export const massaAddress = randomMassaAddress();
export const tokenPair = randomTokenPair();
export const inputTxId1 = randomTxId();
export const inputLogIdx1 = randomInt(100);
export const inputTxId2 = randomTxId();
export const inputLogIdx2 = randomInt(100);
export const inputOpId = randomOpId();

export default async function seed() {
    const dataSource = new DataSource(await getConfig());
    await dataSource.initialize();

    const lockMintRepository = dataSource.getMongoRepository(LockMintEntity);
    const burnRedeemRepository = dataSource.getMongoRepository(BurnRedeemEntity);
    const releaseMASRepository = dataSource.getMongoRepository(ReleaseMASEntity);

    // Add Lock

    // Add some inputAddr: evmAddress
    let newLockMint: LockMintEntity;
    for (let i = 0; i < 3; i++) {
        newLockMint = lockMintRepository.create({
            inputTxId: randomTxId(),
            inputLogIdx: randomInt(100),
            inputAddr: evmAddress,
            outputAddr: randomMassaAddress(),
            amount: randomInt(100).toString(),
            outputAmount: randomInt(100).toString(),
            ercToken: tokenPair.evmToken,
            massaToken: tokenPair.massaToken,
            originNetwork: tokenPair.chainId,
            inputConfirmations: 3,
        });
        await lockMintRepository.save(newLockMint);
    }
    // Add one random
    newLockMint = lockMintRepository.create({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await lockMintRepository.save(newLockMint);

    // Without outputAmount to test retrocompatibility
    newLockMint = lockMintRepository.create({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await lockMintRepository.save(newLockMint);

    // Add one outputAddr: massaAddress
    newLockMint = lockMintRepository.create({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: randomAddr(),
        outputAddr: massaAddress,
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await lockMintRepository.save(newLockMint);
    // Add one outputAddr: massaAddress and inputAddr: evmAddress
    newLockMint = lockMintRepository.create({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: evmAddress,
        outputAddr: massaAddress,
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await lockMintRepository.save(newLockMint);
    // Add one inputTxId: inputTxId and inputLogIdx: inputLogIdx
    newLockMint = lockMintRepository.create({
        inputTxId: inputTxId1,
        inputLogIdx: inputLogIdx1,
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await lockMintRepository.save(newLockMint);

    // Add Burn

    // Add some random
    let burnRedeem: BurnRedeemEntity;
    for (let i = 0; i < 2; i++) {
        burnRedeem = burnRedeemRepository.create({
            inputOpId: randomOpId(),
            inputAddr: randomMassaAddress(),
            outputAddr: randomAddr(),
            amount: randomInt(100).toString(),
            outputAmount: randomInt(100).toString(),
            ercToken: tokenPair.evmToken,
            massaToken: tokenPair.massaToken,
            destinationNetwork: tokenPair.chainId,
        });
        await burnRedeemRepository.save(burnRedeem);
    }
    // Add one inputAddr: massaAddress
    burnRedeem = burnRedeemRepository.create({
        inputOpId: randomOpId(),
        inputAddr: massaAddress,
        outputAddr: randomAddr(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        destinationNetwork: tokenPair.chainId,
    });
    await burnRedeemRepository.save(burnRedeem);

    // Without outputAmount to test retrocompatibility
    burnRedeem = burnRedeemRepository.create({
        inputOpId: randomOpId(),
        inputAddr: massaAddress,
        outputAddr: randomAddr(),
        amount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        destinationNetwork: tokenPair.chainId,
    });
    await burnRedeemRepository.save(burnRedeem);

    // Add one outputAddr: evmAddress and inputAddr: massaAddress
    burnRedeem = burnRedeemRepository.create({
        inputOpId: randomOpId(),
        inputAddr: massaAddress,
        outputAddr: evmAddress,
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        destinationNetwork: tokenPair.chainId,
    });
    await burnRedeemRepository.save(burnRedeem);
    // Add one inputOpId: inputOpId
    burnRedeem = burnRedeemRepository.create({
        inputOpId,
        inputAddr: randomMassaAddress(),
        outputAddr: randomAddr(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        destinationNetwork: tokenPair.chainId,
    });
    await burnRedeemRepository.save(burnRedeem);
    // Add one state: processing
    burnRedeem = burnRedeemRepository.create({
        inputOpId: randomOpId(),
        inputAddr: randomMassaAddress(),
        outputAddr: randomAddr(),
        amount: randomInt(100).toString(),
        outputAmount: randomInt(100).toString(),
        state: BridgingState.processing,
        ercToken: tokenPair.evmToken,
        massaToken: tokenPair.massaToken,
        destinationNetwork: tokenPair.chainId,
    });
    await burnRedeemRepository.save(burnRedeem);

    // Add releaseMAS

    // Add some inputAddr: evmAddress
    let newReleaseMAS: ReleaseMASEntity;
    for (let i = 0; i < 4; i++) {
        newReleaseMAS = releaseMASRepository.create({
            inputTxId: randomTxId(),
            inputLogIdx: randomInt(100),
            inputAddr: evmAddress,
            outputAddr: randomMassaAddress(),
            amount: randomInt(100).toString(),
            originNetwork: tokenPair.chainId,
            inputConfirmations: 3,
        });
        await releaseMASRepository.save(newReleaseMAS);
    }
    // Add one random
    newReleaseMAS = releaseMASRepository.create({
        inputTxId: randomTxId(),
        inputLogIdx: randomInt(100),
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await releaseMASRepository.save(newReleaseMAS);
    // Add some outputAddr: massaAddress
    for (let i = 0; i < 2; i++) {
        newReleaseMAS = releaseMASRepository.create({
            inputTxId: randomTxId(),
            inputLogIdx: randomInt(100),
            inputAddr: randomAddr(),
            outputAddr: massaAddress,
            amount: randomInt(100).toString(),
            originNetwork: tokenPair.chainId,
            inputConfirmations: 3,
            state: BridgingState.processing,
        });
        await releaseMASRepository.save(newReleaseMAS);
    }
    // Add inputTxId: inputTxId1 and inputLogIdx: inputLogIdx1
    newReleaseMAS = releaseMASRepository.create({
        inputTxId: inputTxId1,
        inputLogIdx: inputLogIdx1,
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await releaseMASRepository.save(newReleaseMAS);
    // Add inputTxId: inputTxId2 and inputLogIdx: inputLogIdx2
    newReleaseMAS = releaseMASRepository.create({
        inputTxId: inputTxId2,
        inputLogIdx: inputLogIdx2,
        inputAddr: randomAddr(),
        outputAddr: randomMassaAddress(),
        amount: randomInt(100).toString(),
        originNetwork: tokenPair.chainId,
        inputConfirmations: 3,
        state: BridgingState.processing,
    });
    await releaseMASRepository.save(newReleaseMAS);
}
