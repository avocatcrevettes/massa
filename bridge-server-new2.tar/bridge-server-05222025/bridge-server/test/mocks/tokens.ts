import { Networks } from '../../src/evm-http-provider/networks';

export const Token1 = {
    massaToken: 'AS19GhQmWsBkpeGXa6g5Mc5VggZYbrWTAP1rsB42ykJj2GT3H5r4',
    evmToken: '0x3F4B6664338F23d2397c953f2AB4Ce8031663f80',
    chainId: Networks.BSC,
    totalSupply: 0n,
    symbol: 'SYM',
    decs: 5,
    masBalance: 0n,
};
