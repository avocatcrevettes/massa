import 'reflect-metadata';
import { APIGatewayProxyEvent } from 'aws-lambda';
import { handle } from './handle';

exports.handler = async (event: APIGatewayProxyEvent) => {
    return handle({
        evmAddress: event.queryStringParameters?.evmAddress,
        massaAddress: event.queryStringParameters?.massaAddress,
        entities: event.queryStringParameters?.entities, // ?entities=burn&entities=lock => burn,lock
        inputTxId: event.queryStringParameters?.inputTxId,
        inputLogIdx: event.queryStringParameters?.inputLogIdx,
        inputOpId: event.queryStringParameters?.inputOpId,
        state: event.queryStringParameters?.state,
    });
};
