import { Injectable, Logger } from '@nestjs/common';
import { EOperationStatus, IEvent, MAX_GAS_CALL } from '@massalabs/massa-web3';
import { scheduler } from 'node:timers/promises';
import { BridgeError, Codes } from '../utils/errors';
import { MassaClientService } from './massa-client.service';
import { STATUS_POLL_INTERVAL_MS, WAIT_STATUS_TIMEOUT } from './constants';

@Injectable()
export class MassaOperationsService {
    private readonly logger = new Logger('Massa-operations');

    public defaultFee;
    public bridgeSCTargetBalance = 10_000_000_000n; // 1O MAS
    constructor(protected readonly massaClient: MassaClientService) {
        this.defaultFee = process.env.DEFAULT_FEE ? BigInt(process.env.DEFAULT_FEE) : 0n;
        if (process.env.BRIDGE_SC_TARGET_BALANCE) {
            this.bridgeSCTargetBalance = BigInt(process.env.BRIDGE_SC_TARGET_BALANCE);
        }
    }

    public lastMaxGas: Record<string, bigint> = {};

    public getBridgeCoinsAmount(): bigint {
        let coins = 0n;
        // If the bridge balance is lower than the target balance, send the difference in coins
        if (this.massaClient.bridgeMASBalance < this.bridgeSCTargetBalance) {
            coins = this.bridgeSCTargetBalance - this.massaClient.bridgeMASBalance;
            // update bridge balance now. Its value is updated every minutes in MassaClientService
            this.massaClient.bridgeMASBalance += coins;
        }
        return coins;
    }

    public async getDynamicGasCost(
        targetAddress: string,
        targetFunction: string,
        parameter: number[],
        coins?: bigint,
    ): Promise<bigint> {
        let val: bigint;
        try {
            const readOnlyCall = await this.massaClient.client.smartContracts().readSmartContract({
                targetAddress: targetAddress,
                targetFunction: targetFunction,
                parameter,
                maxGas: MAX_GAS_CALL,
                coins,
            });

            // add 20% to the gas cost
            val = BigInt(Math.floor(readOnlyCall.info.gas_cost * 1.2));
            val = val > MAX_GAS_CALL ? MAX_GAS_CALL : val;
            this.lastMaxGas = { ...this.lastMaxGas, [targetAddress + targetFunction]: val };
        } catch (err) {
            this.logger.error(
                `Failed to get dynamic gas cost for ${targetFunction} at ${targetAddress}. Using fallback value `,
                err.toString(),
            );
            if (this.lastMaxGas[targetAddress + targetFunction]) {
                val = this.lastMaxGas[targetAddress + targetFunction];
            } else {
                val = MAX_GAS_CALL;
            }
        }
        return val;
    }

    public async getOperationStatus(opId: string): Promise<EOperationStatus> {
        return this.massaClient.client.smartContracts().getOperationStatus(opId);
    }

    public async getOperationEvents(opId: string): Promise<IEvent[]> {
        return this.massaClient.client.smartContracts().getFilteredScOutputEvents({
            emitter_address: null,
            start: null,
            end: null,
            original_caller_address: null,
            original_operation_id: opId,
            is_final: null,
        });
    }

    public async waitFinalOperation(opId: string): Promise<void> {
        const start = Date.now();
        let counterMs = 0;
        while (counterMs < WAIT_STATUS_TIMEOUT) {
            const status = await this.getOperationStatus(opId);
            if (status === EOperationStatus.FINAL_SUCCESS) {
                return;
            }
            if (status === EOperationStatus.FINAL_ERROR || status === EOperationStatus.SPECULATIVE_ERROR) {
                const events = await this.getOperationEvents(opId);

                if (
                    events.some((e) => e.data.includes('is lower than the base instance creation gas cost')) ||
                    events.some((e) => e.data.includes('Not enough gas, limit reached at'))
                ) {
                    throw new BridgeError(
                        Codes.MASSA_INSUFFICIENT_GAS,
                        `insufficient maxGas for in ${opId}: Status: ${EOperationStatus[status]}`,
                    );
                }

                if (events.some((e) => e.data.includes('due to insufficient balance'))) {
                    throw new BridgeError(
                        Codes.MASSA_INSUFFICIENT_COINS_FOR_OP,
                        `insufficient coins included in ${opId}: Operation failed.`,
                    );
                }

                const eventStr = events.map((l) => l.data).join('\n');

                throw new BridgeError(
                    Codes.MASSA_OPERATION_ERROR,
                    `Waiting for operation ${opId}. Status: ${EOperationStatus[status]}. Events: ${eventStr}`,
                );
            }

            await scheduler.wait(STATUS_POLL_INTERVAL_MS);
            counterMs = Date.now() - start;
        }
        const status = await this.getOperationStatus(opId);
        throw new BridgeError(
            Codes.MASSA_OPERATION_EXPIRED,
            `Fail to wait operation finality for ${opId}: Timeout reached. status: ${EOperationStatus[status]}`,
        );
    }
}
