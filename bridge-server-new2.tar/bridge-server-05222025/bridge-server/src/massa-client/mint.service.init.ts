import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { MassaClientService } from './massa-client.service';
import { BridgingState } from '../database/entities';
import { BridgeError, Codes } from '../utils/errors';
import { MassaOperationsService } from './massa-operations.service';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';

@Injectable()
export class MintServiceInit {
    protected readonly logger = new Logger('Mint');

    constructor(
        protected readonly massaClient: MassaClientService,
        protected readonly massaOperations: MassaOperationsService,
        protected readonly db: DatabaseService,
        protected readonly evmProvider: EvmHttpProviderService,
    ) {}

    public async onModuleInit(): Promise<void> {
        await this.processPendingMint();
    }

    public async processPendingMint(): Promise<void> {
        // at startup check if there are any pending mint
        const processing = await this.db.getLockMints({ state: BridgingState.processing });

        if (!processing.length) {
            return;
        }

        this.logger.log(`Found ${processing.length} mints in processing state at startup`);

        for (const lockMint of processing) {
            const { inputTxId, inputLogIdx } = lockMint;
            await this.db.updateLockMintState(inputTxId, inputLogIdx, BridgingState.processing, {
                state: BridgingState.error,
                error: new BridgeError(
                    Codes.INTERRUPTED_PROCESSING,
                    'Mint operation found in processing state at startup',
                ),
            });
        }
    }

    public isInLockList = (inputLockTxId: string, inputLockLogIdx: number): boolean => {
        return Object.keys(this.massaClient.lockIdList).some((key) => key === `${inputLockTxId}${inputLockLogIdx}`);
    };
}
