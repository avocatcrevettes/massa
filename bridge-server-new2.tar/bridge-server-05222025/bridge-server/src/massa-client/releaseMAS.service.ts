import { Injectable } from '@nestjs/common';
import { ReleaseMASEntity, BridgingState } from '../database/entities';
import { BridgeError, Codes, isBridgeError } from '../utils/errors';
import { Interval } from '@nestjs/schedule';
import { Args, EOperationStatus } from '@massalabs/massa-web3';
import { toReadable } from '../utils/decimals';
import { PERIOD_TIME } from './constants';
import { ReleaseMASServiceInit } from './releaseMas.service.init';
import { multisigThresholdReached, packSignatures } from './multisig-utils';
import { ReleaseRequest } from './request';

const MAX_OP_PER_PERIOD = 30;

// the remaining costs will be refunded
const RELEASE_COINS = 1_000_000_000n;

@Injectable()
export class ReleaseMasService extends ReleaseMASServiceInit {
    public async submit(entity: ReleaseMASEntity): Promise<string> {
        const { inputTxId, inputLogIdx, amount, outputAddr, originNetwork, signatures } = entity;

        try {
            const packedSignatures = packSignatures(signatures);
            const request = new ReleaseRequest(
                amount,
                outputAddr,
                inputTxId,
                inputLogIdx,
                packedSignatures,
                originNetwork,
            );

            const parameter = new Args().addSerializable(request).serialize();
            const maxGas = await this.massaOperations.getDynamicGasCost(
                this.massaClient.MasVaultContract,
                'release',
                parameter,
                RELEASE_COINS,
            );

            this.logger.log(`Releasing ${toReadable(amount, 9)} MAS to ${outputAddr}. maxGas: ${maxGas}`);
            const opId = await this.massaClient.client.smartContracts().callSmartContract({
                fee: this.massaOperations.defaultFee,
                maxGas,
                coins: RELEASE_COINS,
                targetAddress: this.massaClient.MasVaultContract,
                targetFunction: 'release',
                parameter,
            });
            return opId;
        } catch (err) {
            const msg = `Failed to release ${toReadable(amount, 9)} MAS to ${outputAddr}, input txid ${inputTxId}`;
            this.logger.error(msg);
            throw new BridgeError(Codes.MASSA_RELEASE_SUBMIT, msg);
        }
    }

    public async finalize(bridgeWmas: ReleaseMASEntity): Promise<void> {
        const { inputTxId, inputLogIdx, outputOpId } = bridgeWmas;

        try {
            this.logger.log(`Finalizing release. txId ${inputTxId}. opId: ${outputOpId}`);

            await this.massaOperations.waitFinalOperation(outputOpId);
            this.logger.log(`Release ${outputOpId} reached finality`);

            await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.processing, {
                state: BridgingState.done,
                outputIsFinal: true,
            });
        } catch (err) {
            this.logger.error(`Unable to finalize release, txid ${inputTxId} logIndex ${inputLogIdx}`, err.toString());
            const bridgeError = isBridgeError(err) ? err : new BridgeError(Codes.FINALIZE_RELEASE, err.toString());

            try {
                await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.processing, {
                    state: BridgingState.error,
                    error: bridgeError,
                });
            } catch (err) {
                this.logger.error(`Unable to update release state, txid ${inputTxId}`, err.toString());
            }
        }
    }

    // every 16 secs (1 period)
    @Interval(1000 * PERIOD_TIME)
    public async retry(): Promise<void> {
        if (!this.massaClient.MasVaultContract) {
            return;
        }
        const failed = await this.db.getFailedRelease();

        if (!failed.length) {
            return;
        }

        this.logger.log(`Retrying to submit ${failed.length} failed release(s) operations.`);

        let cnt = 0;
        for (const release of failed) {
            try {
                const { inputTxId, inputLogIdx, error, outputOpId } = release;

                if (this.isInReleaseList(inputTxId, inputLogIdx)) {
                    await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.error, {
                        state: BridgingState.done,
                        outputIsFinal: true,
                    });
                    continue;
                }

                if (outputOpId) {
                    const status = await this.massaOperations.getOperationStatus(outputOpId);
                    switch (status) {
                        case EOperationStatus.INCLUDED_PENDING:
                        case EOperationStatus.AWAITING_INCLUSION:
                        case EOperationStatus.SPECULATIVE_ERROR:
                        case EOperationStatus.SPECULATIVE_SUCCESS:
                            continue;
                        case EOperationStatus.FINAL_SUCCESS:
                            await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.error, {
                                state: BridgingState.done,
                                outputIsFinal: true,
                            });
                            continue;
                    }
                }
                if (!multisigThresholdReached(release, this.massaClient.multisigThreshold)) {
                    // this should not happen. Retry mechanism should only deals with signed releases
                    this.logger.error(`Not all signatures collected for ${inputTxId}. Skipping retry`);
                    continue;
                }

                const isExpired = error.code === Codes.MASSA_OPERATION_EXPIRED;
                const submitError = error.code === Codes.MASSA_RELEASE_SUBMIT;
                const interrupted = error.code === Codes.INTERRUPTED_PROCESSING;

                if (interrupted || submitError || isExpired) {
                    if (++cnt > MAX_OP_PER_PERIOD) {
                        return;
                    }

                    let entity = await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.error, {
                        state: BridgingState.processing,
                    });

                    let opId;
                    try {
                        opId = await this.submit(entity);

                        // set output opId
                        entity = await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.processing, {
                            state: BridgingState.processing,
                            outputOpId: opId,
                        });
                    } catch (err) {
                        // set back to error state
                        await this.db.updateReleaseMasState(inputTxId, inputLogIdx, BridgingState.processing, {
                            state: BridgingState.error,
                            error: err,
                        });
                        continue;
                    }

                    // eslint-disable-next-line @typescript-eslint/no-floating-promises
                    this.finalize(entity);
                } else {
                    this.logger.error(`Unable to process release retry.`, error.toString());
                }
            } catch (err) {
                this.logger.error(`Unable to process release retry.`, err.toString());
                continue;
            }
        }
    }
}
