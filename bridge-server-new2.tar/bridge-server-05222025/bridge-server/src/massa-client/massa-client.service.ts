import { Injectable, Logger } from '@nestjs/common';
import {
    Client,
    ProviderType,
    WalletClient,
    Args,
    bytesToStr,
    bytesToSerializableObjectArray,
    bytesToU256,
    PublicApiClient,
    Web3Account,
    byteToU8,
    MAX_GAS_CALL,
    bytesToU64,
    deserializeObj,
    byteToBool,
} from '@massalabs/massa-web3';
import { toReadable } from '../utils/decimals';
import { ForwardingRequest, RequestStatus, TokenPair } from './request';
import { BridgeError, Codes } from '../utils/errors';
import { Cron, CronExpression, Interval } from '@nestjs/schedule';
import { SigningKey } from 'ethers/lib/utils';
import {
    BURN_LOG_PREFIX,
    DATASTORE_ENTRIES_BATCH_SIZE,
    EXPIRY_PERIOD,
    MINT_LOG_PREFIX,
    MULTISIG_THRESHOLD_KEY,
    PERIOD_TIME,
    RELAYERS_PREFIX,
    RELEASE_LOG_PREFIX,
} from './constants';
import isEqual from 'lodash/isEqual';
import { networkName } from '../evm-http-provider/networks';

export type TokenInfo = {
    massaToken: string;
    evmToken: string;
    chainId: number;
    totalSupply: bigint;
    symbol: string;
    decs: number;
    masBalance: bigint;
};

@Injectable()
export class MassaClientService {
    public client: Client;

    private readonly logger = new Logger('Massa-client');

    public tokensSymbol: Record<string, string> = {};
    public tokensDecimals: Record<string, number> = {};

    public bridgeContract: string;
    public MasVaultContract: string;
    public bridgeMASBalance: bigint;
    public MasVaultBalance: bigint;

    public tokensInfos: TokenInfo[] = [];

    // the lockIdListId is the concatenation of the EVM tx hash (tx id) and the log index
    public lockIdList: Record<string, RequestStatus> = {};
    // the releaseListId is the concatenation of the EVM tx hash (tx id) and the log index
    public releaseList: Record<string, RequestStatus> = {};

    public relayerId: number;
    public relayersPublicKeys: string[] = [];
    public multisigThreshold: number;

    public async onModuleInit(): Promise<void> {
        const adminAccount = await WalletClient.getAccountFromSecretKey(process.env.MASSA_BRIDGE_ADMIN_PK);

        const clientConfig = {
            retryStrategyOn: true,
            providers: [{ url: process.env.MASSA_JSON_RPC, type: ProviderType.PUBLIC }],
            periodOffset: EXPIRY_PERIOD,
        };
        const publicApi = new PublicApiClient(clientConfig);

        const status = await publicApi.getNodeStatus();
        this.logger.log(`Connected to Massa RPC! version: ${status.version}, chainId: ${status.chain_id}`);

        const account = new Web3Account(adminAccount, publicApi, BigInt(status.chain_id));

        this.client = new Client(clientConfig, account, publicApi);

        this.bridgeContract = process.env.MASSA_BRIDGE_CONTRACT;
        if (!this.bridgeContract) {
            throw new Error('Massa bridge contract address is not provided');
        }
        // Check that provided account has relayer role on bridge contract
        if (!(await this.hasRelayerRole(account.address()))) {
            throw new Error(`Account ${account.address()} is not registered as relayer in Massa bridge contract`);
        }
        const relayerBalance = await this.client.wallet().getAccountBalance(account.address());
        this.logger.log(
            `Massa bridge is enabled. Owner is: ${account.address()}. Balance: ${toReadable(
                relayerBalance.candidate,
                9,
            )}`,
        );
        this.bridgeMASBalance = await this.getContractMasBalance(this.bridgeContract);
        this.logger.log(`Massa bridge SC balance: ${toReadable(this.bridgeMASBalance, 9)}`);

        const tokenPairs = await this.getTokenPairs();
        this.tokensInfos = await Promise.all(
            tokenPairs.map(async (pair) => {
                const [totalSupply, symbol, decs, masBalance] = await Promise.all([
                    this.getTotalSupply(pair.massaToken),
                    this.getTokenSymbol(pair.massaToken),
                    this.getTokenDecimals(pair.massaToken),
                    this.getContractMasBalance(pair.massaToken),
                ]);

                return { ...pair, totalSupply, symbol, decs, masBalance };
            }),
        );
        this.logger.log('Supported tokens:');
        this.tokensInfos.map((info) =>
            this.logger.log(
                `${info.symbol} network: ${networkName(info.chainId)} ${info.evmToken} ${
                    info.massaToken
                }: MAS balance: ${toReadable(info.masBalance, 9)}, totalSupply ${toReadable(
                    info.totalSupply,
                    info.decs,
                )}`,
            ),
        );

        await this.refreshLockIdList();
        this.logger.debug('Locks list:');
        Object.entries(this.lockIdList).map(([lockId, status]) =>
            this.logger.debug(`Lock ID: ${lockId}, status: ${status}`),
        );

        this.MasVaultContract = process.env.MASSA_VAULT_CONTRACT;
        if (this.MasVaultContract) {
            const relayerBalance = await this.client.wallet().getAccountBalance(account.address());
            this.logger.log(
                `MAS vault is enabled. Owner is: ${account.address()}. Balance: ${toReadable(
                    relayerBalance.candidate,
                    9,
                )}`,
            );
            this.MasVaultBalance = await this.getContractMasBalance(this.MasVaultContract);
            this.logger.log(`MAS vault SC balance: ${toReadable(this.MasVaultBalance, 9)}`);

            await this.refreshReleaseList();
            this.logger.debug('Releases list:');
            Object.entries(this.releaseList).map(([id, status]) =>
                this.logger.debug(`Release ID: ${id}, status: ${status}`),
            );
        }

        this.relayersPublicKeys = await this.getRelayersPublicKeys(this.MasVaultContract ?? this.bridgeContract);
        this.logger.log(`Relayers public keys:\n${Object.entries(this.relayersPublicKeys).join('\n')}`);

        this.multisigThreshold = await this.getMultisigThreshold(this.MasVaultContract ?? this.bridgeContract);
        this.logger.log(`Multisig threshold: ${this.multisigThreshold}`);
        if (!this.multisigThreshold || this.multisigThreshold > this.relayersPublicKeys.length) {
            throw new Error(`Invalid multisig threshold: ${this.multisigThreshold}`);
        }

        const relayerPublicKey = new SigningKey(`0x${process.env.EVM_RELAYER_PK}`).publicKey;

        this.relayerId = this.getRelayerIdFromPublicKey(relayerPublicKey);
        if (this.relayerId === -1) {
            throw new Error(`Relayer public key ${relayerPublicKey} is not registered as signer in Massa SC`);
        }
        this.logger.log('Relayer id: ' + this.relayerId);
    }

    public async getTokenDecimals(token: string): Promise<number> {
        if (this.tokensDecimals[token]) {
            return this.tokensDecimals[token];
        }
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: token,
            targetFunction: 'decimals',
            parameter: [],
        });

        const decs = parseInt(new Args(res.returnValue).nextU8().toString());
        this.tokensDecimals = { ...this.tokensDecimals, [token]: decs };
        return decs;
    }

    public async getTokenSymbol(token: string): Promise<string> {
        if (this.tokensSymbol[token]) {
            return this.tokensSymbol[token];
        }
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: token,
            targetFunction: 'symbol',
            parameter: [],
        });

        const symbol = bytesToStr(res.returnValue);
        this.tokensSymbol = { ...this.tokensSymbol, [token]: symbol };
        return symbol;
    }

    public async getTotalSupply(token: string): Promise<bigint> {
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: token,
            targetFunction: 'totalSupply',
            parameter: [],
        });

        return bytesToU256(res.returnValue);
    }

    public async getBurnList(): Promise<ForwardingRequest[]> {
        const keys = await this.getDataStoreKeys(this.bridgeContract, Uint8Array.from([BURN_LOG_PREFIX]));

        const list: ForwardingRequest[] = [];
        let offset = 0;
        // if there are more than DATASTORE_ENTRIES_BATCH_SIZE keys, we need to make multiple calls to get all the values
        while (offset < keys.length) {
            const KeyBatch = keys.slice(offset, offset + DATASTORE_ENTRIES_BATCH_SIZE);

            // get the values of the keys
            const serializedLogs = await this.client
                .publicApi()
                .getDatastoreEntries(
                    KeyBatch.map((key) => ({ address: this.bridgeContract, key: Uint8Array.from(key) })),
                );

            list.push(
                ...serializedLogs.map(
                    (logBytes) => deserializeObj(logBytes.final_value, 0, ForwardingRequest).instance,
                ),
            );

            offset += DATASTORE_ENTRIES_BATCH_SIZE;
        }
        return list;
    }

    public async getLockedMasAmount(): Promise<bigint> {
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: this.MasVaultContract,
            targetFunction: 'lockedAmount',
            parameter: [],
        });

        return bytesToU64(res.returnValue);
    }

    public async getContractMasBalance(address: string): Promise<bigint> {
        const balance = await this.client.smartContracts().getContractBalance(address);
        return balance.candidate;
    }

    public async getOwner(contract: string): Promise<string> {
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: contract,
            targetFunction: 'ownerAddress',
            parameter: [],
        });

        return bytesToStr(res.returnValue);
    }

    public async getTokenPairs(): Promise<TokenPair[]> {
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: this.bridgeContract,
            targetFunction: 'supportedTokensList',
            parameter: [],
        });

        return bytesToSerializableObjectArray(res.returnValue, TokenPair);
    }

    public async getMassaTokenAddress(evmAddress: string): Promise<string> {
        const pair = this.tokensInfos.find((info) => info.evmToken === evmAddress);
        if (pair) {
            return pair.massaToken;
        } else {
            throw new BridgeError(Codes.EVM_TOKEN_NOT_SUPPORTED, `Unknown evm address: ${evmAddress}`);
        }
    }

    public async getDataStoreKeys(contract: string, filter: Uint8Array): Promise<number[][]> {
        const addrInfo = await this.client.publicApi().getAddresses([contract]);
        return addrInfo[0].final_datastore_keys.filter((key) =>
            isEqual(Uint8Array.from(key.slice(0, filter.length)), filter),
        );
    }

    public async getDataStoreEntry(contract: string, key: number[]): Promise<Uint8Array> {
        const entry = await this.client
            .publicApi()
            .getDatastoreEntries([{ address: contract, key: Uint8Array.from(key) }]);
        if (entry.length === 0) {
            throw new Error(`Key ${key} not found in datastore`);
        }

        return entry[0].final_value;
    }

    public async getOperationLogs(
        contract: string,
        filter: number,
    ): Promise<Record<string, RequestStatus> | undefined> {
        try {
            // get Bridge SC infos containing all the keys of datastore
            const keys = await this.getDataStoreKeys(contract, Uint8Array.from([filter]));
            const list: Record<string, RequestStatus> = {};
            let offset = 0;
            // if there are more than DATASTORE_ENTRIES_BATCH_SIZE keys, we need to make multiple calls to get all the values
            while (offset < keys.length) {
                const mintKeysBatch = keys.slice(offset, offset + DATASTORE_ENTRIES_BATCH_SIZE);

                // get the values of the keys
                const serializedMintLogs = await this.client
                    .publicApi()
                    .getDatastoreEntries(
                        mintKeysBatch.map((key) => ({ address: contract, key: Uint8Array.from(key) })),
                    );

                for (let i = 0; i < mintKeysBatch.length; i++) {
                    const lockId = bytesToStr(Uint8Array.from(mintKeysBatch[i].slice(1)));
                    const status = byteToU8(serializedMintLogs[i].final_value);
                    list[lockId] = status;
                }

                offset += DATASTORE_ENTRIES_BATCH_SIZE;
            }
            return list;
        } catch (err) {
            this.logger.error(`Failed to get operation logs`, err.toString());
        }
    }

    // every 16 secs (1 period)
    @Interval(1000 * PERIOD_TIME)
    public async refreshLockIdList(): Promise<void> {
        const logs = await this.getOperationLogs(this.bridgeContract, MINT_LOG_PREFIX);
        if (logs) {
            this.lockIdList = logs;
        }
    }

    // every 16 secs (1 period)
    @Interval(1000 * PERIOD_TIME)
    public async refreshReleaseList(): Promise<void> {
        if (this.MasVaultContract) {
            const logs = await this.getOperationLogs(this.MasVaultContract, RELEASE_LOG_PREFIX);
            if (logs) {
                this.releaseList = logs;
            }
        }
    }

    @Cron(CronExpression.EVERY_MINUTE)
    public async refreshBalances(): Promise<void> {
        if (this.bridgeContract) {
            this.bridgeMASBalance = await this.getContractMasBalance(this.bridgeContract);
        }
        if (this.MasVaultContract) {
            this.MasVaultBalance = await this.getContractMasBalance(this.MasVaultContract);
        }
    }

    public async getRelayersPublicKeys(contract: string): Promise<string[]> {
        const relayersKeys = await this.getDataStoreKeys(contract, RELAYERS_PREFIX);

        const relayersData = await this.client.publicApi().getDatastoreEntries(
            relayersKeys
                // sort the keys using the last byte of the key which is the relayerId
                .sort(
                    (key1: number[], key2: number[]) =>
                        byteToU8(new Uint8Array([key1[RELAYERS_PREFIX.length - 1]])) -
                        byteToU8(new Uint8Array([key2[RELAYERS_PREFIX.length - 1]])),
                )
                .map((key) => ({ address: contract, key: Uint8Array.from(key) })),
        );

        const publicKeyPrefix = '0x04';
        return relayersData.map((data) => publicKeyPrefix + Buffer.from(data.final_value).toString('hex'));
    }

    public async getMultisigThreshold(contract: string): Promise<number> {
        const thresholdKey = await this.getDataStoreKeys(contract, MULTISIG_THRESHOLD_KEY);
        const thresholdByte = await this.getDataStoreEntry(contract, thresholdKey[0]);
        return byteToU8(thresholdByte);
    }

    public getRelayerIdFromPublicKey(publicKey: string): number {
        return this.relayersPublicKeys.findIndex((pubkey) => pubkey === publicKey);
    }

    public async hasRelayerRole(address: string): Promise<boolean> {
        const res = await this.client.smartContracts().readSmartContract({
            maxGas: MAX_GAS_CALL,
            targetAddress: this.bridgeContract,
            targetFunction: 'hasRole',
            parameter: new Args().addString('RELAYER').addString(address).serialize(),
        });
        return byteToBool(res.returnValue);
    }
}
