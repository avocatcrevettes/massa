import { BridgeError } from '../../utils/errors';
import { Entity, Column, BaseEntity, ObjectIdColumn, ObjectId } from 'typeorm';
import { BridgingState, Signature } from './utils';

export const lockMintEntityName = 'lock_mint_entity';
@Entity({ name: lockMintEntityName })
export class LockMintEntity extends BaseEntity {
    @ObjectIdColumn()
    id: ObjectId;

    @Column()
    inputAddr: string;
    @Column() inputTxId: string;
    @Column() inputLogIdx: number;
    @Column() inputConfirmations: number;

    @Column() outputAddr: string;
    @Column() outputOpId: string;
    @Column()
    outputIsFinal = false;

    @Column() amount: string;
    @Column() outputAmount: string;

    @Column() ercToken: string;
    @Column() massaToken: string;

    @Column() signatures: Signature[] = [];

    @Column()
    state: BridgingState = BridgingState.new;
    @Column() originNetwork: number;

    @Column() error: BridgeError;
}
