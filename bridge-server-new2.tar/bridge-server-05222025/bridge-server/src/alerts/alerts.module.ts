import { Module, forwardRef } from '@nestjs/common';
import { HttpModule } from '@nestjs/axios';
import { AlertsService } from './alerts.service';
import { DatabaseModule } from '../database/database.module';
import { MassaClientModule } from '../massa-client/massa-client.module';

@Module({
    imports: [HttpModule, forwardRef(() => MassaClientModule), DatabaseModule],
    controllers: [],
    providers: [AlertsService],
    exports: [AlertsService],
})
export class AlertsModule {}
