export class BridgeError {
    public title = '';
    constructor(public code: Codes, public msg?: string) {
        this.title = ErrorsTitles[code];
    }

    public toString(): string {
        return `${this.title}: ${this.msg}`;
    }
}

export const isBridgeError = (err: any): err is BridgeError => err.code && err.code in ErrorsTitles;

export enum Codes {
    GENERIC_ERROR = 100,

    MASSA_OPERATION_EXPIRED = 1001,
    MASSA_OPERATION_ERROR = 1002,
    MASSA_INSUFFICIENT_COINS_FOR_OP = 1003,
    MASSA_DELETE_BURN_REQUEST = 1005,
    MASSA_INSUFFICIENT_GAS = 1006,
    MASSA_MINT_REQUEST = 1007,
    MASSA_RELEASE_SUBMIT = 1008,

    REDEEM_CONFIRMATION_ERROR = 2000,
    EVM_REDEEM_ERROR = 2001,
    EVM_REDEEM_DB_ERROR = 2002,
    EVM_TOKEN_NOT_SUPPORTED = 2003,
    EVM_NO_REDEEM_TX = 2004,

    FINALIZE_BURN_REDEEM = 3000,
    FINALIZE_LOCKMINT = 3001,
    FINALIZE_RELEASE = 3002,

    INTERRUPTED_PROCESSING = 4000,
}

export const ErrorsTitles: Record<number, string> = {
    [Codes.MASSA_INSUFFICIENT_COINS_FOR_OP]: 'Insufficient coins to perform operation',
    [Codes.MASSA_DELETE_BURN_REQUEST]: 'Unable to submit burnLog delete operation',
    [Codes.MASSA_MINT_REQUEST]: 'Unable to submit mint operation',
    [Codes.MASSA_INSUFFICIENT_GAS]: 'Insufficient gas to perform operation',
    [Codes.MASSA_OPERATION_EXPIRED]: 'Wait for operation confirmation reached timeout: Operation expired',
    [Codes.MASSA_OPERATION_ERROR]: 'Operation ended with error',
    [Codes.FINALIZE_BURN_REDEEM]: 'Unable to Finalize BurnRedeem',
    [Codes.FINALIZE_LOCKMINT]: 'Unable to Finalize LockMint',
    [Codes.REDEEM_CONFIRMATION_ERROR]: 'Wait for Redeem confirmation failed',
    [Codes.EVM_REDEEM_ERROR]: 'ERC Redeem error',
    [Codes.EVM_REDEEM_DB_ERROR]: 'Unable to update burnRedeem with redeem tx hash',
    [Codes.EVM_TOKEN_NOT_SUPPORTED]: 'Invalid or not supported token',
    [Codes.EVM_NO_REDEEM_TX]: 'No redeem tx found for burn',
    [Codes.INTERRUPTED_PROCESSING]: 'Bridge processing interrupted',
    [Codes.GENERIC_ERROR]: 'unknown error',
};
