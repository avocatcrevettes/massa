import { getDataSource } from './src/database/config';
import { loadConfig } from './src/config';
import { DataSource } from 'typeorm';

const envDir = `${__dirname}/.env`;

loadConfig(envDir);

const dbConfig = getDataSource();
const source = new DataSource({
    logging: true,
    migrations: ['src/database/migrations/prod/*.ts'],
    ...dbConfig,
});

// eslint-disable-next-line
export default source;
