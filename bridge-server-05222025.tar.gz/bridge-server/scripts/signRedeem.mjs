import { ethers } from 'ethers';
import { config as envConfig } from 'dotenv';

// load environment variables
// edit the path to the .env file if needed
envConfig({ path: '.env/prod.env' });

const config = {
    version: 0,
    // mainnet
    evmChainId: 1,
    // sepolia
    // evmChainId: 11155111,
    evmTokens: [
        // WETH
        // '0xf6E9FBff1CF908f6ebC1a274f15F5c0985291424',
        // // DAI
        // '0x53844F9577C2334e541Aec7Df7174ECe5dF1fCf0',
        // // USDC
        // '0x94a9D9AC8a22534E3FaCa9F4e7F2E2cf85d5E4C8',
        // Mainnet
        // DAI
        '0x6B175474E89094C44Da98b954EedeAC495271d0F',
        // USDC
        '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48',
        // WETH
        '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    ],
    withdrawingContract: '0xCD5dcE776c20260D96E2d0C65431f05da4fa8ba1',
    recipient: '0x6c70c6A2b6B2b0d40e826bFDe89fE2e081Ca408B',
};

const rpcList = process.env.EVM_RPCS_0;

if (!rpcList) {
    throw new Error('Rpc list env var EVM_RPCS_X is not set');
}
const provider = new ethers.providers.JsonRpcProvider(JSON.parse(rpcList)[0]);
const wallet = new ethers.Wallet(process.env.EVM_RELAYER_PK, provider);

console.log('\x1b[36m%s\x1b[0m', `Using signer wallet ${wallet.address}`);
console.log('\x1b[36m%s\x1b[0m', `Withdrawing from contract ${config.withdrawingContract}`);
console.log('\x1b[36m%s\x1b[0m', `Withdrawing to recipient ${config.recipient}\n`);

for (let token of config.evmTokens) {
    const contract = new ethers.Contract(token, ['function balanceOf(address) view returns (uint256)'], provider);

    const balance = await contract.balanceOf(config.withdrawingContract);

    console.log(`Signing redeem request amount for token: ${token}`);
    console.log(`Amount to redeem: ${balance.toString()}`);

    // signature without version, uncomment if needed
    const hashString = ethers.utils.solidityKeccak256(
        [/* 'uint8',*/ 'uint256', 'address', 'string', 'address', 'uint'],
        [/* config.version,*/ balance, config.recipient, `manualRedeem-${token}`, token, config.evmChainId],
    );
    const signature = await wallet.signMessage(ethers.utils.arrayify(hashString));
    console.log('\x1b[33m%s\x1b[0m', `Signature: ${signature}\n`);
}
