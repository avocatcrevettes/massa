import { Injectable, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { FilterOperators, FindManyOptions, MongoRepository, ObjectLiteral } from 'typeorm';
import { LockMintEntity, BridgingState, BurnRedeemEntity, Signature, ReleaseMASEntity } from './entities';

@Injectable()
export class DatabaseService {
    constructor(
        @InjectRepository(LockMintEntity)
        public lockMint: MongoRepository<LockMintEntity>,
        @InjectRepository(BurnRedeemEntity)
        public burnRedeem: MongoRepository<BurnRedeemEntity>,
        @InjectRepository(ReleaseMASEntity)
        public releaseMAS: MongoRepository<ReleaseMASEntity>,
    ) {}

    private readonly logger = new Logger('Db');

    public async createCollectionIndexes(): Promise<void> {
        await this.lockMint.createCollectionIndex({ inputTxId: 1, inputLogIdx: 1 }, { unique: true });
        await this.releaseMAS.createCollectionIndex({ inputTxId: 1, inputLogIdx: 1 }, { unique: true });
        await this.burnRedeem.createCollectionIndex({ inputOpId: 1 }, { unique: true });
    }

    public async onModuleInit(): Promise<void> {
        if (process.env.DB_RESET === 'true') {
            await this.deleteAll();
        }
        await this.createCollectionIndexes();
        const nbLockMint = await this.lockMint.findAndCount();
        this.logger.log(`LockMint collection size: ${nbLockMint[1]}`);
        const nbBurnRedeem = await this.burnRedeem.findAndCount();
        this.logger.log(`BurnRedeem collection size: ${nbBurnRedeem[1]}`);
        const nbRelease = await this.releaseMAS.findAndCount();
        this.logger.log(`Releases collection size: ${nbRelease[1]}`);
    }

    public async addNewLockMint(entity: Partial<LockMintEntity>): Promise<LockMintEntity> {
        try {
            // if entity already exists, it will be updated (especially the confirmations field)
            const updateRes = await this.lockMint.findOneAndUpdate(
                { inputTxId: entity.inputTxId, inputLogIdx: entity.inputLogIdx },
                {
                    $set: entity,
                    $setOnInsert: { state: BridgingState.new, error: null, outputIsFinal: false, outputOpId: null },
                },
                { upsert: true, returnDocument: 'after' },
            );
            return updateRes.value;
        } catch (err) {
            this.logger.error(`addNewLockMint for ${entity.inputTxId} failed.`, err.toString());
            throw err;
        }
    }

    public async updateLockMintState(
        inputTxId: string,
        inputLogIdx: number,
        currentState: BridgingState,
        updateData?: Partial<LockMintEntity>,
    ): Promise<LockMintEntity> {
        this.logger.log(`Updating lockmint ${inputTxId} state to ${updateData.state}`);
        // Atomic update
        const updateRes = await this.lockMint.findOneAndUpdate(
            { inputTxId, inputLogIdx, state: currentState },
            { $set: updateData },
            { returnDocument: 'after' },
        );
        if (updateRes.value) {
            return updateRes.value;
        }
        throw new Error(`Failed to set ${updateData.state} state for tx ${inputTxId}`);
    }

    public async addRedeemSignature(
        burnRedeem: BurnRedeemEntity,
        relayerId: number,
        signature: string,
    ): Promise<BurnRedeemEntity> {
        return this.addSignature(
            { inputOpId: burnRedeem.inputOpId },
            this.burnRedeem,
            relayerId,
            signature,
        ) as Promise<BurnRedeemEntity>;
    }

    public async addMintSignature(
        lockMint: LockMintEntity,
        relayerId: number,
        signature: string,
    ): Promise<LockMintEntity> {
        const { inputTxId, inputLogIdx } = lockMint;

        return this.addSignature(
            { inputTxId, inputLogIdx },
            this.lockMint,
            relayerId,
            signature,
        ) as Promise<LockMintEntity>;
    }

    public async deleteAll(): Promise<void> {
        await this.lockMint.manager.connection.dropDatabase();
    }

    public async getLockMints(
        filter?: FindManyOptions<LockMintEntity> | Partial<LockMintEntity> | FilterOperators<LockMintEntity>,
    ): Promise<LockMintEntity[]> {
        return this.lockMint.find(filter);
    }

    public async getFailedLockMints(): Promise<LockMintEntity[]> {
        return this.getLockMints({
            error: { $ne: null },
            state: BridgingState.error,
        });
    }

    public async countLockMints(query?: ObjectLiteral): Promise<number> {
        return this.lockMint.count(query);
    }

    public async getBurnRedeems(
        filter?: FindManyOptions<BurnRedeemEntity> | Partial<BurnRedeemEntity> | FilterOperators<BurnRedeemEntity>,
    ): Promise<BurnRedeemEntity[]> {
        return this.burnRedeem.find(filter);
    }

    public async getFailedBurnRedeems(): Promise<BurnRedeemEntity[]> {
        return this.getBurnRedeems({
            error: { $ne: null },
            state: BridgingState.error,
        });
    }

    public async getPendingClaims(): Promise<BurnRedeemEntity[]> {
        return this.getBurnRedeems({
            outputTxId: null,
            state: BridgingState.processing,
        });
    }

    public async countBurnRedeems(query?: ObjectLiteral): Promise<number> {
        return this.burnRedeem.count(query);
    }

    public async addNewBurnRedeem(entity: Partial<BurnRedeemEntity>): Promise<BurnRedeemEntity> {
        try {
            const updateRes = await this.burnRedeem.findOneAndUpdate(
                { inputOpId: entity.inputOpId },
                {
                    $set: entity,
                    $setOnInsert: {
                        state: BridgingState.new,
                        error: null,
                        outputTxId: null,
                        outputConfirmations: null,
                    },
                },
                { upsert: true, returnDocument: 'after' },
            );
            return updateRes.value;
        } catch (err) {
            this.logger.error(`Add burnRedeem ${entity.inputOpId} failed.`, err.toString());
            throw err;
        }
    }

    public async updateBurnRedeem(
        inputOpId: string,
        currentState?: BridgingState,
        updateData?: Partial<BurnRedeemEntity>,
    ): Promise<BurnRedeemEntity> {
        let query: ObjectLiteral = { inputOpId };
        if (currentState) {
            this.logger.log(`Updating burnRedeem ${inputOpId} state to ${updateData.state}`);
            query = { ...query, state: currentState };
        }

        const updateRes = await this.burnRedeem.findOneAndUpdate(
            query,
            { $set: updateData },
            { returnDocument: 'after' },
        );
        if (updateRes.value) {
            return updateRes.value;
        }
        throw new Error(`Failed to update burnRedeem entity ${inputOpId}`);
    }

    public async updateManyBurnRedeems(inputOpIds: string[], updateData: Partial<BurnRedeemEntity>): Promise<void> {
        await this.burnRedeem.updateMany({ inputOpId: { $in: inputOpIds } }, { $set: updateData });
    }

    public async addNewReleaseMas(entity: Partial<ReleaseMASEntity>): Promise<ReleaseMASEntity> {
        try {
            // if entity already exists, it will be updated (especially the confirmations field)
            const updateRes = await this.releaseMAS.findOneAndUpdate(
                { inputTxId: entity.inputTxId, inputLogIdx: entity.inputLogIdx },
                {
                    $set: entity,
                    $setOnInsert: { state: BridgingState.new, error: null, outputIsFinal: false, outputOpId: null },
                },
                { upsert: true, returnDocument: 'after' },
            );
            return updateRes.value;
        } catch (err) {
            this.logger.error(`Add Wmas burn ${entity.inputTxId} failed.`, err.toString());
            throw err;
        }
    }

    public async updateReleaseMasState(
        inputTxId: string,
        inputLogIdx: number,
        currentState: BridgingState,
        updateData?: Partial<ReleaseMASEntity>,
    ): Promise<ReleaseMASEntity> {
        this.logger.log(`Updating bridge Wmas ${inputTxId} state to ${updateData.state}`);
        // Atomic update
        const updateRes = await this.releaseMAS.findOneAndUpdate(
            { inputTxId, inputLogIdx, state: currentState },
            { $set: updateData },
            { returnDocument: 'after' },
        );
        if (updateRes.value) {
            return updateRes.value;
        }
        throw new Error(`Failed to set ${updateData.state} state for tx ${inputTxId}`);
    }

    public async addReleaseSignature(
        entity: ReleaseMASEntity,
        relayerId: number,
        signature: string,
    ): Promise<ReleaseMASEntity> {
        const { inputTxId, inputLogIdx } = entity;
        return this.addSignature(
            { inputTxId, inputLogIdx },
            this.releaseMAS,
            relayerId,
            signature,
        ) as Promise<ReleaseMASEntity>;
    }

    private async addSignature(
        filter: { inputTxId: string; inputLogIdx: number } | { inputOpId: string },
        repo: MongoRepository<LockMintEntity | BurnRedeemEntity | ReleaseMASEntity>,
        relayerId: number,
        signature: string,
    ): Promise<ReleaseMASEntity | LockMintEntity | BurnRedeemEntity> {
        const signatures: Signature = { relayerId, signature };
        this.logger.log(`Updating entity ${Object.values(filter).join(', ')} signature for relayer ${relayerId}`);

        // Atomic update
        const updateRes = await repo.findOneAndUpdate(
            filter,
            {
                $addToSet: {
                    signatures,
                },
            },
            { returnDocument: 'after' },
        );
        if (updateRes.value) {
            return updateRes.value;
        }
        throw new Error(`Failed to add signature for entity ${Object.values(filter).join(', ')}`);
    }

    public async getReleases(
        filter?: FindManyOptions<ReleaseMASEntity> | Partial<ReleaseMASEntity> | FilterOperators<ReleaseMASEntity>,
    ): Promise<ReleaseMASEntity[]> {
        return this.releaseMAS.find(filter);
    }

    public async getFailedRelease(): Promise<ReleaseMASEntity[]> {
        return this.getReleases({
            error: { $ne: null },
            state: BridgingState.error,
        });
    }

    public async countReleases(query?: ObjectLiteral): Promise<number> {
        return this.releaseMAS.count(query);
    }
}
