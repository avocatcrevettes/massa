export enum Networks {
    Mainnet = 1,
    Sepolia = 11155111,
    BSC = 56,
    // eslint-disable-next-line camelcase
    BSC_Testnet = 97,
}
export const networkName = (chainId: number) => {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    return Object.entries(Networks).find(([_key, value]) => value === chainId)?.[0];
};
