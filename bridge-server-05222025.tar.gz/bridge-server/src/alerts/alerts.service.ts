/* eslint-disable camelcase */
import { Injectable, Logger } from '@nestjs/common';
import { firstValueFrom } from 'rxjs';
import { HttpService } from '@nestjs/axios';
import { DatabaseService } from '../database/database.service';
import { Cron, CronExpression } from '@nestjs/schedule';
import { MassaClientService } from '../massa-client/massa-client.service';
import { BurnRedeemEntity } from '../database/entities';
import { ObjectId } from 'mongodb';
import { CHAIN_ID } from '@massalabs/massa-web3';

const EVENT_EXPIRATION_TIME = 1000 * 60 * 1;
const alertInstance = 'bridge';

@Injectable()
export class AlertsService {
    private readonly logger = new Logger('Alerts');

    public enabled = false;
    public isBootstrapping = true;
    private webHookUrl;
    private massaNetwork;

    constructor(
        private readonly httpService: HttpService,
        protected readonly massaClient: MassaClientService,
        protected readonly db: DatabaseService,
    ) {
        this.enabled = process.env.ALERTS_ENABLED === 'true';
        if (this.enabled) {
            this.logger.log('Alerts enabled');
            this.webHookUrl = process.env.ALERTS_WEBHOOK_URL;
            if (!this.webHookUrl) {
                this.logger.error('Alerts enabled but no webhook url provided');
            }
        }
    }

    public async onModuleInit(): Promise<void> {
        if (this.enabled) {
            const { chain_id } = await this.massaClient.client.publicApi().getNodeStatus();
            this.massaNetwork = chain_id === CHAIN_ID.MainNet ? 'Mainnet' : 'Buildnet';
        }
    }

    public async triggerAlert(
        alertname: string,
        summary: string,
        severity: 'warning' | 'critical' = 'warning',
        isOneTimeEvent = false,
    ): Promise<void> {
        this.logger.log(`Triggering alert ${alertname}. Message: ${summary}`);

        const alertData = [
            {
                status: 'firing',
                labels: {
                    alertname,
                    severity,
                    instance: alertInstance,
                    dimension_Network: this.massaNetwork,
                },
                annotations: {
                    summary,
                },
            },
        ];
        if (isOneTimeEvent) {
            alertData[0]['endsAt'] = new Date(Date.now() + EVENT_EXPIRATION_TIME).toISOString();
        }
        await this.postAlert(alertData);
    }

    public async closeAlert(alert: string): Promise<void> {
        const alertData = [
            {
                status: 'resolved',
                labels: {
                    alertname: alert,
                },
            },
        ];
        await this.postAlert(alertData);
    }

    private async postAlert(data: any): Promise<void> {
        if (this.webHookUrl) {
            // do not send the same alert twice
            const activeAlerts = await this.getAlerts();
            if (activeAlerts.includes(data[0].labels.alertname)) {
                return;
            }
            try {
                await firstValueFrom(this.httpService.post(this.webHookUrl, data));
            } catch (e) {
                this.logger.warn('Error posting alert: ' + e.toString());
            }
        }
    }

    private async getAlerts(): Promise<string[]> {
        if (this.webHookUrl) {
            try {
                const { data } = await firstValueFrom(this.httpService.get(this.webHookUrl));
                return data.data
                    .filter((item) => item.labels.instance === alertInstance && item.status.state === 'active')
                    .map((item) => item.labels.alertname);
            } catch (e) {
                this.logger.warn('Error getting alerts: ' + e.toString());
            }
        }
    }

    @Cron(CronExpression.EVERY_10_MINUTES)
    public async relayerHealthCheck(): Promise<void> {
        // get all database entries created between 1h and 5 minutes ago
        // for each of them check if all signatures are collected
        // if signatures are missing, trigger an alert containing the missing relayers
        if (this.isBootstrapping) {
            return;
        }
        const nbRelayers = this.massaClient.relayersPublicKeys.length;
        for (const repo of [this.db.lockMint, this.db.burnRedeem, this.db.releaseMAS]) {
            // Get current UTC time
            const now = new Date();
            const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000); // 10 minutes ago
            const oneHourAgo = new Date(now.getTime() - 60 * 60 * 1000); // 1 hour ago

            // Extract timestamp from ObjectId for the time range
            const fiveMinutesAgoTimestamp = Math.floor(fiveMinutesAgo.getTime() / 1000);
            const oneHourAgoTimestamp = Math.floor(oneHourAgo.getTime() / 1000);

            // Find documents created between 1 hour ago and 5 minutes ago
            const result = await repo.find({
                _id: {
                    $gte: ObjectId.createFromTime(oneHourAgoTimestamp),
                    $lte: ObjectId.createFromTime(fiveMinutesAgoTimestamp),
                },
            });
            for (const entry of result) {
                if (entry.signatures.length < nbRelayers) {
                    const input = entry instanceof BurnRedeemEntity ? entry?.inputOpId : entry?.inputTxId;

                    const missingRelayers = [];
                    // find which relayer is missing
                    for (let i = 0; i < nbRelayers; i++) {
                        if (!entry.signatures.find((s) => s.relayerId === i)) {
                            missingRelayers.push(i);
                        }
                    }

                    await this.triggerAlert(
                        `missing-signatures-${input}`,
                        `Missing signatures for relayer(s) ${missingRelayers.join(', ')} for ${input}`,
                        'critical',
                    );
                }
            }
        }
    }
}
