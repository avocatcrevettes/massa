import { Module } from '@nestjs/common';
import { DatabaseModule } from '../database/database.module';
import { MassaClientModule } from '../massa-client/massa-client.module';
import { EvmHttpProviderModule } from '../evm-http-provider/evm-http-provider.module';
import { EvmBlockParserService } from './evm-block-parser.service';
import { EvmEventHandlerService } from './event-handler.service';
import { AlertsModule } from '../alerts/alerts.module';

@Module({
    imports: [DatabaseModule, MassaClientModule, EvmHttpProviderModule, AlertsModule],
    controllers: [],
    providers: [EvmBlockParserService, EvmEventHandlerService],
    exports: [EvmBlockParserService],
})
export class EvmListenerModule {}
