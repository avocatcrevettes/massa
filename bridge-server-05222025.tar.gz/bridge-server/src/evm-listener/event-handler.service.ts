import { ethers } from 'ethers';
import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from '../database/database.service';
import { MassaClientService } from '../massa-client/massa-client.service';
import { EvmHttpProviderService } from '../evm-http-provider/evm-http-provider.service';
import { isHexadecimal } from 'class-validator';
import { toReadable } from '../utils/decimals';
import { MintService } from '../massa-client/mint.service';
import { BridgingState, isSignedByRelayer } from '../database/entities';
import { BurnService } from '../massa-client/burn.service';
import { ReleaseMasService } from '../massa-client/releaseMAS.service';
import { multisigThresholdReached, signMintRequest, signReleaseRequest } from '../massa-client/multisig-utils';
import { networkName } from '../evm-http-provider/networks';

@Injectable()
export class EvmEventHandlerService {
    constructor(
        protected readonly mint: MintService,
        protected readonly provider: EvmHttpProviderService,
        protected readonly massaClient: MassaClientService,
        protected readonly burn: BurnService,
        protected readonly release: ReleaseMasService,
        protected readonly db: DatabaseService,
    ) {}

    private readonly logger = new Logger('evm-events-handler');

    public minConfirmations: Record<number, number> = {};

    async onApplicationBootstrap(): Promise<void> {
        const tokenInfos = await Promise.all(
            this.massaClient.tokensInfos.map(async (info) => {
                const balance = await this.provider.getVaultBalance(info.chainId, info.evmToken);
                const symbol = await this.provider.getTokenSymbol(info.chainId, info.evmToken);
                const decs = await this.provider.getTokenDecimals(info.chainId, info.evmToken);
                return { token: info.evmToken, balance, symbol, decs, chainId: info.chainId };
            }),
        );
        this.logger.log('Vault balances:');
        tokenInfos.map((info) =>
            this.logger.log(`${networkName(info.chainId)}: ${info.symbol}: ${toReadable(info.balance, info.decs)}`),
        );

        if (this.provider.WMasListeningEnabled && !this.massaClient.MasVaultContract) {
            throw new Error(
                'Listening to WMAS events is enabled but Massa MAS vault is not enabled. Check your configuration',
            );
        }

        let networkIdx = 0;
        for (const chainId of this.provider.enabledNetworks) {
            const minConfirmations = parseInt(process.env[`EVM_MIN_CONFIRMATIONS_${networkIdx}`]);
            if (isNaN(minConfirmations) || minConfirmations < 0) {
                throw new Error('Invalid EVM_MIN_CONFIRMATIONS for network ' + chainId);
            }
            this.minConfirmations[chainId] = minConfirmations;
            ++networkIdx;
        }
    }

    public handleLockEvent = async (
        chainId: number,
        senderAddr: string,
        token: string,
        recipientAddr: string,
        amount: ethers.BigNumber,
        lockedAmount: ethers.BigNumber,
        event: ethers.providers.Log,
        confirmations = 0,
    ): Promise<void> => {
        // logIndex is number when coming from websocket, hex string when coming from http provider
        const inputLogIdx = isHexadecimal(event.logIndex) ? parseInt(event.logIndex as any, 16) : event.logIndex;
        const relayerId = this.massaClient.relayerId;

        try {
            this.logger.log(
                `[${networkName(chainId)}]: Lock event received. txId ${
                    event.transactionHash
                }. confirmations: ${confirmations}`,
            );

            const massaToken = await this.massaClient.getMassaTokenAddress(token);

            // create or update new entry in db
            let entity = await this.db.addNewLockMint({
                inputTxId: event.transactionHash,
                inputLogIdx,
                inputAddr: senderAddr,
                outputAddr: recipientAddr,
                amount: amount.toString(),
                outputAmount: lockedAmount.toString(),
                ercToken: token,
                massaToken,
                originNetwork: chainId,
                inputConfirmations: confirmations,
            });

            if (confirmations < this.minConfirmations[chainId] || isSignedByRelayer(entity, relayerId)) {
                return;
            }

            // only sign data coming from the blockchain to mitigate database corruption risk
            const signature = await this.signMintRequest(
                event.transactionHash,
                inputLogIdx,
                recipientAddr,
                lockedAmount.toString(),
                massaToken,
                chainId,
            );

            entity = await this.db.addMintSignature(entity, relayerId, signature);

            // if not enough signatures collected, stop here
            // if already processed, stop here as well
            if (
                entity.state != BridgingState.new ||
                !multisigThresholdReached(entity, this.massaClient.multisigThreshold)
            ) {
                return;
            }

            // this throws if the entry is not in new state
            await this.db.updateLockMintState(event.transactionHash, inputLogIdx, BridgingState.new, {
                state: BridgingState.processing,
            });

            let opId: string;
            try {
                opId = await this.mint.mintWrappedAsset(entity);

                // set output opId
                entity = await this.db.updateLockMintState(
                    event.transactionHash,
                    inputLogIdx,
                    BridgingState.processing,
                    {
                        state: BridgingState.processing,
                        outputOpId: opId,
                    },
                );
            } catch (bridgeError) {
                await this.db.updateLockMintState(event.transactionHash, inputLogIdx, BridgingState.processing, {
                    state: BridgingState.error,
                    error: bridgeError,
                });
                return;
            }

            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            this.mint.finalizeLockMint(entity);
        } catch (err) {
            this.logger.error(
                `Unable to process Lock event, txd ${event.transactionHash} logIndex ${event.logIndex}`,
                err.toString(),
            );
        }
    };

    public handleRedeemEvent = async (
        chainId: number,
        inputOpId: string,
        amount: ethers.BigNumber,
        event: ethers.providers.Log,
        confirmations = 0,
    ): Promise<void> => {
        try {
            this.logger.log(
                `[${networkName(chainId)}]:Redeem event received. txId ${
                    event.transactionHash
                }. confirmations: ${confirmations}`,
            );
            await this.db.updateBurnRedeem(inputOpId, undefined, {
                outputTxId: event.transactionHash,
                outputConfirmations: confirmations,
                outputAmount: amount.toString(),
            });
        } catch (err) {
            this.logger.warn(`Unable to update Redeem event infos of burn opId ${inputOpId}`, err.toString());
        }
    };

    public async signMintRequest(
        inputTxId: string,
        inputLogIdx: number,
        outputAddr: string,
        amount: string,
        massaToken: string,
        chainId: number,
    ): Promise<string> {
        this.logger.log(`Signing mint request ${inputTxId}`);
        return signMintRequest(this.provider.signers[chainId], inputTxId, inputLogIdx, outputAddr, amount, massaToken);
    }

    public handleBurnEvent = async (
        chainId: number,
        account: string,
        massaAddress: string,
        amount: ethers.BigNumber,
        event: ethers.providers.Log,
        confirmations = 0,
    ): Promise<void> => {
        try {
            this.logger.log(
                `[${networkName(chainId)}]: Burn event received. txId ${
                    event.transactionHash
                }. confirmations: ${confirmations}`,
            );

            // logIndex is number when coming from websocket, hex string when coming from http provider
            const inputLogIdx = isHexadecimal(event.logIndex) ? parseInt(event.logIndex as any, 16) : event.logIndex;

            const relayerId = this.massaClient.relayerId;

            let entity = await this.db.addNewReleaseMas({
                inputTxId: event.transactionHash,
                inputLogIdx,
                inputAddr: account,
                outputAddr: massaAddress,
                amount: amount.toString(),
                originNetwork: chainId,
                inputConfirmations: confirmations,
            });

            if (confirmations < this.minConfirmations[chainId] || isSignedByRelayer(entity, relayerId)) {
                return;
            }

            // only sign data coming from the blockchain to mitigate database corruption risk
            const signature = await this.signReleaseRequest(
                event.transactionHash,
                inputLogIdx,
                massaAddress,
                amount.toString(),
                chainId,
            );

            entity = await this.db.addReleaseSignature(entity, relayerId, signature);

            // if not enough signatures collected, stop here
            // if already processed, stop here
            if (
                entity.state != BridgingState.new ||
                !multisigThresholdReached(entity, this.massaClient.multisigThreshold)
            ) {
                return;
            }

            // this throws if the entry is not in new state
            // first relayer to update state will be able to process the release
            await this.db.updateReleaseMasState(event.transactionHash, inputLogIdx, BridgingState.new, {
                state: BridgingState.processing,
            });

            let opId: string;
            try {
                opId = await this.release.submit(entity);
                // set output opId
                entity = await this.db.updateReleaseMasState(
                    event.transactionHash,
                    inputLogIdx,
                    BridgingState.processing,
                    {
                        state: BridgingState.processing,
                        outputOpId: opId,
                    },
                );
            } catch (bridgeError) {
                await this.db.updateReleaseMasState(event.transactionHash, inputLogIdx, BridgingState.processing, {
                    state: BridgingState.error,
                    error: bridgeError,
                });
                return;
            }

            // eslint-disable-next-line @typescript-eslint/no-floating-promises
            this.release.finalize(entity);
        } catch (err) {
            this.logger.warn(`Unable to process burn event ${event.transactionHash}`, err.toString());
        }
    };

    public async signReleaseRequest(
        inputTxId: string,
        inputLogIdx: number,
        outputAddr: string,
        amount: string,
        chainId: number,
    ): Promise<string> {
        this.logger.log(`Signing release request ${inputTxId}`);
        return signReleaseRequest(this.provider.signers[chainId], inputTxId, inputLogIdx, outputAddr, amount, chainId);
    }
}
