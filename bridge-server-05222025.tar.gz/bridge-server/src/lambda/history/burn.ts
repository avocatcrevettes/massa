import { Entities, HistoryOperationStatus, HistoryRequest, OperationHistoryItem } from './interface';
import { BridgingState, BurnRedeemEntity } from '../../database/entities';
import { getFilterMassaToEvm, requiredConfirmations, prepareSignatures } from './utils';
import { BridgeError } from '../../utils/errors';
import { dataSource } from './handle';

export async function fetchBurnRedeem(request: HistoryRequest): Promise<OperationHistoryItem[]> {
    const burnRedeemRepository = dataSource.getMongoRepository(BurnRedeemEntity);

    const burnRedeems = await burnRedeemRepository.find({
        where: getFilterMassaToEvm(request),
    });

    return burnRedeems.map((burnRedeem): OperationHistoryItem => {
        const isConfirmed = burnRedeem.outputConfirmations >= requiredConfirmations[burnRedeem.destinationNetwork];
        return {
            entity: Entities.Burn,
            emitter: burnRedeem.inputAddr,
            inputId: burnRedeem.inputOpId,
            amount: burnRedeem.amount,
            outputAmount: burnRedeem.outputAmount ?? burnRedeem.outputTxId ? burnRedeem.amount : null,
            evmToken: burnRedeem.ercToken,
            massaToken: burnRedeem.massaToken,
            recipient: burnRedeem.outputAddr,
            signatures: prepareSignatures(burnRedeem.signatures),
            evmChainId: burnRedeem.destinationNetwork,
            outputId: burnRedeem.outputTxId,
            confirmations: burnRedeem.outputConfirmations,
            isConfirmed,
            serverState: burnRedeem.state,
            historyStatus: getBurnedHistoryStatus(
                burnRedeem.outputTxId,
                burnRedeem.error,
                burnRedeem.state,
                isConfirmed,
            ),
            error: burnRedeem.error,
            createdAt: burnRedeem.id.getTimestamp().toISOString(),
        };
    });
}

function getBurnedHistoryStatus(
    outputTxId: string | null,
    error: BridgeError,
    state: string,
    isConfirmed: boolean,
): HistoryOperationStatus {
    if (state === BridgingState.finalizing || state === BridgingState.done) {
        // finalizing means relayer is deleting the burn request log in the smart contract
        return HistoryOperationStatus.Done;
    }
    if (state === BridgingState.processing) {
        if (isConfirmed) {
            // User claimed, we have enough confirmations
            return HistoryOperationStatus.Done;
        }
        if (outputTxId) {
            // User claimed, waiting got confirmations of the output transaction
            return HistoryOperationStatus.Pending;
        }
        // User can claim
        return HistoryOperationStatus.Claimable;
    }
    if (state === BridgingState.new && !outputTxId) {
        // Relayer are adding signatures
        return HistoryOperationStatus.Pending;
    }
    if (error !== null || state === BridgingState.error) {
        return HistoryOperationStatus.Error;
    }
    return HistoryOperationStatus.Unknown;
}
