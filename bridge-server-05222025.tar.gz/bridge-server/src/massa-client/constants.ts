import { strToBytes } from '@massalabs/massa-web3';

export const PERIOD_TIME = 16;
export const EXPIRY_PERIOD = 9;

// Massa SC storage prefixes
export const BURN_LOG_PREFIX = 1;
export const MINT_LOG_PREFIX = 2;
export const DATASTORE_ENTRIES_BATCH_SIZE = 2000;
const CONFIG_PREFIX = 0;
export const RELAYERS_PREFIX = Uint8Array.from([CONFIG_PREFIX, ...strToBytes('multisig')]);
export const MULTISIG_THRESHOLD_KEY = Uint8Array.from([CONFIG_PREFIX, ...strToBytes('threshold')]);

export const RELEASE_LOG_PREFIX = 3;
// massa events polling
export const STATUS_POLL_INTERVAL_MS = 1000;
export const WAIT_STATUS_TIMEOUT = EXPIRY_PERIOD * 2 * PERIOD_TIME * 1000;
