#!/usr/bin/env node
/* eslint @typescript-eslint/no-var-requires: 0 */

const esbuildPluginTsc = require('esbuild-plugin-tsc');

require('esbuild')
    .build({
        logLevel: 'info',
        entryPoints: ['src/lambda/history/index.ts'],
        bundle: true,
        minify: true,
        sourcemap: true,
        platform: 'node',
        target: 'es2020',
        outfile: 'dist-lambda/index.js',
        external: ['mongodb-memory-server'],
        plugins: [esbuildPluginTsc()],
    })
    .catch(() => process.exit(1));
