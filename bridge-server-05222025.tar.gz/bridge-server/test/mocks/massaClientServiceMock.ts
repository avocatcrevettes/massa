import { Token1 } from './tokens';

export const opId = 'O129rzGUZ2sVHwuud4hrB4cnnsR3XPuRViG7bUiVLV65ejszMFUm';
export const relayerId = 2;

export const smartContractsMock = {
    callSmartContract: jest.fn().mockResolvedValue(opId),
};

export const walletMock = {
    getAccountBalance: jest.fn().mockResolvedValue({ final: 0n, candidate: 0n }),
};

export const massaClientServiceMock = {
    enableBridge: true,
    enableMasVault: true,
    onModuleInit: jest.fn(),
    tokensInfos: [Token1],
    lockIdList: [],
    getMassaTokenAddress: jest.fn().mockReturnValue(Token1.massaToken),
    getTokenSymbol: jest.fn().mockReturnValue(Token1.symbol),
    getTokenDecimals: jest.fn().mockReturnValue(Token1.decs),
    client: {
        smartContracts: () => smartContractsMock,
        wallet: () => walletMock,
    },
    getBurnList: jest.fn(),
    getDataStoreEntry: jest.fn(),

    relayersPublicKeys: ['publicKey0', 'publicKey1', 'publicKey2', 'publicKey3'],
    relayerId,
    reserveAccount: {
        sendTransaction: jest.fn().mockResolvedValue(opId),
    },
    multisigThreshold: 3,
};
